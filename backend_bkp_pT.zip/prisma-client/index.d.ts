
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model admin
 * 
 */
export type admin = $Result.DefaultSelection<Prisma.$adminPayload>
/**
 * Model credit
 * 
 */
export type credit = $Result.DefaultSelection<Prisma.$creditPayload>
/**
 * Model customer
 * 
 */
export type customer = $Result.DefaultSelection<Prisma.$customerPayload>
/**
 * Model inventory_inflow_outflow
 * 
 */
export type inventory_inflow_outflow = $Result.DefaultSelection<Prisma.$inventory_inflow_outflowPayload>
/**
 * Model notification
 * 
 */
export type notification = $Result.DefaultSelection<Prisma.$notificationPayload>
/**
 * Model order
 * 
 */
export type order = $Result.DefaultSelection<Prisma.$orderPayload>
/**
 * Model order_details
 * 
 */
export type order_details = $Result.DefaultSelection<Prisma.$order_detailsPayload>
/**
 * Model payment
 * 
 */
export type payment = $Result.DefaultSelection<Prisma.$paymentPayload>
/**
 * Model product
 * 
 */
export type product = $Result.DefaultSelection<Prisma.$productPayload>
/**
 * Model quotation
 * 
 */
export type quotation = $Result.DefaultSelection<Prisma.$quotationPayload>
/**
 * Model quotation_details
 * 
 */
export type quotation_details = $Result.DefaultSelection<Prisma.$quotation_detailsPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const credit_status_enum: {
  receivable: 'receivable',
  received: 'received'
};

export type credit_status_enum = (typeof credit_status_enum)[keyof typeof credit_status_enum]


export const flow_direction_enum: {
  in: 'in',
  out: 'out'
};

export type flow_direction_enum = (typeof flow_direction_enum)[keyof typeof flow_direction_enum]


export const order_status_enum: {
  pending: 'pending',
  confirmed: 'confirmed',
  cancelled: 'cancelled',
  completed: 'completed'
};

export type order_status_enum = (typeof order_status_enum)[keyof typeof order_status_enum]


export const payment_mode_enum: {
  credit: 'credit',
  cash: 'cash',
  upi: 'upi',
  card: 'card',
  cheque: 'cheque'
};

export type payment_mode_enum = (typeof payment_mode_enum)[keyof typeof payment_mode_enum]


export const payment_status_enum: {
  pending: 'pending',
  completed: 'completed',
  failed: 'failed'
};

export type payment_status_enum = (typeof payment_status_enum)[keyof typeof payment_status_enum]


export const quotation_status_enum: {
  draft: 'draft',
  sent: 'sent',
  approved: 'approved',
  rejected: 'rejected'
};

export type quotation_status_enum = (typeof quotation_status_enum)[keyof typeof quotation_status_enum]

}

export type credit_status_enum = $Enums.credit_status_enum

export const credit_status_enum: typeof $Enums.credit_status_enum

export type flow_direction_enum = $Enums.flow_direction_enum

export const flow_direction_enum: typeof $Enums.flow_direction_enum

export type order_status_enum = $Enums.order_status_enum

export const order_status_enum: typeof $Enums.order_status_enum

export type payment_mode_enum = $Enums.payment_mode_enum

export const payment_mode_enum: typeof $Enums.payment_mode_enum

export type payment_status_enum = $Enums.payment_status_enum

export const payment_status_enum: typeof $Enums.payment_status_enum

export type quotation_status_enum = $Enums.quotation_status_enum

export const quotation_status_enum: typeof $Enums.quotation_status_enum

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Admins
 * const admins = await prisma.admin.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Admins
   * const admins = await prisma.admin.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.admin`: Exposes CRUD operations for the **admin** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Admins
    * const admins = await prisma.admin.findMany()
    * ```
    */
  get admin(): Prisma.adminDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.credit`: Exposes CRUD operations for the **credit** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Credits
    * const credits = await prisma.credit.findMany()
    * ```
    */
  get credit(): Prisma.creditDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.customer`: Exposes CRUD operations for the **customer** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Customers
    * const customers = await prisma.customer.findMany()
    * ```
    */
  get customer(): Prisma.customerDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.inventory_inflow_outflow`: Exposes CRUD operations for the **inventory_inflow_outflow** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Inventory_inflow_outflows
    * const inventory_inflow_outflows = await prisma.inventory_inflow_outflow.findMany()
    * ```
    */
  get inventory_inflow_outflow(): Prisma.inventory_inflow_outflowDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.notification`: Exposes CRUD operations for the **notification** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Notifications
    * const notifications = await prisma.notification.findMany()
    * ```
    */
  get notification(): Prisma.notificationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.order`: Exposes CRUD operations for the **order** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Orders
    * const orders = await prisma.order.findMany()
    * ```
    */
  get order(): Prisma.orderDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.order_details`: Exposes CRUD operations for the **order_details** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Order_details
    * const order_details = await prisma.order_details.findMany()
    * ```
    */
  get order_details(): Prisma.order_detailsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.payment`: Exposes CRUD operations for the **payment** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Payments
    * const payments = await prisma.payment.findMany()
    * ```
    */
  get payment(): Prisma.paymentDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.product`: Exposes CRUD operations for the **product** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Products
    * const products = await prisma.product.findMany()
    * ```
    */
  get product(): Prisma.productDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.quotation`: Exposes CRUD operations for the **quotation** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Quotations
    * const quotations = await prisma.quotation.findMany()
    * ```
    */
  get quotation(): Prisma.quotationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.quotation_details`: Exposes CRUD operations for the **quotation_details** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Quotation_details
    * const quotation_details = await prisma.quotation_details.findMany()
    * ```
    */
  get quotation_details(): Prisma.quotation_detailsDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.16.2
   * Query Engine version: 1c57fdcd7e44b29b9313256c76699e91c3ac3c43
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    admin: 'admin',
    credit: 'credit',
    customer: 'customer',
    inventory_inflow_outflow: 'inventory_inflow_outflow',
    notification: 'notification',
    order: 'order',
    order_details: 'order_details',
    payment: 'payment',
    product: 'product',
    quotation: 'quotation',
    quotation_details: 'quotation_details'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "admin" | "credit" | "customer" | "inventory_inflow_outflow" | "notification" | "order" | "order_details" | "payment" | "product" | "quotation" | "quotation_details"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      admin: {
        payload: Prisma.$adminPayload<ExtArgs>
        fields: Prisma.adminFieldRefs
        operations: {
          findUnique: {
            args: Prisma.adminFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.adminFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          findFirst: {
            args: Prisma.adminFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.adminFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          findMany: {
            args: Prisma.adminFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>[]
          }
          create: {
            args: Prisma.adminCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          createMany: {
            args: Prisma.adminCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.adminCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>[]
          }
          delete: {
            args: Prisma.adminDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          update: {
            args: Prisma.adminUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          deleteMany: {
            args: Prisma.adminDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.adminUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.adminUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>[]
          }
          upsert: {
            args: Prisma.adminUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$adminPayload>
          }
          aggregate: {
            args: Prisma.AdminAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAdmin>
          }
          groupBy: {
            args: Prisma.adminGroupByArgs<ExtArgs>
            result: $Utils.Optional<AdminGroupByOutputType>[]
          }
          count: {
            args: Prisma.adminCountArgs<ExtArgs>
            result: $Utils.Optional<AdminCountAggregateOutputType> | number
          }
        }
      }
      credit: {
        payload: Prisma.$creditPayload<ExtArgs>
        fields: Prisma.creditFieldRefs
        operations: {
          findUnique: {
            args: Prisma.creditFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.creditFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          findFirst: {
            args: Prisma.creditFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.creditFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          findMany: {
            args: Prisma.creditFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>[]
          }
          create: {
            args: Prisma.creditCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          createMany: {
            args: Prisma.creditCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.creditCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>[]
          }
          delete: {
            args: Prisma.creditDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          update: {
            args: Prisma.creditUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          deleteMany: {
            args: Prisma.creditDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.creditUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.creditUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>[]
          }
          upsert: {
            args: Prisma.creditUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$creditPayload>
          }
          aggregate: {
            args: Prisma.CreditAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCredit>
          }
          groupBy: {
            args: Prisma.creditGroupByArgs<ExtArgs>
            result: $Utils.Optional<CreditGroupByOutputType>[]
          }
          count: {
            args: Prisma.creditCountArgs<ExtArgs>
            result: $Utils.Optional<CreditCountAggregateOutputType> | number
          }
        }
      }
      customer: {
        payload: Prisma.$customerPayload<ExtArgs>
        fields: Prisma.customerFieldRefs
        operations: {
          findUnique: {
            args: Prisma.customerFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.customerFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          findFirst: {
            args: Prisma.customerFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.customerFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          findMany: {
            args: Prisma.customerFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>[]
          }
          create: {
            args: Prisma.customerCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          createMany: {
            args: Prisma.customerCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.customerCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>[]
          }
          delete: {
            args: Prisma.customerDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          update: {
            args: Prisma.customerUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          deleteMany: {
            args: Prisma.customerDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.customerUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.customerUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>[]
          }
          upsert: {
            args: Prisma.customerUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$customerPayload>
          }
          aggregate: {
            args: Prisma.CustomerAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCustomer>
          }
          groupBy: {
            args: Prisma.customerGroupByArgs<ExtArgs>
            result: $Utils.Optional<CustomerGroupByOutputType>[]
          }
          count: {
            args: Prisma.customerCountArgs<ExtArgs>
            result: $Utils.Optional<CustomerCountAggregateOutputType> | number
          }
        }
      }
      inventory_inflow_outflow: {
        payload: Prisma.$inventory_inflow_outflowPayload<ExtArgs>
        fields: Prisma.inventory_inflow_outflowFieldRefs
        operations: {
          findUnique: {
            args: Prisma.inventory_inflow_outflowFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.inventory_inflow_outflowFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          findFirst: {
            args: Prisma.inventory_inflow_outflowFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.inventory_inflow_outflowFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          findMany: {
            args: Prisma.inventory_inflow_outflowFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>[]
          }
          create: {
            args: Prisma.inventory_inflow_outflowCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          createMany: {
            args: Prisma.inventory_inflow_outflowCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.inventory_inflow_outflowCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>[]
          }
          delete: {
            args: Prisma.inventory_inflow_outflowDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          update: {
            args: Prisma.inventory_inflow_outflowUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          deleteMany: {
            args: Prisma.inventory_inflow_outflowDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.inventory_inflow_outflowUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.inventory_inflow_outflowUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>[]
          }
          upsert: {
            args: Prisma.inventory_inflow_outflowUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inventory_inflow_outflowPayload>
          }
          aggregate: {
            args: Prisma.Inventory_inflow_outflowAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateInventory_inflow_outflow>
          }
          groupBy: {
            args: Prisma.inventory_inflow_outflowGroupByArgs<ExtArgs>
            result: $Utils.Optional<Inventory_inflow_outflowGroupByOutputType>[]
          }
          count: {
            args: Prisma.inventory_inflow_outflowCountArgs<ExtArgs>
            result: $Utils.Optional<Inventory_inflow_outflowCountAggregateOutputType> | number
          }
        }
      }
      notification: {
        payload: Prisma.$notificationPayload<ExtArgs>
        fields: Prisma.notificationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.notificationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.notificationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          findFirst: {
            args: Prisma.notificationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.notificationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          findMany: {
            args: Prisma.notificationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>[]
          }
          create: {
            args: Prisma.notificationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          createMany: {
            args: Prisma.notificationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.notificationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>[]
          }
          delete: {
            args: Prisma.notificationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          update: {
            args: Prisma.notificationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          deleteMany: {
            args: Prisma.notificationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.notificationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.notificationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>[]
          }
          upsert: {
            args: Prisma.notificationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$notificationPayload>
          }
          aggregate: {
            args: Prisma.NotificationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateNotification>
          }
          groupBy: {
            args: Prisma.notificationGroupByArgs<ExtArgs>
            result: $Utils.Optional<NotificationGroupByOutputType>[]
          }
          count: {
            args: Prisma.notificationCountArgs<ExtArgs>
            result: $Utils.Optional<NotificationCountAggregateOutputType> | number
          }
        }
      }
      order: {
        payload: Prisma.$orderPayload<ExtArgs>
        fields: Prisma.orderFieldRefs
        operations: {
          findUnique: {
            args: Prisma.orderFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.orderFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          findFirst: {
            args: Prisma.orderFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.orderFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          findMany: {
            args: Prisma.orderFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>[]
          }
          create: {
            args: Prisma.orderCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          createMany: {
            args: Prisma.orderCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.orderCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>[]
          }
          delete: {
            args: Prisma.orderDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          update: {
            args: Prisma.orderUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          deleteMany: {
            args: Prisma.orderDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.orderUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.orderUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>[]
          }
          upsert: {
            args: Prisma.orderUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$orderPayload>
          }
          aggregate: {
            args: Prisma.OrderAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrder>
          }
          groupBy: {
            args: Prisma.orderGroupByArgs<ExtArgs>
            result: $Utils.Optional<OrderGroupByOutputType>[]
          }
          count: {
            args: Prisma.orderCountArgs<ExtArgs>
            result: $Utils.Optional<OrderCountAggregateOutputType> | number
          }
        }
      }
      order_details: {
        payload: Prisma.$order_detailsPayload<ExtArgs>
        fields: Prisma.order_detailsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.order_detailsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.order_detailsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          findFirst: {
            args: Prisma.order_detailsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.order_detailsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          findMany: {
            args: Prisma.order_detailsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>[]
          }
          create: {
            args: Prisma.order_detailsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          createMany: {
            args: Prisma.order_detailsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.order_detailsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>[]
          }
          delete: {
            args: Prisma.order_detailsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          update: {
            args: Prisma.order_detailsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          deleteMany: {
            args: Prisma.order_detailsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.order_detailsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.order_detailsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>[]
          }
          upsert: {
            args: Prisma.order_detailsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$order_detailsPayload>
          }
          aggregate: {
            args: Prisma.Order_detailsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrder_details>
          }
          groupBy: {
            args: Prisma.order_detailsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Order_detailsGroupByOutputType>[]
          }
          count: {
            args: Prisma.order_detailsCountArgs<ExtArgs>
            result: $Utils.Optional<Order_detailsCountAggregateOutputType> | number
          }
        }
      }
      payment: {
        payload: Prisma.$paymentPayload<ExtArgs>
        fields: Prisma.paymentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.paymentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.paymentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          findFirst: {
            args: Prisma.paymentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.paymentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          findMany: {
            args: Prisma.paymentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>[]
          }
          create: {
            args: Prisma.paymentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          createMany: {
            args: Prisma.paymentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.paymentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>[]
          }
          delete: {
            args: Prisma.paymentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          update: {
            args: Prisma.paymentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          deleteMany: {
            args: Prisma.paymentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.paymentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.paymentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>[]
          }
          upsert: {
            args: Prisma.paymentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paymentPayload>
          }
          aggregate: {
            args: Prisma.PaymentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePayment>
          }
          groupBy: {
            args: Prisma.paymentGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaymentGroupByOutputType>[]
          }
          count: {
            args: Prisma.paymentCountArgs<ExtArgs>
            result: $Utils.Optional<PaymentCountAggregateOutputType> | number
          }
        }
      }
      product: {
        payload: Prisma.$productPayload<ExtArgs>
        fields: Prisma.productFieldRefs
        operations: {
          findUnique: {
            args: Prisma.productFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.productFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          findFirst: {
            args: Prisma.productFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.productFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          findMany: {
            args: Prisma.productFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>[]
          }
          create: {
            args: Prisma.productCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          createMany: {
            args: Prisma.productCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.productCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>[]
          }
          delete: {
            args: Prisma.productDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          update: {
            args: Prisma.productUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          deleteMany: {
            args: Prisma.productDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.productUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.productUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>[]
          }
          upsert: {
            args: Prisma.productUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productPayload>
          }
          aggregate: {
            args: Prisma.ProductAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProduct>
          }
          groupBy: {
            args: Prisma.productGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.productCountArgs<ExtArgs>
            result: $Utils.Optional<ProductCountAggregateOutputType> | number
          }
        }
      }
      quotation: {
        payload: Prisma.$quotationPayload<ExtArgs>
        fields: Prisma.quotationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.quotationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.quotationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          findFirst: {
            args: Prisma.quotationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.quotationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          findMany: {
            args: Prisma.quotationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>[]
          }
          create: {
            args: Prisma.quotationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          createMany: {
            args: Prisma.quotationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.quotationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>[]
          }
          delete: {
            args: Prisma.quotationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          update: {
            args: Prisma.quotationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          deleteMany: {
            args: Prisma.quotationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.quotationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.quotationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>[]
          }
          upsert: {
            args: Prisma.quotationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotationPayload>
          }
          aggregate: {
            args: Prisma.QuotationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateQuotation>
          }
          groupBy: {
            args: Prisma.quotationGroupByArgs<ExtArgs>
            result: $Utils.Optional<QuotationGroupByOutputType>[]
          }
          count: {
            args: Prisma.quotationCountArgs<ExtArgs>
            result: $Utils.Optional<QuotationCountAggregateOutputType> | number
          }
        }
      }
      quotation_details: {
        payload: Prisma.$quotation_detailsPayload<ExtArgs>
        fields: Prisma.quotation_detailsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.quotation_detailsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.quotation_detailsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          findFirst: {
            args: Prisma.quotation_detailsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.quotation_detailsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          findMany: {
            args: Prisma.quotation_detailsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>[]
          }
          create: {
            args: Prisma.quotation_detailsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          createMany: {
            args: Prisma.quotation_detailsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.quotation_detailsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>[]
          }
          delete: {
            args: Prisma.quotation_detailsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          update: {
            args: Prisma.quotation_detailsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          deleteMany: {
            args: Prisma.quotation_detailsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.quotation_detailsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.quotation_detailsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>[]
          }
          upsert: {
            args: Prisma.quotation_detailsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$quotation_detailsPayload>
          }
          aggregate: {
            args: Prisma.Quotation_detailsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateQuotation_details>
          }
          groupBy: {
            args: Prisma.quotation_detailsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Quotation_detailsGroupByOutputType>[]
          }
          count: {
            args: Prisma.quotation_detailsCountArgs<ExtArgs>
            result: $Utils.Optional<Quotation_detailsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    admin?: adminOmit
    credit?: creditOmit
    customer?: customerOmit
    inventory_inflow_outflow?: inventory_inflow_outflowOmit
    notification?: notificationOmit
    order?: orderOmit
    order_details?: order_detailsOmit
    payment?: paymentOmit
    product?: productOmit
    quotation?: quotationOmit
    quotation_details?: quotation_detailsOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type CustomerCountOutputType
   */

  export type CustomerCountOutputType = {
    notification: number
    order: number
    quotation: number
  }

  export type CustomerCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    notification?: boolean | CustomerCountOutputTypeCountNotificationArgs
    order?: boolean | CustomerCountOutputTypeCountOrderArgs
    quotation?: boolean | CustomerCountOutputTypeCountQuotationArgs
  }

  // Custom InputTypes
  /**
   * CustomerCountOutputType without action
   */
  export type CustomerCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CustomerCountOutputType
     */
    select?: CustomerCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CustomerCountOutputType without action
   */
  export type CustomerCountOutputTypeCountNotificationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: notificationWhereInput
  }

  /**
   * CustomerCountOutputType without action
   */
  export type CustomerCountOutputTypeCountOrderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: orderWhereInput
  }

  /**
   * CustomerCountOutputType without action
   */
  export type CustomerCountOutputTypeCountQuotationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: quotationWhereInput
  }


  /**
   * Count Type OrderCountOutputType
   */

  export type OrderCountOutputType = {
    order_details: number
    payment: number
  }

  export type OrderCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order_details?: boolean | OrderCountOutputTypeCountOrder_detailsArgs
    payment?: boolean | OrderCountOutputTypeCountPaymentArgs
  }

  // Custom InputTypes
  /**
   * OrderCountOutputType without action
   */
  export type OrderCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OrderCountOutputType
     */
    select?: OrderCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * OrderCountOutputType without action
   */
  export type OrderCountOutputTypeCountOrder_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: order_detailsWhereInput
  }

  /**
   * OrderCountOutputType without action
   */
  export type OrderCountOutputTypeCountPaymentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paymentWhereInput
  }


  /**
   * Count Type ProductCountOutputType
   */

  export type ProductCountOutputType = {
    inventory_inflow_outflow: number
    order_details: number
    quotation_details: number
  }

  export type ProductCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    inventory_inflow_outflow?: boolean | ProductCountOutputTypeCountInventory_inflow_outflowArgs
    order_details?: boolean | ProductCountOutputTypeCountOrder_detailsArgs
    quotation_details?: boolean | ProductCountOutputTypeCountQuotation_detailsArgs
  }

  // Custom InputTypes
  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductCountOutputType
     */
    select?: ProductCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountInventory_inflow_outflowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: inventory_inflow_outflowWhereInput
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountOrder_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: order_detailsWhereInput
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountQuotation_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: quotation_detailsWhereInput
  }


  /**
   * Count Type QuotationCountOutputType
   */

  export type QuotationCountOutputType = {
    order: number
    quotation_details: number
  }

  export type QuotationCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | QuotationCountOutputTypeCountOrderArgs
    quotation_details?: boolean | QuotationCountOutputTypeCountQuotation_detailsArgs
  }

  // Custom InputTypes
  /**
   * QuotationCountOutputType without action
   */
  export type QuotationCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the QuotationCountOutputType
     */
    select?: QuotationCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * QuotationCountOutputType without action
   */
  export type QuotationCountOutputTypeCountOrderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: orderWhereInput
  }

  /**
   * QuotationCountOutputType without action
   */
  export type QuotationCountOutputTypeCountQuotation_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: quotation_detailsWhereInput
  }


  /**
   * Models
   */

  /**
   * Model admin
   */

  export type AggregateAdmin = {
    _count: AdminCountAggregateOutputType | null
    _avg: AdminAvgAggregateOutputType | null
    _sum: AdminSumAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  export type AdminAvgAggregateOutputType = {
    admin_id: number | null
  }

  export type AdminSumAggregateOutputType = {
    admin_id: number | null
  }

  export type AdminMinAggregateOutputType = {
    admin_id: number | null
    username: string | null
    password: string | null
    email: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type AdminMaxAggregateOutputType = {
    admin_id: number | null
    username: string | null
    password: string | null
    email: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type AdminCountAggregateOutputType = {
    admin_id: number
    username: number
    password: number
    roles: number
    email: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type AdminAvgAggregateInputType = {
    admin_id?: true
  }

  export type AdminSumAggregateInputType = {
    admin_id?: true
  }

  export type AdminMinAggregateInputType = {
    admin_id?: true
    username?: true
    password?: true
    email?: true
    created_at?: true
    updated_at?: true
  }

  export type AdminMaxAggregateInputType = {
    admin_id?: true
    username?: true
    password?: true
    email?: true
    created_at?: true
    updated_at?: true
  }

  export type AdminCountAggregateInputType = {
    admin_id?: true
    username?: true
    password?: true
    roles?: true
    email?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type AdminAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which admin to aggregate.
     */
    where?: adminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of admins to fetch.
     */
    orderBy?: adminOrderByWithRelationInput | adminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: adminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned admins
    **/
    _count?: true | AdminCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AdminAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AdminSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AdminMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AdminMaxAggregateInputType
  }

  export type GetAdminAggregateType<T extends AdminAggregateArgs> = {
        [P in keyof T & keyof AggregateAdmin]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAdmin[P]>
      : GetScalarType<T[P], AggregateAdmin[P]>
  }




  export type adminGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: adminWhereInput
    orderBy?: adminOrderByWithAggregationInput | adminOrderByWithAggregationInput[]
    by: AdminScalarFieldEnum[] | AdminScalarFieldEnum
    having?: adminScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AdminCountAggregateInputType | true
    _avg?: AdminAvgAggregateInputType
    _sum?: AdminSumAggregateInputType
    _min?: AdminMinAggregateInputType
    _max?: AdminMaxAggregateInputType
  }

  export type AdminGroupByOutputType = {
    admin_id: number
    username: string
    password: string
    roles: string[]
    email: string | null
    created_at: Date | null
    updated_at: Date | null
    _count: AdminCountAggregateOutputType | null
    _avg: AdminAvgAggregateOutputType | null
    _sum: AdminSumAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  type GetAdminGroupByPayload<T extends adminGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AdminGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AdminGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AdminGroupByOutputType[P]>
            : GetScalarType<T[P], AdminGroupByOutputType[P]>
        }
      >
    >


  export type adminSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    admin_id?: boolean
    username?: boolean
    password?: boolean
    roles?: boolean
    email?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["admin"]>

  export type adminSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    admin_id?: boolean
    username?: boolean
    password?: boolean
    roles?: boolean
    email?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["admin"]>

  export type adminSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    admin_id?: boolean
    username?: boolean
    password?: boolean
    roles?: boolean
    email?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["admin"]>

  export type adminSelectScalar = {
    admin_id?: boolean
    username?: boolean
    password?: boolean
    roles?: boolean
    email?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type adminOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"admin_id" | "username" | "password" | "roles" | "email" | "created_at" | "updated_at", ExtArgs["result"]["admin"]>

  export type $adminPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "admin"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      admin_id: number
      username: string
      password: string
      roles: string[]
      email: string | null
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["admin"]>
    composites: {}
  }

  type adminGetPayload<S extends boolean | null | undefined | adminDefaultArgs> = $Result.GetResult<Prisma.$adminPayload, S>

  type adminCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<adminFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AdminCountAggregateInputType | true
    }

  export interface adminDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['admin'], meta: { name: 'admin' } }
    /**
     * Find zero or one Admin that matches the filter.
     * @param {adminFindUniqueArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends adminFindUniqueArgs>(args: SelectSubset<T, adminFindUniqueArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Admin that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {adminFindUniqueOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends adminFindUniqueOrThrowArgs>(args: SelectSubset<T, adminFindUniqueOrThrowArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminFindFirstArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends adminFindFirstArgs>(args?: SelectSubset<T, adminFindFirstArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminFindFirstOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends adminFindFirstOrThrowArgs>(args?: SelectSubset<T, adminFindFirstOrThrowArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Admins that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Admins
     * const admins = await prisma.admin.findMany()
     * 
     * // Get first 10 Admins
     * const admins = await prisma.admin.findMany({ take: 10 })
     * 
     * // Only select the `admin_id`
     * const adminWithAdmin_idOnly = await prisma.admin.findMany({ select: { admin_id: true } })
     * 
     */
    findMany<T extends adminFindManyArgs>(args?: SelectSubset<T, adminFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Admin.
     * @param {adminCreateArgs} args - Arguments to create a Admin.
     * @example
     * // Create one Admin
     * const Admin = await prisma.admin.create({
     *   data: {
     *     // ... data to create a Admin
     *   }
     * })
     * 
     */
    create<T extends adminCreateArgs>(args: SelectSubset<T, adminCreateArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Admins.
     * @param {adminCreateManyArgs} args - Arguments to create many Admins.
     * @example
     * // Create many Admins
     * const admin = await prisma.admin.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends adminCreateManyArgs>(args?: SelectSubset<T, adminCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Admins and returns the data saved in the database.
     * @param {adminCreateManyAndReturnArgs} args - Arguments to create many Admins.
     * @example
     * // Create many Admins
     * const admin = await prisma.admin.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Admins and only return the `admin_id`
     * const adminWithAdmin_idOnly = await prisma.admin.createManyAndReturn({
     *   select: { admin_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends adminCreateManyAndReturnArgs>(args?: SelectSubset<T, adminCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Admin.
     * @param {adminDeleteArgs} args - Arguments to delete one Admin.
     * @example
     * // Delete one Admin
     * const Admin = await prisma.admin.delete({
     *   where: {
     *     // ... filter to delete one Admin
     *   }
     * })
     * 
     */
    delete<T extends adminDeleteArgs>(args: SelectSubset<T, adminDeleteArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Admin.
     * @param {adminUpdateArgs} args - Arguments to update one Admin.
     * @example
     * // Update one Admin
     * const admin = await prisma.admin.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends adminUpdateArgs>(args: SelectSubset<T, adminUpdateArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Admins.
     * @param {adminDeleteManyArgs} args - Arguments to filter Admins to delete.
     * @example
     * // Delete a few Admins
     * const { count } = await prisma.admin.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends adminDeleteManyArgs>(args?: SelectSubset<T, adminDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Admins
     * const admin = await prisma.admin.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends adminUpdateManyArgs>(args: SelectSubset<T, adminUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Admins and returns the data updated in the database.
     * @param {adminUpdateManyAndReturnArgs} args - Arguments to update many Admins.
     * @example
     * // Update many Admins
     * const admin = await prisma.admin.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Admins and only return the `admin_id`
     * const adminWithAdmin_idOnly = await prisma.admin.updateManyAndReturn({
     *   select: { admin_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends adminUpdateManyAndReturnArgs>(args: SelectSubset<T, adminUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Admin.
     * @param {adminUpsertArgs} args - Arguments to update or create a Admin.
     * @example
     * // Update or create a Admin
     * const admin = await prisma.admin.upsert({
     *   create: {
     *     // ... data to create a Admin
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Admin we want to update
     *   }
     * })
     */
    upsert<T extends adminUpsertArgs>(args: SelectSubset<T, adminUpsertArgs<ExtArgs>>): Prisma__adminClient<$Result.GetResult<Prisma.$adminPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminCountArgs} args - Arguments to filter Admins to count.
     * @example
     * // Count the number of Admins
     * const count = await prisma.admin.count({
     *   where: {
     *     // ... the filter for the Admins we want to count
     *   }
     * })
    **/
    count<T extends adminCountArgs>(
      args?: Subset<T, adminCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AdminCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AdminAggregateArgs>(args: Subset<T, AdminAggregateArgs>): Prisma.PrismaPromise<GetAdminAggregateType<T>>

    /**
     * Group by Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {adminGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends adminGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: adminGroupByArgs['orderBy'] }
        : { orderBy?: adminGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, adminGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAdminGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the admin model
   */
  readonly fields: adminFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for admin.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__adminClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the admin model
   */
  interface adminFieldRefs {
    readonly admin_id: FieldRef<"admin", 'Int'>
    readonly username: FieldRef<"admin", 'String'>
    readonly password: FieldRef<"admin", 'String'>
    readonly roles: FieldRef<"admin", 'String[]'>
    readonly email: FieldRef<"admin", 'String'>
    readonly created_at: FieldRef<"admin", 'DateTime'>
    readonly updated_at: FieldRef<"admin", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * admin findUnique
   */
  export type adminFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter, which admin to fetch.
     */
    where: adminWhereUniqueInput
  }

  /**
   * admin findUniqueOrThrow
   */
  export type adminFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter, which admin to fetch.
     */
    where: adminWhereUniqueInput
  }

  /**
   * admin findFirst
   */
  export type adminFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter, which admin to fetch.
     */
    where?: adminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of admins to fetch.
     */
    orderBy?: adminOrderByWithRelationInput | adminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for admins.
     */
    cursor?: adminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * admin findFirstOrThrow
   */
  export type adminFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter, which admin to fetch.
     */
    where?: adminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of admins to fetch.
     */
    orderBy?: adminOrderByWithRelationInput | adminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for admins.
     */
    cursor?: adminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * admin findMany
   */
  export type adminFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter, which admins to fetch.
     */
    where?: adminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of admins to fetch.
     */
    orderBy?: adminOrderByWithRelationInput | adminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing admins.
     */
    cursor?: adminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` admins.
     */
    skip?: number
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * admin create
   */
  export type adminCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * The data needed to create a admin.
     */
    data: XOR<adminCreateInput, adminUncheckedCreateInput>
  }

  /**
   * admin createMany
   */
  export type adminCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many admins.
     */
    data: adminCreateManyInput | adminCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * admin createManyAndReturn
   */
  export type adminCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * The data used to create many admins.
     */
    data: adminCreateManyInput | adminCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * admin update
   */
  export type adminUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * The data needed to update a admin.
     */
    data: XOR<adminUpdateInput, adminUncheckedUpdateInput>
    /**
     * Choose, which admin to update.
     */
    where: adminWhereUniqueInput
  }

  /**
   * admin updateMany
   */
  export type adminUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update admins.
     */
    data: XOR<adminUpdateManyMutationInput, adminUncheckedUpdateManyInput>
    /**
     * Filter which admins to update
     */
    where?: adminWhereInput
    /**
     * Limit how many admins to update.
     */
    limit?: number
  }

  /**
   * admin updateManyAndReturn
   */
  export type adminUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * The data used to update admins.
     */
    data: XOR<adminUpdateManyMutationInput, adminUncheckedUpdateManyInput>
    /**
     * Filter which admins to update
     */
    where?: adminWhereInput
    /**
     * Limit how many admins to update.
     */
    limit?: number
  }

  /**
   * admin upsert
   */
  export type adminUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * The filter to search for the admin to update in case it exists.
     */
    where: adminWhereUniqueInput
    /**
     * In case the admin found by the `where` argument doesn't exist, create a new admin with this data.
     */
    create: XOR<adminCreateInput, adminUncheckedCreateInput>
    /**
     * In case the admin was found with the provided `where` argument, update it with this data.
     */
    update: XOR<adminUpdateInput, adminUncheckedUpdateInput>
  }

  /**
   * admin delete
   */
  export type adminDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
    /**
     * Filter which admin to delete.
     */
    where: adminWhereUniqueInput
  }

  /**
   * admin deleteMany
   */
  export type adminDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which admins to delete
     */
    where?: adminWhereInput
    /**
     * Limit how many admins to delete.
     */
    limit?: number
  }

  /**
   * admin without action
   */
  export type adminDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the admin
     */
    select?: adminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the admin
     */
    omit?: adminOmit<ExtArgs> | null
  }


  /**
   * Model credit
   */

  export type AggregateCredit = {
    _count: CreditCountAggregateOutputType | null
    _avg: CreditAvgAggregateOutputType | null
    _sum: CreditSumAggregateOutputType | null
    _min: CreditMinAggregateOutputType | null
    _max: CreditMaxAggregateOutputType | null
  }

  export type CreditAvgAggregateOutputType = {
    credit_id: number | null
    customer_id: number | null
    credit_amount: number | null
    total_credit_limit: number | null
    available_credit_limit: number | null
  }

  export type CreditSumAggregateOutputType = {
    credit_id: number | null
    customer_id: number | null
    credit_amount: number | null
    total_credit_limit: number | null
    available_credit_limit: number | null
  }

  export type CreditMinAggregateOutputType = {
    credit_id: number | null
    customer_id: number | null
    due_date: Date | null
    credit_amount: number | null
    status: $Enums.credit_status_enum | null
    total_credit_limit: number | null
    available_credit_limit: number | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type CreditMaxAggregateOutputType = {
    credit_id: number | null
    customer_id: number | null
    due_date: Date | null
    credit_amount: number | null
    status: $Enums.credit_status_enum | null
    total_credit_limit: number | null
    available_credit_limit: number | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type CreditCountAggregateOutputType = {
    credit_id: number
    customer_id: number
    due_date: number
    credit_amount: number
    status: number
    total_credit_limit: number
    available_credit_limit: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type CreditAvgAggregateInputType = {
    credit_id?: true
    customer_id?: true
    credit_amount?: true
    total_credit_limit?: true
    available_credit_limit?: true
  }

  export type CreditSumAggregateInputType = {
    credit_id?: true
    customer_id?: true
    credit_amount?: true
    total_credit_limit?: true
    available_credit_limit?: true
  }

  export type CreditMinAggregateInputType = {
    credit_id?: true
    customer_id?: true
    due_date?: true
    credit_amount?: true
    status?: true
    total_credit_limit?: true
    available_credit_limit?: true
    created_at?: true
    updated_at?: true
  }

  export type CreditMaxAggregateInputType = {
    credit_id?: true
    customer_id?: true
    due_date?: true
    credit_amount?: true
    status?: true
    total_credit_limit?: true
    available_credit_limit?: true
    created_at?: true
    updated_at?: true
  }

  export type CreditCountAggregateInputType = {
    credit_id?: true
    customer_id?: true
    due_date?: true
    credit_amount?: true
    status?: true
    total_credit_limit?: true
    available_credit_limit?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type CreditAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which credit to aggregate.
     */
    where?: creditWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of credits to fetch.
     */
    orderBy?: creditOrderByWithRelationInput | creditOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: creditWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` credits from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` credits.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned credits
    **/
    _count?: true | CreditCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CreditAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CreditSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CreditMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CreditMaxAggregateInputType
  }

  export type GetCreditAggregateType<T extends CreditAggregateArgs> = {
        [P in keyof T & keyof AggregateCredit]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCredit[P]>
      : GetScalarType<T[P], AggregateCredit[P]>
  }




  export type creditGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: creditWhereInput
    orderBy?: creditOrderByWithAggregationInput | creditOrderByWithAggregationInput[]
    by: CreditScalarFieldEnum[] | CreditScalarFieldEnum
    having?: creditScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CreditCountAggregateInputType | true
    _avg?: CreditAvgAggregateInputType
    _sum?: CreditSumAggregateInputType
    _min?: CreditMinAggregateInputType
    _max?: CreditMaxAggregateInputType
  }

  export type CreditGroupByOutputType = {
    credit_id: number
    customer_id: number | null
    due_date: Date | null
    credit_amount: number | null
    status: $Enums.credit_status_enum | null
    total_credit_limit: number | null
    available_credit_limit: number | null
    created_at: Date | null
    updated_at: Date | null
    _count: CreditCountAggregateOutputType | null
    _avg: CreditAvgAggregateOutputType | null
    _sum: CreditSumAggregateOutputType | null
    _min: CreditMinAggregateOutputType | null
    _max: CreditMaxAggregateOutputType | null
  }

  type GetCreditGroupByPayload<T extends creditGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CreditGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CreditGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CreditGroupByOutputType[P]>
            : GetScalarType<T[P], CreditGroupByOutputType[P]>
        }
      >
    >


  export type creditSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    credit_id?: boolean
    customer_id?: boolean
    due_date?: boolean
    credit_amount?: boolean
    status?: boolean
    total_credit_limit?: boolean
    available_credit_limit?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | credit$customerArgs<ExtArgs>
  }, ExtArgs["result"]["credit"]>

  export type creditSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    credit_id?: boolean
    customer_id?: boolean
    due_date?: boolean
    credit_amount?: boolean
    status?: boolean
    total_credit_limit?: boolean
    available_credit_limit?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | credit$customerArgs<ExtArgs>
  }, ExtArgs["result"]["credit"]>

  export type creditSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    credit_id?: boolean
    customer_id?: boolean
    due_date?: boolean
    credit_amount?: boolean
    status?: boolean
    total_credit_limit?: boolean
    available_credit_limit?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | credit$customerArgs<ExtArgs>
  }, ExtArgs["result"]["credit"]>

  export type creditSelectScalar = {
    credit_id?: boolean
    customer_id?: boolean
    due_date?: boolean
    credit_amount?: boolean
    status?: boolean
    total_credit_limit?: boolean
    available_credit_limit?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type creditOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"credit_id" | "customer_id" | "due_date" | "credit_amount" | "status" | "total_credit_limit" | "available_credit_limit" | "created_at" | "updated_at", ExtArgs["result"]["credit"]>
  export type creditInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | credit$customerArgs<ExtArgs>
  }
  export type creditIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | credit$customerArgs<ExtArgs>
  }
  export type creditIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | credit$customerArgs<ExtArgs>
  }

  export type $creditPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "credit"
    objects: {
      customer: Prisma.$customerPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      credit_id: number
      customer_id: number | null
      due_date: Date | null
      credit_amount: number | null
      status: $Enums.credit_status_enum | null
      total_credit_limit: number | null
      available_credit_limit: number | null
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["credit"]>
    composites: {}
  }

  type creditGetPayload<S extends boolean | null | undefined | creditDefaultArgs> = $Result.GetResult<Prisma.$creditPayload, S>

  type creditCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<creditFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CreditCountAggregateInputType | true
    }

  export interface creditDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['credit'], meta: { name: 'credit' } }
    /**
     * Find zero or one Credit that matches the filter.
     * @param {creditFindUniqueArgs} args - Arguments to find a Credit
     * @example
     * // Get one Credit
     * const credit = await prisma.credit.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends creditFindUniqueArgs>(args: SelectSubset<T, creditFindUniqueArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Credit that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {creditFindUniqueOrThrowArgs} args - Arguments to find a Credit
     * @example
     * // Get one Credit
     * const credit = await prisma.credit.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends creditFindUniqueOrThrowArgs>(args: SelectSubset<T, creditFindUniqueOrThrowArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Credit that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditFindFirstArgs} args - Arguments to find a Credit
     * @example
     * // Get one Credit
     * const credit = await prisma.credit.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends creditFindFirstArgs>(args?: SelectSubset<T, creditFindFirstArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Credit that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditFindFirstOrThrowArgs} args - Arguments to find a Credit
     * @example
     * // Get one Credit
     * const credit = await prisma.credit.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends creditFindFirstOrThrowArgs>(args?: SelectSubset<T, creditFindFirstOrThrowArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Credits that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Credits
     * const credits = await prisma.credit.findMany()
     * 
     * // Get first 10 Credits
     * const credits = await prisma.credit.findMany({ take: 10 })
     * 
     * // Only select the `credit_id`
     * const creditWithCredit_idOnly = await prisma.credit.findMany({ select: { credit_id: true } })
     * 
     */
    findMany<T extends creditFindManyArgs>(args?: SelectSubset<T, creditFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Credit.
     * @param {creditCreateArgs} args - Arguments to create a Credit.
     * @example
     * // Create one Credit
     * const Credit = await prisma.credit.create({
     *   data: {
     *     // ... data to create a Credit
     *   }
     * })
     * 
     */
    create<T extends creditCreateArgs>(args: SelectSubset<T, creditCreateArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Credits.
     * @param {creditCreateManyArgs} args - Arguments to create many Credits.
     * @example
     * // Create many Credits
     * const credit = await prisma.credit.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends creditCreateManyArgs>(args?: SelectSubset<T, creditCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Credits and returns the data saved in the database.
     * @param {creditCreateManyAndReturnArgs} args - Arguments to create many Credits.
     * @example
     * // Create many Credits
     * const credit = await prisma.credit.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Credits and only return the `credit_id`
     * const creditWithCredit_idOnly = await prisma.credit.createManyAndReturn({
     *   select: { credit_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends creditCreateManyAndReturnArgs>(args?: SelectSubset<T, creditCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Credit.
     * @param {creditDeleteArgs} args - Arguments to delete one Credit.
     * @example
     * // Delete one Credit
     * const Credit = await prisma.credit.delete({
     *   where: {
     *     // ... filter to delete one Credit
     *   }
     * })
     * 
     */
    delete<T extends creditDeleteArgs>(args: SelectSubset<T, creditDeleteArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Credit.
     * @param {creditUpdateArgs} args - Arguments to update one Credit.
     * @example
     * // Update one Credit
     * const credit = await prisma.credit.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends creditUpdateArgs>(args: SelectSubset<T, creditUpdateArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Credits.
     * @param {creditDeleteManyArgs} args - Arguments to filter Credits to delete.
     * @example
     * // Delete a few Credits
     * const { count } = await prisma.credit.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends creditDeleteManyArgs>(args?: SelectSubset<T, creditDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Credits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Credits
     * const credit = await prisma.credit.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends creditUpdateManyArgs>(args: SelectSubset<T, creditUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Credits and returns the data updated in the database.
     * @param {creditUpdateManyAndReturnArgs} args - Arguments to update many Credits.
     * @example
     * // Update many Credits
     * const credit = await prisma.credit.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Credits and only return the `credit_id`
     * const creditWithCredit_idOnly = await prisma.credit.updateManyAndReturn({
     *   select: { credit_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends creditUpdateManyAndReturnArgs>(args: SelectSubset<T, creditUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Credit.
     * @param {creditUpsertArgs} args - Arguments to update or create a Credit.
     * @example
     * // Update or create a Credit
     * const credit = await prisma.credit.upsert({
     *   create: {
     *     // ... data to create a Credit
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Credit we want to update
     *   }
     * })
     */
    upsert<T extends creditUpsertArgs>(args: SelectSubset<T, creditUpsertArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Credits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditCountArgs} args - Arguments to filter Credits to count.
     * @example
     * // Count the number of Credits
     * const count = await prisma.credit.count({
     *   where: {
     *     // ... the filter for the Credits we want to count
     *   }
     * })
    **/
    count<T extends creditCountArgs>(
      args?: Subset<T, creditCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CreditCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Credit.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CreditAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CreditAggregateArgs>(args: Subset<T, CreditAggregateArgs>): Prisma.PrismaPromise<GetCreditAggregateType<T>>

    /**
     * Group by Credit.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {creditGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends creditGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: creditGroupByArgs['orderBy'] }
        : { orderBy?: creditGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, creditGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCreditGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the credit model
   */
  readonly fields: creditFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for credit.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__creditClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    customer<T extends credit$customerArgs<ExtArgs> = {}>(args?: Subset<T, credit$customerArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the credit model
   */
  interface creditFieldRefs {
    readonly credit_id: FieldRef<"credit", 'Int'>
    readonly customer_id: FieldRef<"credit", 'Int'>
    readonly due_date: FieldRef<"credit", 'DateTime'>
    readonly credit_amount: FieldRef<"credit", 'Int'>
    readonly status: FieldRef<"credit", 'credit_status_enum'>
    readonly total_credit_limit: FieldRef<"credit", 'Int'>
    readonly available_credit_limit: FieldRef<"credit", 'Int'>
    readonly created_at: FieldRef<"credit", 'DateTime'>
    readonly updated_at: FieldRef<"credit", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * credit findUnique
   */
  export type creditFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter, which credit to fetch.
     */
    where: creditWhereUniqueInput
  }

  /**
   * credit findUniqueOrThrow
   */
  export type creditFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter, which credit to fetch.
     */
    where: creditWhereUniqueInput
  }

  /**
   * credit findFirst
   */
  export type creditFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter, which credit to fetch.
     */
    where?: creditWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of credits to fetch.
     */
    orderBy?: creditOrderByWithRelationInput | creditOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for credits.
     */
    cursor?: creditWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` credits from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` credits.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of credits.
     */
    distinct?: CreditScalarFieldEnum | CreditScalarFieldEnum[]
  }

  /**
   * credit findFirstOrThrow
   */
  export type creditFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter, which credit to fetch.
     */
    where?: creditWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of credits to fetch.
     */
    orderBy?: creditOrderByWithRelationInput | creditOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for credits.
     */
    cursor?: creditWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` credits from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` credits.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of credits.
     */
    distinct?: CreditScalarFieldEnum | CreditScalarFieldEnum[]
  }

  /**
   * credit findMany
   */
  export type creditFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter, which credits to fetch.
     */
    where?: creditWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of credits to fetch.
     */
    orderBy?: creditOrderByWithRelationInput | creditOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing credits.
     */
    cursor?: creditWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` credits from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` credits.
     */
    skip?: number
    distinct?: CreditScalarFieldEnum | CreditScalarFieldEnum[]
  }

  /**
   * credit create
   */
  export type creditCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * The data needed to create a credit.
     */
    data?: XOR<creditCreateInput, creditUncheckedCreateInput>
  }

  /**
   * credit createMany
   */
  export type creditCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many credits.
     */
    data: creditCreateManyInput | creditCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * credit createManyAndReturn
   */
  export type creditCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * The data used to create many credits.
     */
    data: creditCreateManyInput | creditCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * credit update
   */
  export type creditUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * The data needed to update a credit.
     */
    data: XOR<creditUpdateInput, creditUncheckedUpdateInput>
    /**
     * Choose, which credit to update.
     */
    where: creditWhereUniqueInput
  }

  /**
   * credit updateMany
   */
  export type creditUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update credits.
     */
    data: XOR<creditUpdateManyMutationInput, creditUncheckedUpdateManyInput>
    /**
     * Filter which credits to update
     */
    where?: creditWhereInput
    /**
     * Limit how many credits to update.
     */
    limit?: number
  }

  /**
   * credit updateManyAndReturn
   */
  export type creditUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * The data used to update credits.
     */
    data: XOR<creditUpdateManyMutationInput, creditUncheckedUpdateManyInput>
    /**
     * Filter which credits to update
     */
    where?: creditWhereInput
    /**
     * Limit how many credits to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * credit upsert
   */
  export type creditUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * The filter to search for the credit to update in case it exists.
     */
    where: creditWhereUniqueInput
    /**
     * In case the credit found by the `where` argument doesn't exist, create a new credit with this data.
     */
    create: XOR<creditCreateInput, creditUncheckedCreateInput>
    /**
     * In case the credit was found with the provided `where` argument, update it with this data.
     */
    update: XOR<creditUpdateInput, creditUncheckedUpdateInput>
  }

  /**
   * credit delete
   */
  export type creditDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    /**
     * Filter which credit to delete.
     */
    where: creditWhereUniqueInput
  }

  /**
   * credit deleteMany
   */
  export type creditDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which credits to delete
     */
    where?: creditWhereInput
    /**
     * Limit how many credits to delete.
     */
    limit?: number
  }

  /**
   * credit.customer
   */
  export type credit$customerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    where?: customerWhereInput
  }

  /**
   * credit without action
   */
  export type creditDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
  }


  /**
   * Model customer
   */

  export type AggregateCustomer = {
    _count: CustomerCountAggregateOutputType | null
    _avg: CustomerAvgAggregateOutputType | null
    _sum: CustomerSumAggregateOutputType | null
    _min: CustomerMinAggregateOutputType | null
    _max: CustomerMaxAggregateOutputType | null
  }

  export type CustomerAvgAggregateOutputType = {
    customer_id: number | null
    credit_limit: Decimal | null
    remaining_credit: Decimal | null
  }

  export type CustomerSumAggregateOutputType = {
    customer_id: number | null
    credit_limit: Decimal | null
    remaining_credit: Decimal | null
  }

  export type CustomerMinAggregateOutputType = {
    customer_id: number | null
    username: string | null
    password: string | null
    email: string | null
    mobile_number: string | null
    credit_limit: Decimal | null
    remaining_credit: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type CustomerMaxAggregateOutputType = {
    customer_id: number | null
    username: string | null
    password: string | null
    email: string | null
    mobile_number: string | null
    credit_limit: Decimal | null
    remaining_credit: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type CustomerCountAggregateOutputType = {
    customer_id: number
    username: number
    password: number
    email: number
    mobile_number: number
    credit_limit: number
    remaining_credit: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type CustomerAvgAggregateInputType = {
    customer_id?: true
    credit_limit?: true
    remaining_credit?: true
  }

  export type CustomerSumAggregateInputType = {
    customer_id?: true
    credit_limit?: true
    remaining_credit?: true
  }

  export type CustomerMinAggregateInputType = {
    customer_id?: true
    username?: true
    password?: true
    email?: true
    mobile_number?: true
    credit_limit?: true
    remaining_credit?: true
    created_at?: true
    updated_at?: true
  }

  export type CustomerMaxAggregateInputType = {
    customer_id?: true
    username?: true
    password?: true
    email?: true
    mobile_number?: true
    credit_limit?: true
    remaining_credit?: true
    created_at?: true
    updated_at?: true
  }

  export type CustomerCountAggregateInputType = {
    customer_id?: true
    username?: true
    password?: true
    email?: true
    mobile_number?: true
    credit_limit?: true
    remaining_credit?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type CustomerAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which customer to aggregate.
     */
    where?: customerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     */
    orderBy?: customerOrderByWithRelationInput | customerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: customerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned customers
    **/
    _count?: true | CustomerCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CustomerAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CustomerSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CustomerMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CustomerMaxAggregateInputType
  }

  export type GetCustomerAggregateType<T extends CustomerAggregateArgs> = {
        [P in keyof T & keyof AggregateCustomer]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCustomer[P]>
      : GetScalarType<T[P], AggregateCustomer[P]>
  }




  export type customerGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: customerWhereInput
    orderBy?: customerOrderByWithAggregationInput | customerOrderByWithAggregationInput[]
    by: CustomerScalarFieldEnum[] | CustomerScalarFieldEnum
    having?: customerScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CustomerCountAggregateInputType | true
    _avg?: CustomerAvgAggregateInputType
    _sum?: CustomerSumAggregateInputType
    _min?: CustomerMinAggregateInputType
    _max?: CustomerMaxAggregateInputType
  }

  export type CustomerGroupByOutputType = {
    customer_id: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit: Decimal | null
    remaining_credit: Decimal | null
    created_at: Date | null
    updated_at: Date | null
    _count: CustomerCountAggregateOutputType | null
    _avg: CustomerAvgAggregateOutputType | null
    _sum: CustomerSumAggregateOutputType | null
    _min: CustomerMinAggregateOutputType | null
    _max: CustomerMaxAggregateOutputType | null
  }

  type GetCustomerGroupByPayload<T extends customerGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CustomerGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CustomerGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CustomerGroupByOutputType[P]>
            : GetScalarType<T[P], CustomerGroupByOutputType[P]>
        }
      >
    >


  export type customerSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    customer_id?: boolean
    username?: boolean
    password?: boolean
    email?: boolean
    mobile_number?: boolean
    credit_limit?: boolean
    remaining_credit?: boolean
    created_at?: boolean
    updated_at?: boolean
    credit?: boolean | customer$creditArgs<ExtArgs>
    notification?: boolean | customer$notificationArgs<ExtArgs>
    order?: boolean | customer$orderArgs<ExtArgs>
    quotation?: boolean | customer$quotationArgs<ExtArgs>
    _count?: boolean | CustomerCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["customer"]>

  export type customerSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    customer_id?: boolean
    username?: boolean
    password?: boolean
    email?: boolean
    mobile_number?: boolean
    credit_limit?: boolean
    remaining_credit?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["customer"]>

  export type customerSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    customer_id?: boolean
    username?: boolean
    password?: boolean
    email?: boolean
    mobile_number?: boolean
    credit_limit?: boolean
    remaining_credit?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["customer"]>

  export type customerSelectScalar = {
    customer_id?: boolean
    username?: boolean
    password?: boolean
    email?: boolean
    mobile_number?: boolean
    credit_limit?: boolean
    remaining_credit?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type customerOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"customer_id" | "username" | "password" | "email" | "mobile_number" | "credit_limit" | "remaining_credit" | "created_at" | "updated_at", ExtArgs["result"]["customer"]>
  export type customerInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    credit?: boolean | customer$creditArgs<ExtArgs>
    notification?: boolean | customer$notificationArgs<ExtArgs>
    order?: boolean | customer$orderArgs<ExtArgs>
    quotation?: boolean | customer$quotationArgs<ExtArgs>
    _count?: boolean | CustomerCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type customerIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type customerIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $customerPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "customer"
    objects: {
      credit: Prisma.$creditPayload<ExtArgs> | null
      notification: Prisma.$notificationPayload<ExtArgs>[]
      order: Prisma.$orderPayload<ExtArgs>[]
      quotation: Prisma.$quotationPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      customer_id: number
      username: string
      password: string
      email: string
      mobile_number: string
      credit_limit: Prisma.Decimal | null
      remaining_credit: Prisma.Decimal | null
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["customer"]>
    composites: {}
  }

  type customerGetPayload<S extends boolean | null | undefined | customerDefaultArgs> = $Result.GetResult<Prisma.$customerPayload, S>

  type customerCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<customerFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CustomerCountAggregateInputType | true
    }

  export interface customerDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['customer'], meta: { name: 'customer' } }
    /**
     * Find zero or one Customer that matches the filter.
     * @param {customerFindUniqueArgs} args - Arguments to find a Customer
     * @example
     * // Get one Customer
     * const customer = await prisma.customer.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends customerFindUniqueArgs>(args: SelectSubset<T, customerFindUniqueArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Customer that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {customerFindUniqueOrThrowArgs} args - Arguments to find a Customer
     * @example
     * // Get one Customer
     * const customer = await prisma.customer.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends customerFindUniqueOrThrowArgs>(args: SelectSubset<T, customerFindUniqueOrThrowArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Customer that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerFindFirstArgs} args - Arguments to find a Customer
     * @example
     * // Get one Customer
     * const customer = await prisma.customer.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends customerFindFirstArgs>(args?: SelectSubset<T, customerFindFirstArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Customer that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerFindFirstOrThrowArgs} args - Arguments to find a Customer
     * @example
     * // Get one Customer
     * const customer = await prisma.customer.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends customerFindFirstOrThrowArgs>(args?: SelectSubset<T, customerFindFirstOrThrowArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Customers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Customers
     * const customers = await prisma.customer.findMany()
     * 
     * // Get first 10 Customers
     * const customers = await prisma.customer.findMany({ take: 10 })
     * 
     * // Only select the `customer_id`
     * const customerWithCustomer_idOnly = await prisma.customer.findMany({ select: { customer_id: true } })
     * 
     */
    findMany<T extends customerFindManyArgs>(args?: SelectSubset<T, customerFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Customer.
     * @param {customerCreateArgs} args - Arguments to create a Customer.
     * @example
     * // Create one Customer
     * const Customer = await prisma.customer.create({
     *   data: {
     *     // ... data to create a Customer
     *   }
     * })
     * 
     */
    create<T extends customerCreateArgs>(args: SelectSubset<T, customerCreateArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Customers.
     * @param {customerCreateManyArgs} args - Arguments to create many Customers.
     * @example
     * // Create many Customers
     * const customer = await prisma.customer.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends customerCreateManyArgs>(args?: SelectSubset<T, customerCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Customers and returns the data saved in the database.
     * @param {customerCreateManyAndReturnArgs} args - Arguments to create many Customers.
     * @example
     * // Create many Customers
     * const customer = await prisma.customer.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Customers and only return the `customer_id`
     * const customerWithCustomer_idOnly = await prisma.customer.createManyAndReturn({
     *   select: { customer_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends customerCreateManyAndReturnArgs>(args?: SelectSubset<T, customerCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Customer.
     * @param {customerDeleteArgs} args - Arguments to delete one Customer.
     * @example
     * // Delete one Customer
     * const Customer = await prisma.customer.delete({
     *   where: {
     *     // ... filter to delete one Customer
     *   }
     * })
     * 
     */
    delete<T extends customerDeleteArgs>(args: SelectSubset<T, customerDeleteArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Customer.
     * @param {customerUpdateArgs} args - Arguments to update one Customer.
     * @example
     * // Update one Customer
     * const customer = await prisma.customer.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends customerUpdateArgs>(args: SelectSubset<T, customerUpdateArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Customers.
     * @param {customerDeleteManyArgs} args - Arguments to filter Customers to delete.
     * @example
     * // Delete a few Customers
     * const { count } = await prisma.customer.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends customerDeleteManyArgs>(args?: SelectSubset<T, customerDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Customers
     * const customer = await prisma.customer.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends customerUpdateManyArgs>(args: SelectSubset<T, customerUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Customers and returns the data updated in the database.
     * @param {customerUpdateManyAndReturnArgs} args - Arguments to update many Customers.
     * @example
     * // Update many Customers
     * const customer = await prisma.customer.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Customers and only return the `customer_id`
     * const customerWithCustomer_idOnly = await prisma.customer.updateManyAndReturn({
     *   select: { customer_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends customerUpdateManyAndReturnArgs>(args: SelectSubset<T, customerUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Customer.
     * @param {customerUpsertArgs} args - Arguments to update or create a Customer.
     * @example
     * // Update or create a Customer
     * const customer = await prisma.customer.upsert({
     *   create: {
     *     // ... data to create a Customer
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Customer we want to update
     *   }
     * })
     */
    upsert<T extends customerUpsertArgs>(args: SelectSubset<T, customerUpsertArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerCountArgs} args - Arguments to filter Customers to count.
     * @example
     * // Count the number of Customers
     * const count = await prisma.customer.count({
     *   where: {
     *     // ... the filter for the Customers we want to count
     *   }
     * })
    **/
    count<T extends customerCountArgs>(
      args?: Subset<T, customerCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CustomerCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Customer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomerAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CustomerAggregateArgs>(args: Subset<T, CustomerAggregateArgs>): Prisma.PrismaPromise<GetCustomerAggregateType<T>>

    /**
     * Group by Customer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customerGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends customerGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: customerGroupByArgs['orderBy'] }
        : { orderBy?: customerGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, customerGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCustomerGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the customer model
   */
  readonly fields: customerFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for customer.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__customerClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    credit<T extends customer$creditArgs<ExtArgs> = {}>(args?: Subset<T, customer$creditArgs<ExtArgs>>): Prisma__creditClient<$Result.GetResult<Prisma.$creditPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    notification<T extends customer$notificationArgs<ExtArgs> = {}>(args?: Subset<T, customer$notificationArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    order<T extends customer$orderArgs<ExtArgs> = {}>(args?: Subset<T, customer$orderArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    quotation<T extends customer$quotationArgs<ExtArgs> = {}>(args?: Subset<T, customer$quotationArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the customer model
   */
  interface customerFieldRefs {
    readonly customer_id: FieldRef<"customer", 'Int'>
    readonly username: FieldRef<"customer", 'String'>
    readonly password: FieldRef<"customer", 'String'>
    readonly email: FieldRef<"customer", 'String'>
    readonly mobile_number: FieldRef<"customer", 'String'>
    readonly credit_limit: FieldRef<"customer", 'Decimal'>
    readonly remaining_credit: FieldRef<"customer", 'Decimal'>
    readonly created_at: FieldRef<"customer", 'DateTime'>
    readonly updated_at: FieldRef<"customer", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * customer findUnique
   */
  export type customerFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter, which customer to fetch.
     */
    where: customerWhereUniqueInput
  }

  /**
   * customer findUniqueOrThrow
   */
  export type customerFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter, which customer to fetch.
     */
    where: customerWhereUniqueInput
  }

  /**
   * customer findFirst
   */
  export type customerFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter, which customer to fetch.
     */
    where?: customerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     */
    orderBy?: customerOrderByWithRelationInput | customerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for customers.
     */
    cursor?: customerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of customers.
     */
    distinct?: CustomerScalarFieldEnum | CustomerScalarFieldEnum[]
  }

  /**
   * customer findFirstOrThrow
   */
  export type customerFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter, which customer to fetch.
     */
    where?: customerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     */
    orderBy?: customerOrderByWithRelationInput | customerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for customers.
     */
    cursor?: customerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of customers.
     */
    distinct?: CustomerScalarFieldEnum | CustomerScalarFieldEnum[]
  }

  /**
   * customer findMany
   */
  export type customerFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter, which customers to fetch.
     */
    where?: customerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     */
    orderBy?: customerOrderByWithRelationInput | customerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing customers.
     */
    cursor?: customerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     */
    skip?: number
    distinct?: CustomerScalarFieldEnum | CustomerScalarFieldEnum[]
  }

  /**
   * customer create
   */
  export type customerCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * The data needed to create a customer.
     */
    data: XOR<customerCreateInput, customerUncheckedCreateInput>
  }

  /**
   * customer createMany
   */
  export type customerCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many customers.
     */
    data: customerCreateManyInput | customerCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * customer createManyAndReturn
   */
  export type customerCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * The data used to create many customers.
     */
    data: customerCreateManyInput | customerCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * customer update
   */
  export type customerUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * The data needed to update a customer.
     */
    data: XOR<customerUpdateInput, customerUncheckedUpdateInput>
    /**
     * Choose, which customer to update.
     */
    where: customerWhereUniqueInput
  }

  /**
   * customer updateMany
   */
  export type customerUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update customers.
     */
    data: XOR<customerUpdateManyMutationInput, customerUncheckedUpdateManyInput>
    /**
     * Filter which customers to update
     */
    where?: customerWhereInput
    /**
     * Limit how many customers to update.
     */
    limit?: number
  }

  /**
   * customer updateManyAndReturn
   */
  export type customerUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * The data used to update customers.
     */
    data: XOR<customerUpdateManyMutationInput, customerUncheckedUpdateManyInput>
    /**
     * Filter which customers to update
     */
    where?: customerWhereInput
    /**
     * Limit how many customers to update.
     */
    limit?: number
  }

  /**
   * customer upsert
   */
  export type customerUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * The filter to search for the customer to update in case it exists.
     */
    where: customerWhereUniqueInput
    /**
     * In case the customer found by the `where` argument doesn't exist, create a new customer with this data.
     */
    create: XOR<customerCreateInput, customerUncheckedCreateInput>
    /**
     * In case the customer was found with the provided `where` argument, update it with this data.
     */
    update: XOR<customerUpdateInput, customerUncheckedUpdateInput>
  }

  /**
   * customer delete
   */
  export type customerDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    /**
     * Filter which customer to delete.
     */
    where: customerWhereUniqueInput
  }

  /**
   * customer deleteMany
   */
  export type customerDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which customers to delete
     */
    where?: customerWhereInput
    /**
     * Limit how many customers to delete.
     */
    limit?: number
  }

  /**
   * customer.credit
   */
  export type customer$creditArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the credit
     */
    select?: creditSelect<ExtArgs> | null
    /**
     * Omit specific fields from the credit
     */
    omit?: creditOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: creditInclude<ExtArgs> | null
    where?: creditWhereInput
  }

  /**
   * customer.notification
   */
  export type customer$notificationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    where?: notificationWhereInput
    orderBy?: notificationOrderByWithRelationInput | notificationOrderByWithRelationInput[]
    cursor?: notificationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * customer.order
   */
  export type customer$orderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    where?: orderWhereInput
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    cursor?: orderWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * customer.quotation
   */
  export type customer$quotationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    where?: quotationWhereInput
    orderBy?: quotationOrderByWithRelationInput | quotationOrderByWithRelationInput[]
    cursor?: quotationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: QuotationScalarFieldEnum | QuotationScalarFieldEnum[]
  }

  /**
   * customer without action
   */
  export type customerDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
  }


  /**
   * Model inventory_inflow_outflow
   */

  export type AggregateInventory_inflow_outflow = {
    _count: Inventory_inflow_outflowCountAggregateOutputType | null
    _avg: Inventory_inflow_outflowAvgAggregateOutputType | null
    _sum: Inventory_inflow_outflowSumAggregateOutputType | null
    _min: Inventory_inflow_outflowMinAggregateOutputType | null
    _max: Inventory_inflow_outflowMaxAggregateOutputType | null
  }

  export type Inventory_inflow_outflowAvgAggregateOutputType = {
    id: number | null
    product_id: number | null
    quantity: number | null
  }

  export type Inventory_inflow_outflowSumAggregateOutputType = {
    id: number | null
    product_id: number | null
    quantity: number | null
  }

  export type Inventory_inflow_outflowMinAggregateOutputType = {
    id: number | null
    product_id: number | null
    flow_direction: $Enums.flow_direction_enum | null
    quantity: number | null
    created_at: Date | null
  }

  export type Inventory_inflow_outflowMaxAggregateOutputType = {
    id: number | null
    product_id: number | null
    flow_direction: $Enums.flow_direction_enum | null
    quantity: number | null
    created_at: Date | null
  }

  export type Inventory_inflow_outflowCountAggregateOutputType = {
    id: number
    product_id: number
    flow_direction: number
    quantity: number
    created_at: number
    _all: number
  }


  export type Inventory_inflow_outflowAvgAggregateInputType = {
    id?: true
    product_id?: true
    quantity?: true
  }

  export type Inventory_inflow_outflowSumAggregateInputType = {
    id?: true
    product_id?: true
    quantity?: true
  }

  export type Inventory_inflow_outflowMinAggregateInputType = {
    id?: true
    product_id?: true
    flow_direction?: true
    quantity?: true
    created_at?: true
  }

  export type Inventory_inflow_outflowMaxAggregateInputType = {
    id?: true
    product_id?: true
    flow_direction?: true
    quantity?: true
    created_at?: true
  }

  export type Inventory_inflow_outflowCountAggregateInputType = {
    id?: true
    product_id?: true
    flow_direction?: true
    quantity?: true
    created_at?: true
    _all?: true
  }

  export type Inventory_inflow_outflowAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which inventory_inflow_outflow to aggregate.
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inventory_inflow_outflows to fetch.
     */
    orderBy?: inventory_inflow_outflowOrderByWithRelationInput | inventory_inflow_outflowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: inventory_inflow_outflowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inventory_inflow_outflows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inventory_inflow_outflows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned inventory_inflow_outflows
    **/
    _count?: true | Inventory_inflow_outflowCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Inventory_inflow_outflowAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Inventory_inflow_outflowSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Inventory_inflow_outflowMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Inventory_inflow_outflowMaxAggregateInputType
  }

  export type GetInventory_inflow_outflowAggregateType<T extends Inventory_inflow_outflowAggregateArgs> = {
        [P in keyof T & keyof AggregateInventory_inflow_outflow]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateInventory_inflow_outflow[P]>
      : GetScalarType<T[P], AggregateInventory_inflow_outflow[P]>
  }




  export type inventory_inflow_outflowGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: inventory_inflow_outflowWhereInput
    orderBy?: inventory_inflow_outflowOrderByWithAggregationInput | inventory_inflow_outflowOrderByWithAggregationInput[]
    by: Inventory_inflow_outflowScalarFieldEnum[] | Inventory_inflow_outflowScalarFieldEnum
    having?: inventory_inflow_outflowScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Inventory_inflow_outflowCountAggregateInputType | true
    _avg?: Inventory_inflow_outflowAvgAggregateInputType
    _sum?: Inventory_inflow_outflowSumAggregateInputType
    _min?: Inventory_inflow_outflowMinAggregateInputType
    _max?: Inventory_inflow_outflowMaxAggregateInputType
  }

  export type Inventory_inflow_outflowGroupByOutputType = {
    id: number
    product_id: number | null
    flow_direction: $Enums.flow_direction_enum | null
    quantity: number | null
    created_at: Date | null
    _count: Inventory_inflow_outflowCountAggregateOutputType | null
    _avg: Inventory_inflow_outflowAvgAggregateOutputType | null
    _sum: Inventory_inflow_outflowSumAggregateOutputType | null
    _min: Inventory_inflow_outflowMinAggregateOutputType | null
    _max: Inventory_inflow_outflowMaxAggregateOutputType | null
  }

  type GetInventory_inflow_outflowGroupByPayload<T extends inventory_inflow_outflowGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Inventory_inflow_outflowGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Inventory_inflow_outflowGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Inventory_inflow_outflowGroupByOutputType[P]>
            : GetScalarType<T[P], Inventory_inflow_outflowGroupByOutputType[P]>
        }
      >
    >


  export type inventory_inflow_outflowSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    product_id?: boolean
    flow_direction?: boolean
    quantity?: boolean
    created_at?: boolean
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }, ExtArgs["result"]["inventory_inflow_outflow"]>

  export type inventory_inflow_outflowSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    product_id?: boolean
    flow_direction?: boolean
    quantity?: boolean
    created_at?: boolean
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }, ExtArgs["result"]["inventory_inflow_outflow"]>

  export type inventory_inflow_outflowSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    product_id?: boolean
    flow_direction?: boolean
    quantity?: boolean
    created_at?: boolean
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }, ExtArgs["result"]["inventory_inflow_outflow"]>

  export type inventory_inflow_outflowSelectScalar = {
    id?: boolean
    product_id?: boolean
    flow_direction?: boolean
    quantity?: boolean
    created_at?: boolean
  }

  export type inventory_inflow_outflowOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "product_id" | "flow_direction" | "quantity" | "created_at", ExtArgs["result"]["inventory_inflow_outflow"]>
  export type inventory_inflow_outflowInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }
  export type inventory_inflow_outflowIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }
  export type inventory_inflow_outflowIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | inventory_inflow_outflow$productArgs<ExtArgs>
  }

  export type $inventory_inflow_outflowPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "inventory_inflow_outflow"
    objects: {
      product: Prisma.$productPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      product_id: number | null
      flow_direction: $Enums.flow_direction_enum | null
      quantity: number | null
      created_at: Date | null
    }, ExtArgs["result"]["inventory_inflow_outflow"]>
    composites: {}
  }

  type inventory_inflow_outflowGetPayload<S extends boolean | null | undefined | inventory_inflow_outflowDefaultArgs> = $Result.GetResult<Prisma.$inventory_inflow_outflowPayload, S>

  type inventory_inflow_outflowCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<inventory_inflow_outflowFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Inventory_inflow_outflowCountAggregateInputType | true
    }

  export interface inventory_inflow_outflowDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['inventory_inflow_outflow'], meta: { name: 'inventory_inflow_outflow' } }
    /**
     * Find zero or one Inventory_inflow_outflow that matches the filter.
     * @param {inventory_inflow_outflowFindUniqueArgs} args - Arguments to find a Inventory_inflow_outflow
     * @example
     * // Get one Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends inventory_inflow_outflowFindUniqueArgs>(args: SelectSubset<T, inventory_inflow_outflowFindUniqueArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Inventory_inflow_outflow that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {inventory_inflow_outflowFindUniqueOrThrowArgs} args - Arguments to find a Inventory_inflow_outflow
     * @example
     * // Get one Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends inventory_inflow_outflowFindUniqueOrThrowArgs>(args: SelectSubset<T, inventory_inflow_outflowFindUniqueOrThrowArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inventory_inflow_outflow that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowFindFirstArgs} args - Arguments to find a Inventory_inflow_outflow
     * @example
     * // Get one Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends inventory_inflow_outflowFindFirstArgs>(args?: SelectSubset<T, inventory_inflow_outflowFindFirstArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inventory_inflow_outflow that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowFindFirstOrThrowArgs} args - Arguments to find a Inventory_inflow_outflow
     * @example
     * // Get one Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends inventory_inflow_outflowFindFirstOrThrowArgs>(args?: SelectSubset<T, inventory_inflow_outflowFindFirstOrThrowArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Inventory_inflow_outflows that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Inventory_inflow_outflows
     * const inventory_inflow_outflows = await prisma.inventory_inflow_outflow.findMany()
     * 
     * // Get first 10 Inventory_inflow_outflows
     * const inventory_inflow_outflows = await prisma.inventory_inflow_outflow.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const inventory_inflow_outflowWithIdOnly = await prisma.inventory_inflow_outflow.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends inventory_inflow_outflowFindManyArgs>(args?: SelectSubset<T, inventory_inflow_outflowFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Inventory_inflow_outflow.
     * @param {inventory_inflow_outflowCreateArgs} args - Arguments to create a Inventory_inflow_outflow.
     * @example
     * // Create one Inventory_inflow_outflow
     * const Inventory_inflow_outflow = await prisma.inventory_inflow_outflow.create({
     *   data: {
     *     // ... data to create a Inventory_inflow_outflow
     *   }
     * })
     * 
     */
    create<T extends inventory_inflow_outflowCreateArgs>(args: SelectSubset<T, inventory_inflow_outflowCreateArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Inventory_inflow_outflows.
     * @param {inventory_inflow_outflowCreateManyArgs} args - Arguments to create many Inventory_inflow_outflows.
     * @example
     * // Create many Inventory_inflow_outflows
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends inventory_inflow_outflowCreateManyArgs>(args?: SelectSubset<T, inventory_inflow_outflowCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Inventory_inflow_outflows and returns the data saved in the database.
     * @param {inventory_inflow_outflowCreateManyAndReturnArgs} args - Arguments to create many Inventory_inflow_outflows.
     * @example
     * // Create many Inventory_inflow_outflows
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Inventory_inflow_outflows and only return the `id`
     * const inventory_inflow_outflowWithIdOnly = await prisma.inventory_inflow_outflow.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends inventory_inflow_outflowCreateManyAndReturnArgs>(args?: SelectSubset<T, inventory_inflow_outflowCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Inventory_inflow_outflow.
     * @param {inventory_inflow_outflowDeleteArgs} args - Arguments to delete one Inventory_inflow_outflow.
     * @example
     * // Delete one Inventory_inflow_outflow
     * const Inventory_inflow_outflow = await prisma.inventory_inflow_outflow.delete({
     *   where: {
     *     // ... filter to delete one Inventory_inflow_outflow
     *   }
     * })
     * 
     */
    delete<T extends inventory_inflow_outflowDeleteArgs>(args: SelectSubset<T, inventory_inflow_outflowDeleteArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Inventory_inflow_outflow.
     * @param {inventory_inflow_outflowUpdateArgs} args - Arguments to update one Inventory_inflow_outflow.
     * @example
     * // Update one Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends inventory_inflow_outflowUpdateArgs>(args: SelectSubset<T, inventory_inflow_outflowUpdateArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Inventory_inflow_outflows.
     * @param {inventory_inflow_outflowDeleteManyArgs} args - Arguments to filter Inventory_inflow_outflows to delete.
     * @example
     * // Delete a few Inventory_inflow_outflows
     * const { count } = await prisma.inventory_inflow_outflow.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends inventory_inflow_outflowDeleteManyArgs>(args?: SelectSubset<T, inventory_inflow_outflowDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Inventory_inflow_outflows.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Inventory_inflow_outflows
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends inventory_inflow_outflowUpdateManyArgs>(args: SelectSubset<T, inventory_inflow_outflowUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Inventory_inflow_outflows and returns the data updated in the database.
     * @param {inventory_inflow_outflowUpdateManyAndReturnArgs} args - Arguments to update many Inventory_inflow_outflows.
     * @example
     * // Update many Inventory_inflow_outflows
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Inventory_inflow_outflows and only return the `id`
     * const inventory_inflow_outflowWithIdOnly = await prisma.inventory_inflow_outflow.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends inventory_inflow_outflowUpdateManyAndReturnArgs>(args: SelectSubset<T, inventory_inflow_outflowUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Inventory_inflow_outflow.
     * @param {inventory_inflow_outflowUpsertArgs} args - Arguments to update or create a Inventory_inflow_outflow.
     * @example
     * // Update or create a Inventory_inflow_outflow
     * const inventory_inflow_outflow = await prisma.inventory_inflow_outflow.upsert({
     *   create: {
     *     // ... data to create a Inventory_inflow_outflow
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Inventory_inflow_outflow we want to update
     *   }
     * })
     */
    upsert<T extends inventory_inflow_outflowUpsertArgs>(args: SelectSubset<T, inventory_inflow_outflowUpsertArgs<ExtArgs>>): Prisma__inventory_inflow_outflowClient<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Inventory_inflow_outflows.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowCountArgs} args - Arguments to filter Inventory_inflow_outflows to count.
     * @example
     * // Count the number of Inventory_inflow_outflows
     * const count = await prisma.inventory_inflow_outflow.count({
     *   where: {
     *     // ... the filter for the Inventory_inflow_outflows we want to count
     *   }
     * })
    **/
    count<T extends inventory_inflow_outflowCountArgs>(
      args?: Subset<T, inventory_inflow_outflowCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Inventory_inflow_outflowCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Inventory_inflow_outflow.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Inventory_inflow_outflowAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Inventory_inflow_outflowAggregateArgs>(args: Subset<T, Inventory_inflow_outflowAggregateArgs>): Prisma.PrismaPromise<GetInventory_inflow_outflowAggregateType<T>>

    /**
     * Group by Inventory_inflow_outflow.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inventory_inflow_outflowGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends inventory_inflow_outflowGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: inventory_inflow_outflowGroupByArgs['orderBy'] }
        : { orderBy?: inventory_inflow_outflowGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, inventory_inflow_outflowGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetInventory_inflow_outflowGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the inventory_inflow_outflow model
   */
  readonly fields: inventory_inflow_outflowFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for inventory_inflow_outflow.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__inventory_inflow_outflowClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    product<T extends inventory_inflow_outflow$productArgs<ExtArgs> = {}>(args?: Subset<T, inventory_inflow_outflow$productArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the inventory_inflow_outflow model
   */
  interface inventory_inflow_outflowFieldRefs {
    readonly id: FieldRef<"inventory_inflow_outflow", 'Int'>
    readonly product_id: FieldRef<"inventory_inflow_outflow", 'Int'>
    readonly flow_direction: FieldRef<"inventory_inflow_outflow", 'flow_direction_enum'>
    readonly quantity: FieldRef<"inventory_inflow_outflow", 'Int'>
    readonly created_at: FieldRef<"inventory_inflow_outflow", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * inventory_inflow_outflow findUnique
   */
  export type inventory_inflow_outflowFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter, which inventory_inflow_outflow to fetch.
     */
    where: inventory_inflow_outflowWhereUniqueInput
  }

  /**
   * inventory_inflow_outflow findUniqueOrThrow
   */
  export type inventory_inflow_outflowFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter, which inventory_inflow_outflow to fetch.
     */
    where: inventory_inflow_outflowWhereUniqueInput
  }

  /**
   * inventory_inflow_outflow findFirst
   */
  export type inventory_inflow_outflowFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter, which inventory_inflow_outflow to fetch.
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inventory_inflow_outflows to fetch.
     */
    orderBy?: inventory_inflow_outflowOrderByWithRelationInput | inventory_inflow_outflowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for inventory_inflow_outflows.
     */
    cursor?: inventory_inflow_outflowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inventory_inflow_outflows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inventory_inflow_outflows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of inventory_inflow_outflows.
     */
    distinct?: Inventory_inflow_outflowScalarFieldEnum | Inventory_inflow_outflowScalarFieldEnum[]
  }

  /**
   * inventory_inflow_outflow findFirstOrThrow
   */
  export type inventory_inflow_outflowFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter, which inventory_inflow_outflow to fetch.
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inventory_inflow_outflows to fetch.
     */
    orderBy?: inventory_inflow_outflowOrderByWithRelationInput | inventory_inflow_outflowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for inventory_inflow_outflows.
     */
    cursor?: inventory_inflow_outflowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inventory_inflow_outflows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inventory_inflow_outflows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of inventory_inflow_outflows.
     */
    distinct?: Inventory_inflow_outflowScalarFieldEnum | Inventory_inflow_outflowScalarFieldEnum[]
  }

  /**
   * inventory_inflow_outflow findMany
   */
  export type inventory_inflow_outflowFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter, which inventory_inflow_outflows to fetch.
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inventory_inflow_outflows to fetch.
     */
    orderBy?: inventory_inflow_outflowOrderByWithRelationInput | inventory_inflow_outflowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing inventory_inflow_outflows.
     */
    cursor?: inventory_inflow_outflowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inventory_inflow_outflows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inventory_inflow_outflows.
     */
    skip?: number
    distinct?: Inventory_inflow_outflowScalarFieldEnum | Inventory_inflow_outflowScalarFieldEnum[]
  }

  /**
   * inventory_inflow_outflow create
   */
  export type inventory_inflow_outflowCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * The data needed to create a inventory_inflow_outflow.
     */
    data?: XOR<inventory_inflow_outflowCreateInput, inventory_inflow_outflowUncheckedCreateInput>
  }

  /**
   * inventory_inflow_outflow createMany
   */
  export type inventory_inflow_outflowCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many inventory_inflow_outflows.
     */
    data: inventory_inflow_outflowCreateManyInput | inventory_inflow_outflowCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * inventory_inflow_outflow createManyAndReturn
   */
  export type inventory_inflow_outflowCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * The data used to create many inventory_inflow_outflows.
     */
    data: inventory_inflow_outflowCreateManyInput | inventory_inflow_outflowCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * inventory_inflow_outflow update
   */
  export type inventory_inflow_outflowUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * The data needed to update a inventory_inflow_outflow.
     */
    data: XOR<inventory_inflow_outflowUpdateInput, inventory_inflow_outflowUncheckedUpdateInput>
    /**
     * Choose, which inventory_inflow_outflow to update.
     */
    where: inventory_inflow_outflowWhereUniqueInput
  }

  /**
   * inventory_inflow_outflow updateMany
   */
  export type inventory_inflow_outflowUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update inventory_inflow_outflows.
     */
    data: XOR<inventory_inflow_outflowUpdateManyMutationInput, inventory_inflow_outflowUncheckedUpdateManyInput>
    /**
     * Filter which inventory_inflow_outflows to update
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * Limit how many inventory_inflow_outflows to update.
     */
    limit?: number
  }

  /**
   * inventory_inflow_outflow updateManyAndReturn
   */
  export type inventory_inflow_outflowUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * The data used to update inventory_inflow_outflows.
     */
    data: XOR<inventory_inflow_outflowUpdateManyMutationInput, inventory_inflow_outflowUncheckedUpdateManyInput>
    /**
     * Filter which inventory_inflow_outflows to update
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * Limit how many inventory_inflow_outflows to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * inventory_inflow_outflow upsert
   */
  export type inventory_inflow_outflowUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * The filter to search for the inventory_inflow_outflow to update in case it exists.
     */
    where: inventory_inflow_outflowWhereUniqueInput
    /**
     * In case the inventory_inflow_outflow found by the `where` argument doesn't exist, create a new inventory_inflow_outflow with this data.
     */
    create: XOR<inventory_inflow_outflowCreateInput, inventory_inflow_outflowUncheckedCreateInput>
    /**
     * In case the inventory_inflow_outflow was found with the provided `where` argument, update it with this data.
     */
    update: XOR<inventory_inflow_outflowUpdateInput, inventory_inflow_outflowUncheckedUpdateInput>
  }

  /**
   * inventory_inflow_outflow delete
   */
  export type inventory_inflow_outflowDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    /**
     * Filter which inventory_inflow_outflow to delete.
     */
    where: inventory_inflow_outflowWhereUniqueInput
  }

  /**
   * inventory_inflow_outflow deleteMany
   */
  export type inventory_inflow_outflowDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which inventory_inflow_outflows to delete
     */
    where?: inventory_inflow_outflowWhereInput
    /**
     * Limit how many inventory_inflow_outflows to delete.
     */
    limit?: number
  }

  /**
   * inventory_inflow_outflow.product
   */
  export type inventory_inflow_outflow$productArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    where?: productWhereInput
  }

  /**
   * inventory_inflow_outflow without action
   */
  export type inventory_inflow_outflowDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
  }


  /**
   * Model notification
   */

  export type AggregateNotification = {
    _count: NotificationCountAggregateOutputType | null
    _avg: NotificationAvgAggregateOutputType | null
    _sum: NotificationSumAggregateOutputType | null
    _min: NotificationMinAggregateOutputType | null
    _max: NotificationMaxAggregateOutputType | null
  }

  export type NotificationAvgAggregateOutputType = {
    notification_id: number | null
    customer_id: number | null
  }

  export type NotificationSumAggregateOutputType = {
    notification_id: number | null
    customer_id: number | null
  }

  export type NotificationMinAggregateOutputType = {
    notification_id: number | null
    customer_id: number | null
    message: string | null
    sent_at: Date | null
  }

  export type NotificationMaxAggregateOutputType = {
    notification_id: number | null
    customer_id: number | null
    message: string | null
    sent_at: Date | null
  }

  export type NotificationCountAggregateOutputType = {
    notification_id: number
    customer_id: number
    message: number
    sent_at: number
    _all: number
  }


  export type NotificationAvgAggregateInputType = {
    notification_id?: true
    customer_id?: true
  }

  export type NotificationSumAggregateInputType = {
    notification_id?: true
    customer_id?: true
  }

  export type NotificationMinAggregateInputType = {
    notification_id?: true
    customer_id?: true
    message?: true
    sent_at?: true
  }

  export type NotificationMaxAggregateInputType = {
    notification_id?: true
    customer_id?: true
    message?: true
    sent_at?: true
  }

  export type NotificationCountAggregateInputType = {
    notification_id?: true
    customer_id?: true
    message?: true
    sent_at?: true
    _all?: true
  }

  export type NotificationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which notification to aggregate.
     */
    where?: notificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notifications to fetch.
     */
    orderBy?: notificationOrderByWithRelationInput | notificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: notificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned notifications
    **/
    _count?: true | NotificationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: NotificationAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: NotificationSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: NotificationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: NotificationMaxAggregateInputType
  }

  export type GetNotificationAggregateType<T extends NotificationAggregateArgs> = {
        [P in keyof T & keyof AggregateNotification]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateNotification[P]>
      : GetScalarType<T[P], AggregateNotification[P]>
  }




  export type notificationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: notificationWhereInput
    orderBy?: notificationOrderByWithAggregationInput | notificationOrderByWithAggregationInput[]
    by: NotificationScalarFieldEnum[] | NotificationScalarFieldEnum
    having?: notificationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: NotificationCountAggregateInputType | true
    _avg?: NotificationAvgAggregateInputType
    _sum?: NotificationSumAggregateInputType
    _min?: NotificationMinAggregateInputType
    _max?: NotificationMaxAggregateInputType
  }

  export type NotificationGroupByOutputType = {
    notification_id: number
    customer_id: number | null
    message: string
    sent_at: Date | null
    _count: NotificationCountAggregateOutputType | null
    _avg: NotificationAvgAggregateOutputType | null
    _sum: NotificationSumAggregateOutputType | null
    _min: NotificationMinAggregateOutputType | null
    _max: NotificationMaxAggregateOutputType | null
  }

  type GetNotificationGroupByPayload<T extends notificationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<NotificationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof NotificationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], NotificationGroupByOutputType[P]>
            : GetScalarType<T[P], NotificationGroupByOutputType[P]>
        }
      >
    >


  export type notificationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    notification_id?: boolean
    customer_id?: boolean
    message?: boolean
    sent_at?: boolean
    customer?: boolean | notification$customerArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type notificationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    notification_id?: boolean
    customer_id?: boolean
    message?: boolean
    sent_at?: boolean
    customer?: boolean | notification$customerArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type notificationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    notification_id?: boolean
    customer_id?: boolean
    message?: boolean
    sent_at?: boolean
    customer?: boolean | notification$customerArgs<ExtArgs>
  }, ExtArgs["result"]["notification"]>

  export type notificationSelectScalar = {
    notification_id?: boolean
    customer_id?: boolean
    message?: boolean
    sent_at?: boolean
  }

  export type notificationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"notification_id" | "customer_id" | "message" | "sent_at", ExtArgs["result"]["notification"]>
  export type notificationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | notification$customerArgs<ExtArgs>
  }
  export type notificationIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | notification$customerArgs<ExtArgs>
  }
  export type notificationIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | notification$customerArgs<ExtArgs>
  }

  export type $notificationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "notification"
    objects: {
      customer: Prisma.$customerPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      notification_id: number
      customer_id: number | null
      message: string
      sent_at: Date | null
    }, ExtArgs["result"]["notification"]>
    composites: {}
  }

  type notificationGetPayload<S extends boolean | null | undefined | notificationDefaultArgs> = $Result.GetResult<Prisma.$notificationPayload, S>

  type notificationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<notificationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: NotificationCountAggregateInputType | true
    }

  export interface notificationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['notification'], meta: { name: 'notification' } }
    /**
     * Find zero or one Notification that matches the filter.
     * @param {notificationFindUniqueArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends notificationFindUniqueArgs>(args: SelectSubset<T, notificationFindUniqueArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Notification that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {notificationFindUniqueOrThrowArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends notificationFindUniqueOrThrowArgs>(args: SelectSubset<T, notificationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Notification that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationFindFirstArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends notificationFindFirstArgs>(args?: SelectSubset<T, notificationFindFirstArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Notification that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationFindFirstOrThrowArgs} args - Arguments to find a Notification
     * @example
     * // Get one Notification
     * const notification = await prisma.notification.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends notificationFindFirstOrThrowArgs>(args?: SelectSubset<T, notificationFindFirstOrThrowArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Notifications that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Notifications
     * const notifications = await prisma.notification.findMany()
     * 
     * // Get first 10 Notifications
     * const notifications = await prisma.notification.findMany({ take: 10 })
     * 
     * // Only select the `notification_id`
     * const notificationWithNotification_idOnly = await prisma.notification.findMany({ select: { notification_id: true } })
     * 
     */
    findMany<T extends notificationFindManyArgs>(args?: SelectSubset<T, notificationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Notification.
     * @param {notificationCreateArgs} args - Arguments to create a Notification.
     * @example
     * // Create one Notification
     * const Notification = await prisma.notification.create({
     *   data: {
     *     // ... data to create a Notification
     *   }
     * })
     * 
     */
    create<T extends notificationCreateArgs>(args: SelectSubset<T, notificationCreateArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Notifications.
     * @param {notificationCreateManyArgs} args - Arguments to create many Notifications.
     * @example
     * // Create many Notifications
     * const notification = await prisma.notification.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends notificationCreateManyArgs>(args?: SelectSubset<T, notificationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Notifications and returns the data saved in the database.
     * @param {notificationCreateManyAndReturnArgs} args - Arguments to create many Notifications.
     * @example
     * // Create many Notifications
     * const notification = await prisma.notification.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Notifications and only return the `notification_id`
     * const notificationWithNotification_idOnly = await prisma.notification.createManyAndReturn({
     *   select: { notification_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends notificationCreateManyAndReturnArgs>(args?: SelectSubset<T, notificationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Notification.
     * @param {notificationDeleteArgs} args - Arguments to delete one Notification.
     * @example
     * // Delete one Notification
     * const Notification = await prisma.notification.delete({
     *   where: {
     *     // ... filter to delete one Notification
     *   }
     * })
     * 
     */
    delete<T extends notificationDeleteArgs>(args: SelectSubset<T, notificationDeleteArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Notification.
     * @param {notificationUpdateArgs} args - Arguments to update one Notification.
     * @example
     * // Update one Notification
     * const notification = await prisma.notification.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends notificationUpdateArgs>(args: SelectSubset<T, notificationUpdateArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Notifications.
     * @param {notificationDeleteManyArgs} args - Arguments to filter Notifications to delete.
     * @example
     * // Delete a few Notifications
     * const { count } = await prisma.notification.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends notificationDeleteManyArgs>(args?: SelectSubset<T, notificationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Notifications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Notifications
     * const notification = await prisma.notification.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends notificationUpdateManyArgs>(args: SelectSubset<T, notificationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Notifications and returns the data updated in the database.
     * @param {notificationUpdateManyAndReturnArgs} args - Arguments to update many Notifications.
     * @example
     * // Update many Notifications
     * const notification = await prisma.notification.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Notifications and only return the `notification_id`
     * const notificationWithNotification_idOnly = await prisma.notification.updateManyAndReturn({
     *   select: { notification_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends notificationUpdateManyAndReturnArgs>(args: SelectSubset<T, notificationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Notification.
     * @param {notificationUpsertArgs} args - Arguments to update or create a Notification.
     * @example
     * // Update or create a Notification
     * const notification = await prisma.notification.upsert({
     *   create: {
     *     // ... data to create a Notification
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Notification we want to update
     *   }
     * })
     */
    upsert<T extends notificationUpsertArgs>(args: SelectSubset<T, notificationUpsertArgs<ExtArgs>>): Prisma__notificationClient<$Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Notifications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationCountArgs} args - Arguments to filter Notifications to count.
     * @example
     * // Count the number of Notifications
     * const count = await prisma.notification.count({
     *   where: {
     *     // ... the filter for the Notifications we want to count
     *   }
     * })
    **/
    count<T extends notificationCountArgs>(
      args?: Subset<T, notificationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], NotificationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Notification.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotificationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends NotificationAggregateArgs>(args: Subset<T, NotificationAggregateArgs>): Prisma.PrismaPromise<GetNotificationAggregateType<T>>

    /**
     * Group by Notification.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notificationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends notificationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: notificationGroupByArgs['orderBy'] }
        : { orderBy?: notificationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, notificationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNotificationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the notification model
   */
  readonly fields: notificationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for notification.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__notificationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    customer<T extends notification$customerArgs<ExtArgs> = {}>(args?: Subset<T, notification$customerArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the notification model
   */
  interface notificationFieldRefs {
    readonly notification_id: FieldRef<"notification", 'Int'>
    readonly customer_id: FieldRef<"notification", 'Int'>
    readonly message: FieldRef<"notification", 'String'>
    readonly sent_at: FieldRef<"notification", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * notification findUnique
   */
  export type notificationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter, which notification to fetch.
     */
    where: notificationWhereUniqueInput
  }

  /**
   * notification findUniqueOrThrow
   */
  export type notificationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter, which notification to fetch.
     */
    where: notificationWhereUniqueInput
  }

  /**
   * notification findFirst
   */
  export type notificationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter, which notification to fetch.
     */
    where?: notificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notifications to fetch.
     */
    orderBy?: notificationOrderByWithRelationInput | notificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for notifications.
     */
    cursor?: notificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of notifications.
     */
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * notification findFirstOrThrow
   */
  export type notificationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter, which notification to fetch.
     */
    where?: notificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notifications to fetch.
     */
    orderBy?: notificationOrderByWithRelationInput | notificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for notifications.
     */
    cursor?: notificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notifications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of notifications.
     */
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * notification findMany
   */
  export type notificationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter, which notifications to fetch.
     */
    where?: notificationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notifications to fetch.
     */
    orderBy?: notificationOrderByWithRelationInput | notificationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing notifications.
     */
    cursor?: notificationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notifications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notifications.
     */
    skip?: number
    distinct?: NotificationScalarFieldEnum | NotificationScalarFieldEnum[]
  }

  /**
   * notification create
   */
  export type notificationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * The data needed to create a notification.
     */
    data: XOR<notificationCreateInput, notificationUncheckedCreateInput>
  }

  /**
   * notification createMany
   */
  export type notificationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many notifications.
     */
    data: notificationCreateManyInput | notificationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * notification createManyAndReturn
   */
  export type notificationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * The data used to create many notifications.
     */
    data: notificationCreateManyInput | notificationCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * notification update
   */
  export type notificationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * The data needed to update a notification.
     */
    data: XOR<notificationUpdateInput, notificationUncheckedUpdateInput>
    /**
     * Choose, which notification to update.
     */
    where: notificationWhereUniqueInput
  }

  /**
   * notification updateMany
   */
  export type notificationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update notifications.
     */
    data: XOR<notificationUpdateManyMutationInput, notificationUncheckedUpdateManyInput>
    /**
     * Filter which notifications to update
     */
    where?: notificationWhereInput
    /**
     * Limit how many notifications to update.
     */
    limit?: number
  }

  /**
   * notification updateManyAndReturn
   */
  export type notificationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * The data used to update notifications.
     */
    data: XOR<notificationUpdateManyMutationInput, notificationUncheckedUpdateManyInput>
    /**
     * Filter which notifications to update
     */
    where?: notificationWhereInput
    /**
     * Limit how many notifications to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * notification upsert
   */
  export type notificationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * The filter to search for the notification to update in case it exists.
     */
    where: notificationWhereUniqueInput
    /**
     * In case the notification found by the `where` argument doesn't exist, create a new notification with this data.
     */
    create: XOR<notificationCreateInput, notificationUncheckedCreateInput>
    /**
     * In case the notification was found with the provided `where` argument, update it with this data.
     */
    update: XOR<notificationUpdateInput, notificationUncheckedUpdateInput>
  }

  /**
   * notification delete
   */
  export type notificationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
    /**
     * Filter which notification to delete.
     */
    where: notificationWhereUniqueInput
  }

  /**
   * notification deleteMany
   */
  export type notificationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which notifications to delete
     */
    where?: notificationWhereInput
    /**
     * Limit how many notifications to delete.
     */
    limit?: number
  }

  /**
   * notification.customer
   */
  export type notification$customerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    where?: customerWhereInput
  }

  /**
   * notification without action
   */
  export type notificationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the notification
     */
    select?: notificationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the notification
     */
    omit?: notificationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: notificationInclude<ExtArgs> | null
  }


  /**
   * Model order
   */

  export type AggregateOrder = {
    _count: OrderCountAggregateOutputType | null
    _avg: OrderAvgAggregateOutputType | null
    _sum: OrderSumAggregateOutputType | null
    _min: OrderMinAggregateOutputType | null
    _max: OrderMaxAggregateOutputType | null
  }

  export type OrderAvgAggregateOutputType = {
    order_id: number | null
    quotation_id: number | null
    customer_id: number | null
    total_price: Decimal | null
  }

  export type OrderSumAggregateOutputType = {
    order_id: number | null
    quotation_id: number | null
    customer_id: number | null
    total_price: Decimal | null
  }

  export type OrderMinAggregateOutputType = {
    order_id: number | null
    quotation_id: number | null
    customer_id: number | null
    status: $Enums.order_status_enum | null
    total_price: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type OrderMaxAggregateOutputType = {
    order_id: number | null
    quotation_id: number | null
    customer_id: number | null
    status: $Enums.order_status_enum | null
    total_price: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type OrderCountAggregateOutputType = {
    order_id: number
    quotation_id: number
    customer_id: number
    status: number
    total_price: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type OrderAvgAggregateInputType = {
    order_id?: true
    quotation_id?: true
    customer_id?: true
    total_price?: true
  }

  export type OrderSumAggregateInputType = {
    order_id?: true
    quotation_id?: true
    customer_id?: true
    total_price?: true
  }

  export type OrderMinAggregateInputType = {
    order_id?: true
    quotation_id?: true
    customer_id?: true
    status?: true
    total_price?: true
    created_at?: true
    updated_at?: true
  }

  export type OrderMaxAggregateInputType = {
    order_id?: true
    quotation_id?: true
    customer_id?: true
    status?: true
    total_price?: true
    created_at?: true
    updated_at?: true
  }

  export type OrderCountAggregateInputType = {
    order_id?: true
    quotation_id?: true
    customer_id?: true
    status?: true
    total_price?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type OrderAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which order to aggregate.
     */
    where?: orderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of orders to fetch.
     */
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: orderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned orders
    **/
    _count?: true | OrderCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OrderAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OrderSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OrderMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OrderMaxAggregateInputType
  }

  export type GetOrderAggregateType<T extends OrderAggregateArgs> = {
        [P in keyof T & keyof AggregateOrder]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrder[P]>
      : GetScalarType<T[P], AggregateOrder[P]>
  }




  export type orderGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: orderWhereInput
    orderBy?: orderOrderByWithAggregationInput | orderOrderByWithAggregationInput[]
    by: OrderScalarFieldEnum[] | OrderScalarFieldEnum
    having?: orderScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OrderCountAggregateInputType | true
    _avg?: OrderAvgAggregateInputType
    _sum?: OrderSumAggregateInputType
    _min?: OrderMinAggregateInputType
    _max?: OrderMaxAggregateInputType
  }

  export type OrderGroupByOutputType = {
    order_id: number
    quotation_id: number | null
    customer_id: number | null
    status: $Enums.order_status_enum | null
    total_price: Decimal | null
    created_at: Date | null
    updated_at: Date | null
    _count: OrderCountAggregateOutputType | null
    _avg: OrderAvgAggregateOutputType | null
    _sum: OrderSumAggregateOutputType | null
    _min: OrderMinAggregateOutputType | null
    _max: OrderMaxAggregateOutputType | null
  }

  type GetOrderGroupByPayload<T extends orderGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OrderGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OrderGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OrderGroupByOutputType[P]>
            : GetScalarType<T[P], OrderGroupByOutputType[P]>
        }
      >
    >


  export type orderSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_id?: boolean
    quotation_id?: boolean
    customer_id?: boolean
    status?: boolean
    total_price?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
    order_details?: boolean | order$order_detailsArgs<ExtArgs>
    payment?: boolean | order$paymentArgs<ExtArgs>
    _count?: boolean | OrderCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type orderSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_id?: boolean
    quotation_id?: boolean
    customer_id?: boolean
    status?: boolean
    total_price?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type orderSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_id?: boolean
    quotation_id?: boolean
    customer_id?: boolean
    status?: boolean
    total_price?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
  }, ExtArgs["result"]["order"]>

  export type orderSelectScalar = {
    order_id?: boolean
    quotation_id?: boolean
    customer_id?: boolean
    status?: boolean
    total_price?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type orderOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"order_id" | "quotation_id" | "customer_id" | "status" | "total_price" | "created_at" | "updated_at", ExtArgs["result"]["order"]>
  export type orderInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
    order_details?: boolean | order$order_detailsArgs<ExtArgs>
    payment?: boolean | order$paymentArgs<ExtArgs>
    _count?: boolean | OrderCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type orderIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
  }
  export type orderIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | order$customerArgs<ExtArgs>
    quotation?: boolean | order$quotationArgs<ExtArgs>
  }

  export type $orderPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "order"
    objects: {
      customer: Prisma.$customerPayload<ExtArgs> | null
      quotation: Prisma.$quotationPayload<ExtArgs> | null
      order_details: Prisma.$order_detailsPayload<ExtArgs>[]
      payment: Prisma.$paymentPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      order_id: number
      quotation_id: number | null
      customer_id: number | null
      status: $Enums.order_status_enum | null
      total_price: Prisma.Decimal | null
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["order"]>
    composites: {}
  }

  type orderGetPayload<S extends boolean | null | undefined | orderDefaultArgs> = $Result.GetResult<Prisma.$orderPayload, S>

  type orderCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<orderFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OrderCountAggregateInputType | true
    }

  export interface orderDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['order'], meta: { name: 'order' } }
    /**
     * Find zero or one Order that matches the filter.
     * @param {orderFindUniqueArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends orderFindUniqueArgs>(args: SelectSubset<T, orderFindUniqueArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Order that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {orderFindUniqueOrThrowArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends orderFindUniqueOrThrowArgs>(args: SelectSubset<T, orderFindUniqueOrThrowArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderFindFirstArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends orderFindFirstArgs>(args?: SelectSubset<T, orderFindFirstArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderFindFirstOrThrowArgs} args - Arguments to find a Order
     * @example
     * // Get one Order
     * const order = await prisma.order.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends orderFindFirstOrThrowArgs>(args?: SelectSubset<T, orderFindFirstOrThrowArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Orders that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Orders
     * const orders = await prisma.order.findMany()
     * 
     * // Get first 10 Orders
     * const orders = await prisma.order.findMany({ take: 10 })
     * 
     * // Only select the `order_id`
     * const orderWithOrder_idOnly = await prisma.order.findMany({ select: { order_id: true } })
     * 
     */
    findMany<T extends orderFindManyArgs>(args?: SelectSubset<T, orderFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Order.
     * @param {orderCreateArgs} args - Arguments to create a Order.
     * @example
     * // Create one Order
     * const Order = await prisma.order.create({
     *   data: {
     *     // ... data to create a Order
     *   }
     * })
     * 
     */
    create<T extends orderCreateArgs>(args: SelectSubset<T, orderCreateArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Orders.
     * @param {orderCreateManyArgs} args - Arguments to create many Orders.
     * @example
     * // Create many Orders
     * const order = await prisma.order.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends orderCreateManyArgs>(args?: SelectSubset<T, orderCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Orders and returns the data saved in the database.
     * @param {orderCreateManyAndReturnArgs} args - Arguments to create many Orders.
     * @example
     * // Create many Orders
     * const order = await prisma.order.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Orders and only return the `order_id`
     * const orderWithOrder_idOnly = await prisma.order.createManyAndReturn({
     *   select: { order_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends orderCreateManyAndReturnArgs>(args?: SelectSubset<T, orderCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Order.
     * @param {orderDeleteArgs} args - Arguments to delete one Order.
     * @example
     * // Delete one Order
     * const Order = await prisma.order.delete({
     *   where: {
     *     // ... filter to delete one Order
     *   }
     * })
     * 
     */
    delete<T extends orderDeleteArgs>(args: SelectSubset<T, orderDeleteArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Order.
     * @param {orderUpdateArgs} args - Arguments to update one Order.
     * @example
     * // Update one Order
     * const order = await prisma.order.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends orderUpdateArgs>(args: SelectSubset<T, orderUpdateArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Orders.
     * @param {orderDeleteManyArgs} args - Arguments to filter Orders to delete.
     * @example
     * // Delete a few Orders
     * const { count } = await prisma.order.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends orderDeleteManyArgs>(args?: SelectSubset<T, orderDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Orders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Orders
     * const order = await prisma.order.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends orderUpdateManyArgs>(args: SelectSubset<T, orderUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Orders and returns the data updated in the database.
     * @param {orderUpdateManyAndReturnArgs} args - Arguments to update many Orders.
     * @example
     * // Update many Orders
     * const order = await prisma.order.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Orders and only return the `order_id`
     * const orderWithOrder_idOnly = await prisma.order.updateManyAndReturn({
     *   select: { order_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends orderUpdateManyAndReturnArgs>(args: SelectSubset<T, orderUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Order.
     * @param {orderUpsertArgs} args - Arguments to update or create a Order.
     * @example
     * // Update or create a Order
     * const order = await prisma.order.upsert({
     *   create: {
     *     // ... data to create a Order
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Order we want to update
     *   }
     * })
     */
    upsert<T extends orderUpsertArgs>(args: SelectSubset<T, orderUpsertArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Orders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderCountArgs} args - Arguments to filter Orders to count.
     * @example
     * // Count the number of Orders
     * const count = await prisma.order.count({
     *   where: {
     *     // ... the filter for the Orders we want to count
     *   }
     * })
    **/
    count<T extends orderCountArgs>(
      args?: Subset<T, orderCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OrderCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Order.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrderAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OrderAggregateArgs>(args: Subset<T, OrderAggregateArgs>): Prisma.PrismaPromise<GetOrderAggregateType<T>>

    /**
     * Group by Order.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {orderGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends orderGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: orderGroupByArgs['orderBy'] }
        : { orderBy?: orderGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, orderGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrderGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the order model
   */
  readonly fields: orderFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for order.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__orderClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    customer<T extends order$customerArgs<ExtArgs> = {}>(args?: Subset<T, order$customerArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    quotation<T extends order$quotationArgs<ExtArgs> = {}>(args?: Subset<T, order$quotationArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    order_details<T extends order$order_detailsArgs<ExtArgs> = {}>(args?: Subset<T, order$order_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    payment<T extends order$paymentArgs<ExtArgs> = {}>(args?: Subset<T, order$paymentArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the order model
   */
  interface orderFieldRefs {
    readonly order_id: FieldRef<"order", 'Int'>
    readonly quotation_id: FieldRef<"order", 'Int'>
    readonly customer_id: FieldRef<"order", 'Int'>
    readonly status: FieldRef<"order", 'order_status_enum'>
    readonly total_price: FieldRef<"order", 'Decimal'>
    readonly created_at: FieldRef<"order", 'DateTime'>
    readonly updated_at: FieldRef<"order", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * order findUnique
   */
  export type orderFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter, which order to fetch.
     */
    where: orderWhereUniqueInput
  }

  /**
   * order findUniqueOrThrow
   */
  export type orderFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter, which order to fetch.
     */
    where: orderWhereUniqueInput
  }

  /**
   * order findFirst
   */
  export type orderFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter, which order to fetch.
     */
    where?: orderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of orders to fetch.
     */
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for orders.
     */
    cursor?: orderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of orders.
     */
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * order findFirstOrThrow
   */
  export type orderFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter, which order to fetch.
     */
    where?: orderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of orders to fetch.
     */
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for orders.
     */
    cursor?: orderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` orders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of orders.
     */
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * order findMany
   */
  export type orderFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter, which orders to fetch.
     */
    where?: orderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of orders to fetch.
     */
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing orders.
     */
    cursor?: orderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` orders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` orders.
     */
    skip?: number
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * order create
   */
  export type orderCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * The data needed to create a order.
     */
    data?: XOR<orderCreateInput, orderUncheckedCreateInput>
  }

  /**
   * order createMany
   */
  export type orderCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many orders.
     */
    data: orderCreateManyInput | orderCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * order createManyAndReturn
   */
  export type orderCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * The data used to create many orders.
     */
    data: orderCreateManyInput | orderCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * order update
   */
  export type orderUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * The data needed to update a order.
     */
    data: XOR<orderUpdateInput, orderUncheckedUpdateInput>
    /**
     * Choose, which order to update.
     */
    where: orderWhereUniqueInput
  }

  /**
   * order updateMany
   */
  export type orderUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update orders.
     */
    data: XOR<orderUpdateManyMutationInput, orderUncheckedUpdateManyInput>
    /**
     * Filter which orders to update
     */
    where?: orderWhereInput
    /**
     * Limit how many orders to update.
     */
    limit?: number
  }

  /**
   * order updateManyAndReturn
   */
  export type orderUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * The data used to update orders.
     */
    data: XOR<orderUpdateManyMutationInput, orderUncheckedUpdateManyInput>
    /**
     * Filter which orders to update
     */
    where?: orderWhereInput
    /**
     * Limit how many orders to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * order upsert
   */
  export type orderUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * The filter to search for the order to update in case it exists.
     */
    where: orderWhereUniqueInput
    /**
     * In case the order found by the `where` argument doesn't exist, create a new order with this data.
     */
    create: XOR<orderCreateInput, orderUncheckedCreateInput>
    /**
     * In case the order was found with the provided `where` argument, update it with this data.
     */
    update: XOR<orderUpdateInput, orderUncheckedUpdateInput>
  }

  /**
   * order delete
   */
  export type orderDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    /**
     * Filter which order to delete.
     */
    where: orderWhereUniqueInput
  }

  /**
   * order deleteMany
   */
  export type orderDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which orders to delete
     */
    where?: orderWhereInput
    /**
     * Limit how many orders to delete.
     */
    limit?: number
  }

  /**
   * order.customer
   */
  export type order$customerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    where?: customerWhereInput
  }

  /**
   * order.quotation
   */
  export type order$quotationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    where?: quotationWhereInput
  }

  /**
   * order.order_details
   */
  export type order$order_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    where?: order_detailsWhereInput
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    cursor?: order_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Order_detailsScalarFieldEnum | Order_detailsScalarFieldEnum[]
  }

  /**
   * order.payment
   */
  export type order$paymentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    where?: paymentWhereInput
    orderBy?: paymentOrderByWithRelationInput | paymentOrderByWithRelationInput[]
    cursor?: paymentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * order without action
   */
  export type orderDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
  }


  /**
   * Model order_details
   */

  export type AggregateOrder_details = {
    _count: Order_detailsCountAggregateOutputType | null
    _avg: Order_detailsAvgAggregateOutputType | null
    _sum: Order_detailsSumAggregateOutputType | null
    _min: Order_detailsMinAggregateOutputType | null
    _max: Order_detailsMaxAggregateOutputType | null
  }

  export type Order_detailsAvgAggregateOutputType = {
    order_item_id: number | null
    order_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Order_detailsSumAggregateOutputType = {
    order_item_id: number | null
    order_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Order_detailsMinAggregateOutputType = {
    order_item_id: number | null
    order_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Order_detailsMaxAggregateOutputType = {
    order_item_id: number | null
    order_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Order_detailsCountAggregateOutputType = {
    order_item_id: number
    order_id: number
    product_id: number
    quantity: number
    price: number
    _all: number
  }


  export type Order_detailsAvgAggregateInputType = {
    order_item_id?: true
    order_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Order_detailsSumAggregateInputType = {
    order_item_id?: true
    order_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Order_detailsMinAggregateInputType = {
    order_item_id?: true
    order_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Order_detailsMaxAggregateInputType = {
    order_item_id?: true
    order_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Order_detailsCountAggregateInputType = {
    order_item_id?: true
    order_id?: true
    product_id?: true
    quantity?: true
    price?: true
    _all?: true
  }

  export type Order_detailsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which order_details to aggregate.
     */
    where?: order_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of order_details to fetch.
     */
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: order_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` order_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` order_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned order_details
    **/
    _count?: true | Order_detailsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Order_detailsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Order_detailsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Order_detailsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Order_detailsMaxAggregateInputType
  }

  export type GetOrder_detailsAggregateType<T extends Order_detailsAggregateArgs> = {
        [P in keyof T & keyof AggregateOrder_details]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrder_details[P]>
      : GetScalarType<T[P], AggregateOrder_details[P]>
  }




  export type order_detailsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: order_detailsWhereInput
    orderBy?: order_detailsOrderByWithAggregationInput | order_detailsOrderByWithAggregationInput[]
    by: Order_detailsScalarFieldEnum[] | Order_detailsScalarFieldEnum
    having?: order_detailsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Order_detailsCountAggregateInputType | true
    _avg?: Order_detailsAvgAggregateInputType
    _sum?: Order_detailsSumAggregateInputType
    _min?: Order_detailsMinAggregateInputType
    _max?: Order_detailsMaxAggregateInputType
  }

  export type Order_detailsGroupByOutputType = {
    order_item_id: number
    order_id: number | null
    product_id: number | null
    quantity: number
    price: Decimal
    _count: Order_detailsCountAggregateOutputType | null
    _avg: Order_detailsAvgAggregateOutputType | null
    _sum: Order_detailsSumAggregateOutputType | null
    _min: Order_detailsMinAggregateOutputType | null
    _max: Order_detailsMaxAggregateOutputType | null
  }

  type GetOrder_detailsGroupByPayload<T extends order_detailsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Order_detailsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Order_detailsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Order_detailsGroupByOutputType[P]>
            : GetScalarType<T[P], Order_detailsGroupByOutputType[P]>
        }
      >
    >


  export type order_detailsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_item_id?: boolean
    order_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }, ExtArgs["result"]["order_details"]>

  export type order_detailsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_item_id?: boolean
    order_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }, ExtArgs["result"]["order_details"]>

  export type order_detailsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    order_item_id?: boolean
    order_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }, ExtArgs["result"]["order_details"]>

  export type order_detailsSelectScalar = {
    order_item_id?: boolean
    order_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
  }

  export type order_detailsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"order_item_id" | "order_id" | "product_id" | "quantity" | "price", ExtArgs["result"]["order_details"]>
  export type order_detailsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }
  export type order_detailsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }
  export type order_detailsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | order_details$orderArgs<ExtArgs>
    product?: boolean | order_details$productArgs<ExtArgs>
  }

  export type $order_detailsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "order_details"
    objects: {
      order: Prisma.$orderPayload<ExtArgs> | null
      product: Prisma.$productPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      order_item_id: number
      order_id: number | null
      product_id: number | null
      quantity: number
      price: Prisma.Decimal
    }, ExtArgs["result"]["order_details"]>
    composites: {}
  }

  type order_detailsGetPayload<S extends boolean | null | undefined | order_detailsDefaultArgs> = $Result.GetResult<Prisma.$order_detailsPayload, S>

  type order_detailsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<order_detailsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Order_detailsCountAggregateInputType | true
    }

  export interface order_detailsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['order_details'], meta: { name: 'order_details' } }
    /**
     * Find zero or one Order_details that matches the filter.
     * @param {order_detailsFindUniqueArgs} args - Arguments to find a Order_details
     * @example
     * // Get one Order_details
     * const order_details = await prisma.order_details.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends order_detailsFindUniqueArgs>(args: SelectSubset<T, order_detailsFindUniqueArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Order_details that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {order_detailsFindUniqueOrThrowArgs} args - Arguments to find a Order_details
     * @example
     * // Get one Order_details
     * const order_details = await prisma.order_details.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends order_detailsFindUniqueOrThrowArgs>(args: SelectSubset<T, order_detailsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsFindFirstArgs} args - Arguments to find a Order_details
     * @example
     * // Get one Order_details
     * const order_details = await prisma.order_details.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends order_detailsFindFirstArgs>(args?: SelectSubset<T, order_detailsFindFirstArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Order_details that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsFindFirstOrThrowArgs} args - Arguments to find a Order_details
     * @example
     * // Get one Order_details
     * const order_details = await prisma.order_details.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends order_detailsFindFirstOrThrowArgs>(args?: SelectSubset<T, order_detailsFindFirstOrThrowArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Order_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Order_details
     * const order_details = await prisma.order_details.findMany()
     * 
     * // Get first 10 Order_details
     * const order_details = await prisma.order_details.findMany({ take: 10 })
     * 
     * // Only select the `order_item_id`
     * const order_detailsWithOrder_item_idOnly = await prisma.order_details.findMany({ select: { order_item_id: true } })
     * 
     */
    findMany<T extends order_detailsFindManyArgs>(args?: SelectSubset<T, order_detailsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Order_details.
     * @param {order_detailsCreateArgs} args - Arguments to create a Order_details.
     * @example
     * // Create one Order_details
     * const Order_details = await prisma.order_details.create({
     *   data: {
     *     // ... data to create a Order_details
     *   }
     * })
     * 
     */
    create<T extends order_detailsCreateArgs>(args: SelectSubset<T, order_detailsCreateArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Order_details.
     * @param {order_detailsCreateManyArgs} args - Arguments to create many Order_details.
     * @example
     * // Create many Order_details
     * const order_details = await prisma.order_details.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends order_detailsCreateManyArgs>(args?: SelectSubset<T, order_detailsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Order_details and returns the data saved in the database.
     * @param {order_detailsCreateManyAndReturnArgs} args - Arguments to create many Order_details.
     * @example
     * // Create many Order_details
     * const order_details = await prisma.order_details.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Order_details and only return the `order_item_id`
     * const order_detailsWithOrder_item_idOnly = await prisma.order_details.createManyAndReturn({
     *   select: { order_item_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends order_detailsCreateManyAndReturnArgs>(args?: SelectSubset<T, order_detailsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Order_details.
     * @param {order_detailsDeleteArgs} args - Arguments to delete one Order_details.
     * @example
     * // Delete one Order_details
     * const Order_details = await prisma.order_details.delete({
     *   where: {
     *     // ... filter to delete one Order_details
     *   }
     * })
     * 
     */
    delete<T extends order_detailsDeleteArgs>(args: SelectSubset<T, order_detailsDeleteArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Order_details.
     * @param {order_detailsUpdateArgs} args - Arguments to update one Order_details.
     * @example
     * // Update one Order_details
     * const order_details = await prisma.order_details.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends order_detailsUpdateArgs>(args: SelectSubset<T, order_detailsUpdateArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Order_details.
     * @param {order_detailsDeleteManyArgs} args - Arguments to filter Order_details to delete.
     * @example
     * // Delete a few Order_details
     * const { count } = await prisma.order_details.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends order_detailsDeleteManyArgs>(args?: SelectSubset<T, order_detailsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Order_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Order_details
     * const order_details = await prisma.order_details.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends order_detailsUpdateManyArgs>(args: SelectSubset<T, order_detailsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Order_details and returns the data updated in the database.
     * @param {order_detailsUpdateManyAndReturnArgs} args - Arguments to update many Order_details.
     * @example
     * // Update many Order_details
     * const order_details = await prisma.order_details.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Order_details and only return the `order_item_id`
     * const order_detailsWithOrder_item_idOnly = await prisma.order_details.updateManyAndReturn({
     *   select: { order_item_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends order_detailsUpdateManyAndReturnArgs>(args: SelectSubset<T, order_detailsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Order_details.
     * @param {order_detailsUpsertArgs} args - Arguments to update or create a Order_details.
     * @example
     * // Update or create a Order_details
     * const order_details = await prisma.order_details.upsert({
     *   create: {
     *     // ... data to create a Order_details
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Order_details we want to update
     *   }
     * })
     */
    upsert<T extends order_detailsUpsertArgs>(args: SelectSubset<T, order_detailsUpsertArgs<ExtArgs>>): Prisma__order_detailsClient<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Order_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsCountArgs} args - Arguments to filter Order_details to count.
     * @example
     * // Count the number of Order_details
     * const count = await prisma.order_details.count({
     *   where: {
     *     // ... the filter for the Order_details we want to count
     *   }
     * })
    **/
    count<T extends order_detailsCountArgs>(
      args?: Subset<T, order_detailsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Order_detailsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Order_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Order_detailsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Order_detailsAggregateArgs>(args: Subset<T, Order_detailsAggregateArgs>): Prisma.PrismaPromise<GetOrder_detailsAggregateType<T>>

    /**
     * Group by Order_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {order_detailsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends order_detailsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: order_detailsGroupByArgs['orderBy'] }
        : { orderBy?: order_detailsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, order_detailsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrder_detailsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the order_details model
   */
  readonly fields: order_detailsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for order_details.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__order_detailsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    order<T extends order_details$orderArgs<ExtArgs> = {}>(args?: Subset<T, order_details$orderArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    product<T extends order_details$productArgs<ExtArgs> = {}>(args?: Subset<T, order_details$productArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the order_details model
   */
  interface order_detailsFieldRefs {
    readonly order_item_id: FieldRef<"order_details", 'Int'>
    readonly order_id: FieldRef<"order_details", 'Int'>
    readonly product_id: FieldRef<"order_details", 'Int'>
    readonly quantity: FieldRef<"order_details", 'Int'>
    readonly price: FieldRef<"order_details", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * order_details findUnique
   */
  export type order_detailsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter, which order_details to fetch.
     */
    where: order_detailsWhereUniqueInput
  }

  /**
   * order_details findUniqueOrThrow
   */
  export type order_detailsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter, which order_details to fetch.
     */
    where: order_detailsWhereUniqueInput
  }

  /**
   * order_details findFirst
   */
  export type order_detailsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter, which order_details to fetch.
     */
    where?: order_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of order_details to fetch.
     */
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for order_details.
     */
    cursor?: order_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` order_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` order_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of order_details.
     */
    distinct?: Order_detailsScalarFieldEnum | Order_detailsScalarFieldEnum[]
  }

  /**
   * order_details findFirstOrThrow
   */
  export type order_detailsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter, which order_details to fetch.
     */
    where?: order_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of order_details to fetch.
     */
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for order_details.
     */
    cursor?: order_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` order_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` order_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of order_details.
     */
    distinct?: Order_detailsScalarFieldEnum | Order_detailsScalarFieldEnum[]
  }

  /**
   * order_details findMany
   */
  export type order_detailsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter, which order_details to fetch.
     */
    where?: order_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of order_details to fetch.
     */
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing order_details.
     */
    cursor?: order_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` order_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` order_details.
     */
    skip?: number
    distinct?: Order_detailsScalarFieldEnum | Order_detailsScalarFieldEnum[]
  }

  /**
   * order_details create
   */
  export type order_detailsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * The data needed to create a order_details.
     */
    data: XOR<order_detailsCreateInput, order_detailsUncheckedCreateInput>
  }

  /**
   * order_details createMany
   */
  export type order_detailsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many order_details.
     */
    data: order_detailsCreateManyInput | order_detailsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * order_details createManyAndReturn
   */
  export type order_detailsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * The data used to create many order_details.
     */
    data: order_detailsCreateManyInput | order_detailsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * order_details update
   */
  export type order_detailsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * The data needed to update a order_details.
     */
    data: XOR<order_detailsUpdateInput, order_detailsUncheckedUpdateInput>
    /**
     * Choose, which order_details to update.
     */
    where: order_detailsWhereUniqueInput
  }

  /**
   * order_details updateMany
   */
  export type order_detailsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update order_details.
     */
    data: XOR<order_detailsUpdateManyMutationInput, order_detailsUncheckedUpdateManyInput>
    /**
     * Filter which order_details to update
     */
    where?: order_detailsWhereInput
    /**
     * Limit how many order_details to update.
     */
    limit?: number
  }

  /**
   * order_details updateManyAndReturn
   */
  export type order_detailsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * The data used to update order_details.
     */
    data: XOR<order_detailsUpdateManyMutationInput, order_detailsUncheckedUpdateManyInput>
    /**
     * Filter which order_details to update
     */
    where?: order_detailsWhereInput
    /**
     * Limit how many order_details to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * order_details upsert
   */
  export type order_detailsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * The filter to search for the order_details to update in case it exists.
     */
    where: order_detailsWhereUniqueInput
    /**
     * In case the order_details found by the `where` argument doesn't exist, create a new order_details with this data.
     */
    create: XOR<order_detailsCreateInput, order_detailsUncheckedCreateInput>
    /**
     * In case the order_details was found with the provided `where` argument, update it with this data.
     */
    update: XOR<order_detailsUpdateInput, order_detailsUncheckedUpdateInput>
  }

  /**
   * order_details delete
   */
  export type order_detailsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    /**
     * Filter which order_details to delete.
     */
    where: order_detailsWhereUniqueInput
  }

  /**
   * order_details deleteMany
   */
  export type order_detailsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which order_details to delete
     */
    where?: order_detailsWhereInput
    /**
     * Limit how many order_details to delete.
     */
    limit?: number
  }

  /**
   * order_details.order
   */
  export type order_details$orderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    where?: orderWhereInput
  }

  /**
   * order_details.product
   */
  export type order_details$productArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    where?: productWhereInput
  }

  /**
   * order_details without action
   */
  export type order_detailsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
  }


  /**
   * Model payment
   */

  export type AggregatePayment = {
    _count: PaymentCountAggregateOutputType | null
    _avg: PaymentAvgAggregateOutputType | null
    _sum: PaymentSumAggregateOutputType | null
    _min: PaymentMinAggregateOutputType | null
    _max: PaymentMaxAggregateOutputType | null
  }

  export type PaymentAvgAggregateOutputType = {
    payment_id: number | null
    order_id: number | null
    amount: Decimal | null
  }

  export type PaymentSumAggregateOutputType = {
    payment_id: number | null
    order_id: number | null
    amount: Decimal | null
  }

  export type PaymentMinAggregateOutputType = {
    payment_id: number | null
    order_id: number | null
    amount: Decimal | null
    payment_mode: $Enums.payment_mode_enum | null
    payment_date: Date | null
    status: $Enums.payment_status_enum | null
  }

  export type PaymentMaxAggregateOutputType = {
    payment_id: number | null
    order_id: number | null
    amount: Decimal | null
    payment_mode: $Enums.payment_mode_enum | null
    payment_date: Date | null
    status: $Enums.payment_status_enum | null
  }

  export type PaymentCountAggregateOutputType = {
    payment_id: number
    order_id: number
    amount: number
    payment_mode: number
    payment_date: number
    status: number
    _all: number
  }


  export type PaymentAvgAggregateInputType = {
    payment_id?: true
    order_id?: true
    amount?: true
  }

  export type PaymentSumAggregateInputType = {
    payment_id?: true
    order_id?: true
    amount?: true
  }

  export type PaymentMinAggregateInputType = {
    payment_id?: true
    order_id?: true
    amount?: true
    payment_mode?: true
    payment_date?: true
    status?: true
  }

  export type PaymentMaxAggregateInputType = {
    payment_id?: true
    order_id?: true
    amount?: true
    payment_mode?: true
    payment_date?: true
    status?: true
  }

  export type PaymentCountAggregateInputType = {
    payment_id?: true
    order_id?: true
    amount?: true
    payment_mode?: true
    payment_date?: true
    status?: true
    _all?: true
  }

  export type PaymentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which payment to aggregate.
     */
    where?: paymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of payments to fetch.
     */
    orderBy?: paymentOrderByWithRelationInput | paymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: paymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned payments
    **/
    _count?: true | PaymentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PaymentAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PaymentSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaymentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaymentMaxAggregateInputType
  }

  export type GetPaymentAggregateType<T extends PaymentAggregateArgs> = {
        [P in keyof T & keyof AggregatePayment]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePayment[P]>
      : GetScalarType<T[P], AggregatePayment[P]>
  }




  export type paymentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paymentWhereInput
    orderBy?: paymentOrderByWithAggregationInput | paymentOrderByWithAggregationInput[]
    by: PaymentScalarFieldEnum[] | PaymentScalarFieldEnum
    having?: paymentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaymentCountAggregateInputType | true
    _avg?: PaymentAvgAggregateInputType
    _sum?: PaymentSumAggregateInputType
    _min?: PaymentMinAggregateInputType
    _max?: PaymentMaxAggregateInputType
  }

  export type PaymentGroupByOutputType = {
    payment_id: number
    order_id: number | null
    amount: Decimal
    payment_mode: $Enums.payment_mode_enum | null
    payment_date: Date | null
    status: $Enums.payment_status_enum | null
    _count: PaymentCountAggregateOutputType | null
    _avg: PaymentAvgAggregateOutputType | null
    _sum: PaymentSumAggregateOutputType | null
    _min: PaymentMinAggregateOutputType | null
    _max: PaymentMaxAggregateOutputType | null
  }

  type GetPaymentGroupByPayload<T extends paymentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaymentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaymentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaymentGroupByOutputType[P]>
            : GetScalarType<T[P], PaymentGroupByOutputType[P]>
        }
      >
    >


  export type paymentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    payment_id?: boolean
    order_id?: boolean
    amount?: boolean
    payment_mode?: boolean
    payment_date?: boolean
    status?: boolean
    order?: boolean | payment$orderArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type paymentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    payment_id?: boolean
    order_id?: boolean
    amount?: boolean
    payment_mode?: boolean
    payment_date?: boolean
    status?: boolean
    order?: boolean | payment$orderArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type paymentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    payment_id?: boolean
    order_id?: boolean
    amount?: boolean
    payment_mode?: boolean
    payment_date?: boolean
    status?: boolean
    order?: boolean | payment$orderArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type paymentSelectScalar = {
    payment_id?: boolean
    order_id?: boolean
    amount?: boolean
    payment_mode?: boolean
    payment_date?: boolean
    status?: boolean
  }

  export type paymentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"payment_id" | "order_id" | "amount" | "payment_mode" | "payment_date" | "status", ExtArgs["result"]["payment"]>
  export type paymentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | payment$orderArgs<ExtArgs>
  }
  export type paymentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | payment$orderArgs<ExtArgs>
  }
  export type paymentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | payment$orderArgs<ExtArgs>
  }

  export type $paymentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "payment"
    objects: {
      order: Prisma.$orderPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      payment_id: number
      order_id: number | null
      amount: Prisma.Decimal
      payment_mode: $Enums.payment_mode_enum | null
      payment_date: Date | null
      status: $Enums.payment_status_enum | null
    }, ExtArgs["result"]["payment"]>
    composites: {}
  }

  type paymentGetPayload<S extends boolean | null | undefined | paymentDefaultArgs> = $Result.GetResult<Prisma.$paymentPayload, S>

  type paymentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<paymentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaymentCountAggregateInputType | true
    }

  export interface paymentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['payment'], meta: { name: 'payment' } }
    /**
     * Find zero or one Payment that matches the filter.
     * @param {paymentFindUniqueArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends paymentFindUniqueArgs>(args: SelectSubset<T, paymentFindUniqueArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Payment that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {paymentFindUniqueOrThrowArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends paymentFindUniqueOrThrowArgs>(args: SelectSubset<T, paymentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Payment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentFindFirstArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends paymentFindFirstArgs>(args?: SelectSubset<T, paymentFindFirstArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Payment that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentFindFirstOrThrowArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends paymentFindFirstOrThrowArgs>(args?: SelectSubset<T, paymentFindFirstOrThrowArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Payments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Payments
     * const payments = await prisma.payment.findMany()
     * 
     * // Get first 10 Payments
     * const payments = await prisma.payment.findMany({ take: 10 })
     * 
     * // Only select the `payment_id`
     * const paymentWithPayment_idOnly = await prisma.payment.findMany({ select: { payment_id: true } })
     * 
     */
    findMany<T extends paymentFindManyArgs>(args?: SelectSubset<T, paymentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Payment.
     * @param {paymentCreateArgs} args - Arguments to create a Payment.
     * @example
     * // Create one Payment
     * const Payment = await prisma.payment.create({
     *   data: {
     *     // ... data to create a Payment
     *   }
     * })
     * 
     */
    create<T extends paymentCreateArgs>(args: SelectSubset<T, paymentCreateArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Payments.
     * @param {paymentCreateManyArgs} args - Arguments to create many Payments.
     * @example
     * // Create many Payments
     * const payment = await prisma.payment.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends paymentCreateManyArgs>(args?: SelectSubset<T, paymentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Payments and returns the data saved in the database.
     * @param {paymentCreateManyAndReturnArgs} args - Arguments to create many Payments.
     * @example
     * // Create many Payments
     * const payment = await prisma.payment.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Payments and only return the `payment_id`
     * const paymentWithPayment_idOnly = await prisma.payment.createManyAndReturn({
     *   select: { payment_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends paymentCreateManyAndReturnArgs>(args?: SelectSubset<T, paymentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Payment.
     * @param {paymentDeleteArgs} args - Arguments to delete one Payment.
     * @example
     * // Delete one Payment
     * const Payment = await prisma.payment.delete({
     *   where: {
     *     // ... filter to delete one Payment
     *   }
     * })
     * 
     */
    delete<T extends paymentDeleteArgs>(args: SelectSubset<T, paymentDeleteArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Payment.
     * @param {paymentUpdateArgs} args - Arguments to update one Payment.
     * @example
     * // Update one Payment
     * const payment = await prisma.payment.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends paymentUpdateArgs>(args: SelectSubset<T, paymentUpdateArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Payments.
     * @param {paymentDeleteManyArgs} args - Arguments to filter Payments to delete.
     * @example
     * // Delete a few Payments
     * const { count } = await prisma.payment.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends paymentDeleteManyArgs>(args?: SelectSubset<T, paymentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Payments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Payments
     * const payment = await prisma.payment.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends paymentUpdateManyArgs>(args: SelectSubset<T, paymentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Payments and returns the data updated in the database.
     * @param {paymentUpdateManyAndReturnArgs} args - Arguments to update many Payments.
     * @example
     * // Update many Payments
     * const payment = await prisma.payment.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Payments and only return the `payment_id`
     * const paymentWithPayment_idOnly = await prisma.payment.updateManyAndReturn({
     *   select: { payment_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends paymentUpdateManyAndReturnArgs>(args: SelectSubset<T, paymentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Payment.
     * @param {paymentUpsertArgs} args - Arguments to update or create a Payment.
     * @example
     * // Update or create a Payment
     * const payment = await prisma.payment.upsert({
     *   create: {
     *     // ... data to create a Payment
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Payment we want to update
     *   }
     * })
     */
    upsert<T extends paymentUpsertArgs>(args: SelectSubset<T, paymentUpsertArgs<ExtArgs>>): Prisma__paymentClient<$Result.GetResult<Prisma.$paymentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Payments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentCountArgs} args - Arguments to filter Payments to count.
     * @example
     * // Count the number of Payments
     * const count = await prisma.payment.count({
     *   where: {
     *     // ... the filter for the Payments we want to count
     *   }
     * })
    **/
    count<T extends paymentCountArgs>(
      args?: Subset<T, paymentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaymentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Payment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaymentAggregateArgs>(args: Subset<T, PaymentAggregateArgs>): Prisma.PrismaPromise<GetPaymentAggregateType<T>>

    /**
     * Group by Payment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paymentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends paymentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: paymentGroupByArgs['orderBy'] }
        : { orderBy?: paymentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, paymentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaymentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the payment model
   */
  readonly fields: paymentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for payment.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__paymentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    order<T extends payment$orderArgs<ExtArgs> = {}>(args?: Subset<T, payment$orderArgs<ExtArgs>>): Prisma__orderClient<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the payment model
   */
  interface paymentFieldRefs {
    readonly payment_id: FieldRef<"payment", 'Int'>
    readonly order_id: FieldRef<"payment", 'Int'>
    readonly amount: FieldRef<"payment", 'Decimal'>
    readonly payment_mode: FieldRef<"payment", 'payment_mode_enum'>
    readonly payment_date: FieldRef<"payment", 'DateTime'>
    readonly status: FieldRef<"payment", 'payment_status_enum'>
  }
    

  // Custom InputTypes
  /**
   * payment findUnique
   */
  export type paymentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter, which payment to fetch.
     */
    where: paymentWhereUniqueInput
  }

  /**
   * payment findUniqueOrThrow
   */
  export type paymentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter, which payment to fetch.
     */
    where: paymentWhereUniqueInput
  }

  /**
   * payment findFirst
   */
  export type paymentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter, which payment to fetch.
     */
    where?: paymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of payments to fetch.
     */
    orderBy?: paymentOrderByWithRelationInput | paymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for payments.
     */
    cursor?: paymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of payments.
     */
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * payment findFirstOrThrow
   */
  export type paymentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter, which payment to fetch.
     */
    where?: paymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of payments to fetch.
     */
    orderBy?: paymentOrderByWithRelationInput | paymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for payments.
     */
    cursor?: paymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of payments.
     */
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * payment findMany
   */
  export type paymentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter, which payments to fetch.
     */
    where?: paymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of payments to fetch.
     */
    orderBy?: paymentOrderByWithRelationInput | paymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing payments.
     */
    cursor?: paymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` payments.
     */
    skip?: number
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * payment create
   */
  export type paymentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * The data needed to create a payment.
     */
    data: XOR<paymentCreateInput, paymentUncheckedCreateInput>
  }

  /**
   * payment createMany
   */
  export type paymentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many payments.
     */
    data: paymentCreateManyInput | paymentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * payment createManyAndReturn
   */
  export type paymentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * The data used to create many payments.
     */
    data: paymentCreateManyInput | paymentCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * payment update
   */
  export type paymentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * The data needed to update a payment.
     */
    data: XOR<paymentUpdateInput, paymentUncheckedUpdateInput>
    /**
     * Choose, which payment to update.
     */
    where: paymentWhereUniqueInput
  }

  /**
   * payment updateMany
   */
  export type paymentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update payments.
     */
    data: XOR<paymentUpdateManyMutationInput, paymentUncheckedUpdateManyInput>
    /**
     * Filter which payments to update
     */
    where?: paymentWhereInput
    /**
     * Limit how many payments to update.
     */
    limit?: number
  }

  /**
   * payment updateManyAndReturn
   */
  export type paymentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * The data used to update payments.
     */
    data: XOR<paymentUpdateManyMutationInput, paymentUncheckedUpdateManyInput>
    /**
     * Filter which payments to update
     */
    where?: paymentWhereInput
    /**
     * Limit how many payments to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * payment upsert
   */
  export type paymentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * The filter to search for the payment to update in case it exists.
     */
    where: paymentWhereUniqueInput
    /**
     * In case the payment found by the `where` argument doesn't exist, create a new payment with this data.
     */
    create: XOR<paymentCreateInput, paymentUncheckedCreateInput>
    /**
     * In case the payment was found with the provided `where` argument, update it with this data.
     */
    update: XOR<paymentUpdateInput, paymentUncheckedUpdateInput>
  }

  /**
   * payment delete
   */
  export type paymentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
    /**
     * Filter which payment to delete.
     */
    where: paymentWhereUniqueInput
  }

  /**
   * payment deleteMany
   */
  export type paymentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which payments to delete
     */
    where?: paymentWhereInput
    /**
     * Limit how many payments to delete.
     */
    limit?: number
  }

  /**
   * payment.order
   */
  export type payment$orderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    where?: orderWhereInput
  }

  /**
   * payment without action
   */
  export type paymentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the payment
     */
    select?: paymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the payment
     */
    omit?: paymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paymentInclude<ExtArgs> | null
  }


  /**
   * Model product
   */

  export type AggregateProduct = {
    _count: ProductCountAggregateOutputType | null
    _avg: ProductAvgAggregateOutputType | null
    _sum: ProductSumAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  export type ProductAvgAggregateOutputType = {
    product_id: number | null
    min_stock_limit: number | null
    price: Decimal | null
  }

  export type ProductSumAggregateOutputType = {
    product_id: number | null
    min_stock_limit: number | null
    price: Decimal | null
  }

  export type ProductMinAggregateOutputType = {
    product_id: number | null
    name: string | null
    min_stock_limit: number | null
    description: string | null
    specifications: string | null
    price: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type ProductMaxAggregateOutputType = {
    product_id: number | null
    name: string | null
    min_stock_limit: number | null
    description: string | null
    specifications: string | null
    price: Decimal | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type ProductCountAggregateOutputType = {
    product_id: number
    name: number
    min_stock_limit: number
    description: number
    specifications: number
    image_url: number
    price: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type ProductAvgAggregateInputType = {
    product_id?: true
    min_stock_limit?: true
    price?: true
  }

  export type ProductSumAggregateInputType = {
    product_id?: true
    min_stock_limit?: true
    price?: true
  }

  export type ProductMinAggregateInputType = {
    product_id?: true
    name?: true
    min_stock_limit?: true
    description?: true
    specifications?: true
    price?: true
    created_at?: true
    updated_at?: true
  }

  export type ProductMaxAggregateInputType = {
    product_id?: true
    name?: true
    min_stock_limit?: true
    description?: true
    specifications?: true
    price?: true
    created_at?: true
    updated_at?: true
  }

  export type ProductCountAggregateInputType = {
    product_id?: true
    name?: true
    min_stock_limit?: true
    description?: true
    specifications?: true
    image_url?: true
    price?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type ProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which product to aggregate.
     */
    where?: productWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productOrderByWithRelationInput | productOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: productWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned products
    **/
    _count?: true | ProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProductAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProductSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductMaxAggregateInputType
  }

  export type GetProductAggregateType<T extends ProductAggregateArgs> = {
        [P in keyof T & keyof AggregateProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProduct[P]>
      : GetScalarType<T[P], AggregateProduct[P]>
  }




  export type productGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: productWhereInput
    orderBy?: productOrderByWithAggregationInput | productOrderByWithAggregationInput[]
    by: ProductScalarFieldEnum[] | ProductScalarFieldEnum
    having?: productScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductCountAggregateInputType | true
    _avg?: ProductAvgAggregateInputType
    _sum?: ProductSumAggregateInputType
    _min?: ProductMinAggregateInputType
    _max?: ProductMaxAggregateInputType
  }

  export type ProductGroupByOutputType = {
    product_id: number
    name: string
    min_stock_limit: number | null
    description: string | null
    specifications: string | null
    image_url: string[]
    price: Decimal
    created_at: Date | null
    updated_at: Date | null
    _count: ProductCountAggregateOutputType | null
    _avg: ProductAvgAggregateOutputType | null
    _sum: ProductSumAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  type GetProductGroupByPayload<T extends productGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductGroupByOutputType[P]>
            : GetScalarType<T[P], ProductGroupByOutputType[P]>
        }
      >
    >


  export type productSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    product_id?: boolean
    name?: boolean
    min_stock_limit?: boolean
    description?: boolean
    specifications?: boolean
    image_url?: boolean
    price?: boolean
    created_at?: boolean
    updated_at?: boolean
    inventory_inflow_outflow?: boolean | product$inventory_inflow_outflowArgs<ExtArgs>
    order_details?: boolean | product$order_detailsArgs<ExtArgs>
    quotation_details?: boolean | product$quotation_detailsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["product"]>

  export type productSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    product_id?: boolean
    name?: boolean
    min_stock_limit?: boolean
    description?: boolean
    specifications?: boolean
    image_url?: boolean
    price?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["product"]>

  export type productSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    product_id?: boolean
    name?: boolean
    min_stock_limit?: boolean
    description?: boolean
    specifications?: boolean
    image_url?: boolean
    price?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["product"]>

  export type productSelectScalar = {
    product_id?: boolean
    name?: boolean
    min_stock_limit?: boolean
    description?: boolean
    specifications?: boolean
    image_url?: boolean
    price?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type productOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"product_id" | "name" | "min_stock_limit" | "description" | "specifications" | "image_url" | "price" | "created_at" | "updated_at", ExtArgs["result"]["product"]>
  export type productInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    inventory_inflow_outflow?: boolean | product$inventory_inflow_outflowArgs<ExtArgs>
    order_details?: boolean | product$order_detailsArgs<ExtArgs>
    quotation_details?: boolean | product$quotation_detailsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type productIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type productIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $productPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "product"
    objects: {
      inventory_inflow_outflow: Prisma.$inventory_inflow_outflowPayload<ExtArgs>[]
      order_details: Prisma.$order_detailsPayload<ExtArgs>[]
      quotation_details: Prisma.$quotation_detailsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      product_id: number
      name: string
      min_stock_limit: number | null
      description: string | null
      specifications: string | null
      image_url: string[]
      price: Prisma.Decimal
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["product"]>
    composites: {}
  }

  type productGetPayload<S extends boolean | null | undefined | productDefaultArgs> = $Result.GetResult<Prisma.$productPayload, S>

  type productCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<productFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProductCountAggregateInputType | true
    }

  export interface productDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['product'], meta: { name: 'product' } }
    /**
     * Find zero or one Product that matches the filter.
     * @param {productFindUniqueArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends productFindUniqueArgs>(args: SelectSubset<T, productFindUniqueArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Product that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {productFindUniqueOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends productFindUniqueOrThrowArgs>(args: SelectSubset<T, productFindUniqueOrThrowArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Product that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productFindFirstArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends productFindFirstArgs>(args?: SelectSubset<T, productFindFirstArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Product that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productFindFirstOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends productFindFirstOrThrowArgs>(args?: SelectSubset<T, productFindFirstOrThrowArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Products that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Products
     * const products = await prisma.product.findMany()
     * 
     * // Get first 10 Products
     * const products = await prisma.product.findMany({ take: 10 })
     * 
     * // Only select the `product_id`
     * const productWithProduct_idOnly = await prisma.product.findMany({ select: { product_id: true } })
     * 
     */
    findMany<T extends productFindManyArgs>(args?: SelectSubset<T, productFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Product.
     * @param {productCreateArgs} args - Arguments to create a Product.
     * @example
     * // Create one Product
     * const Product = await prisma.product.create({
     *   data: {
     *     // ... data to create a Product
     *   }
     * })
     * 
     */
    create<T extends productCreateArgs>(args: SelectSubset<T, productCreateArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Products.
     * @param {productCreateManyArgs} args - Arguments to create many Products.
     * @example
     * // Create many Products
     * const product = await prisma.product.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends productCreateManyArgs>(args?: SelectSubset<T, productCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Products and returns the data saved in the database.
     * @param {productCreateManyAndReturnArgs} args - Arguments to create many Products.
     * @example
     * // Create many Products
     * const product = await prisma.product.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Products and only return the `product_id`
     * const productWithProduct_idOnly = await prisma.product.createManyAndReturn({
     *   select: { product_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends productCreateManyAndReturnArgs>(args?: SelectSubset<T, productCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Product.
     * @param {productDeleteArgs} args - Arguments to delete one Product.
     * @example
     * // Delete one Product
     * const Product = await prisma.product.delete({
     *   where: {
     *     // ... filter to delete one Product
     *   }
     * })
     * 
     */
    delete<T extends productDeleteArgs>(args: SelectSubset<T, productDeleteArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Product.
     * @param {productUpdateArgs} args - Arguments to update one Product.
     * @example
     * // Update one Product
     * const product = await prisma.product.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends productUpdateArgs>(args: SelectSubset<T, productUpdateArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Products.
     * @param {productDeleteManyArgs} args - Arguments to filter Products to delete.
     * @example
     * // Delete a few Products
     * const { count } = await prisma.product.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends productDeleteManyArgs>(args?: SelectSubset<T, productDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Products
     * const product = await prisma.product.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends productUpdateManyArgs>(args: SelectSubset<T, productUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products and returns the data updated in the database.
     * @param {productUpdateManyAndReturnArgs} args - Arguments to update many Products.
     * @example
     * // Update many Products
     * const product = await prisma.product.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Products and only return the `product_id`
     * const productWithProduct_idOnly = await prisma.product.updateManyAndReturn({
     *   select: { product_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends productUpdateManyAndReturnArgs>(args: SelectSubset<T, productUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Product.
     * @param {productUpsertArgs} args - Arguments to update or create a Product.
     * @example
     * // Update or create a Product
     * const product = await prisma.product.upsert({
     *   create: {
     *     // ... data to create a Product
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Product we want to update
     *   }
     * })
     */
    upsert<T extends productUpsertArgs>(args: SelectSubset<T, productUpsertArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productCountArgs} args - Arguments to filter Products to count.
     * @example
     * // Count the number of Products
     * const count = await prisma.product.count({
     *   where: {
     *     // ... the filter for the Products we want to count
     *   }
     * })
    **/
    count<T extends productCountArgs>(
      args?: Subset<T, productCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductAggregateArgs>(args: Subset<T, ProductAggregateArgs>): Prisma.PrismaPromise<GetProductAggregateType<T>>

    /**
     * Group by Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends productGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: productGroupByArgs['orderBy'] }
        : { orderBy?: productGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, productGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the product model
   */
  readonly fields: productFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for product.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__productClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    inventory_inflow_outflow<T extends product$inventory_inflow_outflowArgs<ExtArgs> = {}>(args?: Subset<T, product$inventory_inflow_outflowArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inventory_inflow_outflowPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    order_details<T extends product$order_detailsArgs<ExtArgs> = {}>(args?: Subset<T, product$order_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$order_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    quotation_details<T extends product$quotation_detailsArgs<ExtArgs> = {}>(args?: Subset<T, product$quotation_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the product model
   */
  interface productFieldRefs {
    readonly product_id: FieldRef<"product", 'Int'>
    readonly name: FieldRef<"product", 'String'>
    readonly min_stock_limit: FieldRef<"product", 'Int'>
    readonly description: FieldRef<"product", 'String'>
    readonly specifications: FieldRef<"product", 'String'>
    readonly image_url: FieldRef<"product", 'String[]'>
    readonly price: FieldRef<"product", 'Decimal'>
    readonly created_at: FieldRef<"product", 'DateTime'>
    readonly updated_at: FieldRef<"product", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * product findUnique
   */
  export type productFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter, which product to fetch.
     */
    where: productWhereUniqueInput
  }

  /**
   * product findUniqueOrThrow
   */
  export type productFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter, which product to fetch.
     */
    where: productWhereUniqueInput
  }

  /**
   * product findFirst
   */
  export type productFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter, which product to fetch.
     */
    where?: productWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productOrderByWithRelationInput | productOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for products.
     */
    cursor?: productWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * product findFirstOrThrow
   */
  export type productFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter, which product to fetch.
     */
    where?: productWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productOrderByWithRelationInput | productOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for products.
     */
    cursor?: productWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * product findMany
   */
  export type productFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where?: productWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productOrderByWithRelationInput | productOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing products.
     */
    cursor?: productWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * product create
   */
  export type productCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * The data needed to create a product.
     */
    data: XOR<productCreateInput, productUncheckedCreateInput>
  }

  /**
   * product createMany
   */
  export type productCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many products.
     */
    data: productCreateManyInput | productCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * product createManyAndReturn
   */
  export type productCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * The data used to create many products.
     */
    data: productCreateManyInput | productCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * product update
   */
  export type productUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * The data needed to update a product.
     */
    data: XOR<productUpdateInput, productUncheckedUpdateInput>
    /**
     * Choose, which product to update.
     */
    where: productWhereUniqueInput
  }

  /**
   * product updateMany
   */
  export type productUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update products.
     */
    data: XOR<productUpdateManyMutationInput, productUncheckedUpdateManyInput>
    /**
     * Filter which products to update
     */
    where?: productWhereInput
    /**
     * Limit how many products to update.
     */
    limit?: number
  }

  /**
   * product updateManyAndReturn
   */
  export type productUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * The data used to update products.
     */
    data: XOR<productUpdateManyMutationInput, productUncheckedUpdateManyInput>
    /**
     * Filter which products to update
     */
    where?: productWhereInput
    /**
     * Limit how many products to update.
     */
    limit?: number
  }

  /**
   * product upsert
   */
  export type productUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * The filter to search for the product to update in case it exists.
     */
    where: productWhereUniqueInput
    /**
     * In case the product found by the `where` argument doesn't exist, create a new product with this data.
     */
    create: XOR<productCreateInput, productUncheckedCreateInput>
    /**
     * In case the product was found with the provided `where` argument, update it with this data.
     */
    update: XOR<productUpdateInput, productUncheckedUpdateInput>
  }

  /**
   * product delete
   */
  export type productDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    /**
     * Filter which product to delete.
     */
    where: productWhereUniqueInput
  }

  /**
   * product deleteMany
   */
  export type productDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which products to delete
     */
    where?: productWhereInput
    /**
     * Limit how many products to delete.
     */
    limit?: number
  }

  /**
   * product.inventory_inflow_outflow
   */
  export type product$inventory_inflow_outflowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inventory_inflow_outflow
     */
    select?: inventory_inflow_outflowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inventory_inflow_outflow
     */
    omit?: inventory_inflow_outflowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inventory_inflow_outflowInclude<ExtArgs> | null
    where?: inventory_inflow_outflowWhereInput
    orderBy?: inventory_inflow_outflowOrderByWithRelationInput | inventory_inflow_outflowOrderByWithRelationInput[]
    cursor?: inventory_inflow_outflowWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Inventory_inflow_outflowScalarFieldEnum | Inventory_inflow_outflowScalarFieldEnum[]
  }

  /**
   * product.order_details
   */
  export type product$order_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order_details
     */
    select?: order_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order_details
     */
    omit?: order_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: order_detailsInclude<ExtArgs> | null
    where?: order_detailsWhereInput
    orderBy?: order_detailsOrderByWithRelationInput | order_detailsOrderByWithRelationInput[]
    cursor?: order_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Order_detailsScalarFieldEnum | Order_detailsScalarFieldEnum[]
  }

  /**
   * product.quotation_details
   */
  export type product$quotation_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    where?: quotation_detailsWhereInput
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    cursor?: quotation_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Quotation_detailsScalarFieldEnum | Quotation_detailsScalarFieldEnum[]
  }

  /**
   * product without action
   */
  export type productDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
  }


  /**
   * Model quotation
   */

  export type AggregateQuotation = {
    _count: QuotationCountAggregateOutputType | null
    _avg: QuotationAvgAggregateOutputType | null
    _sum: QuotationSumAggregateOutputType | null
    _min: QuotationMinAggregateOutputType | null
    _max: QuotationMaxAggregateOutputType | null
  }

  export type QuotationAvgAggregateOutputType = {
    quotation_id: number | null
    customer_id: number | null
    admin_id: number | null
    total_amount: Decimal | null
    credit_period: number | null
  }

  export type QuotationSumAggregateOutputType = {
    quotation_id: number | null
    customer_id: number | null
    admin_id: number | null
    total_amount: Decimal | null
    credit_period: number | null
  }

  export type QuotationMinAggregateOutputType = {
    quotation_id: number | null
    customer_id: number | null
    admin_id: number | null
    status: $Enums.quotation_status_enum | null
    total_amount: Decimal | null
    credit_period: number | null
    payment_mode: $Enums.payment_mode_enum | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type QuotationMaxAggregateOutputType = {
    quotation_id: number | null
    customer_id: number | null
    admin_id: number | null
    status: $Enums.quotation_status_enum | null
    total_amount: Decimal | null
    credit_period: number | null
    payment_mode: $Enums.payment_mode_enum | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type QuotationCountAggregateOutputType = {
    quotation_id: number
    customer_id: number
    admin_id: number
    status: number
    total_amount: number
    credit_period: number
    payment_mode: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type QuotationAvgAggregateInputType = {
    quotation_id?: true
    customer_id?: true
    admin_id?: true
    total_amount?: true
    credit_period?: true
  }

  export type QuotationSumAggregateInputType = {
    quotation_id?: true
    customer_id?: true
    admin_id?: true
    total_amount?: true
    credit_period?: true
  }

  export type QuotationMinAggregateInputType = {
    quotation_id?: true
    customer_id?: true
    admin_id?: true
    status?: true
    total_amount?: true
    credit_period?: true
    payment_mode?: true
    created_at?: true
    updated_at?: true
  }

  export type QuotationMaxAggregateInputType = {
    quotation_id?: true
    customer_id?: true
    admin_id?: true
    status?: true
    total_amount?: true
    credit_period?: true
    payment_mode?: true
    created_at?: true
    updated_at?: true
  }

  export type QuotationCountAggregateInputType = {
    quotation_id?: true
    customer_id?: true
    admin_id?: true
    status?: true
    total_amount?: true
    credit_period?: true
    payment_mode?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type QuotationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which quotation to aggregate.
     */
    where?: quotationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotations to fetch.
     */
    orderBy?: quotationOrderByWithRelationInput | quotationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: quotationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned quotations
    **/
    _count?: true | QuotationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: QuotationAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: QuotationSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: QuotationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: QuotationMaxAggregateInputType
  }

  export type GetQuotationAggregateType<T extends QuotationAggregateArgs> = {
        [P in keyof T & keyof AggregateQuotation]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateQuotation[P]>
      : GetScalarType<T[P], AggregateQuotation[P]>
  }




  export type quotationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: quotationWhereInput
    orderBy?: quotationOrderByWithAggregationInput | quotationOrderByWithAggregationInput[]
    by: QuotationScalarFieldEnum[] | QuotationScalarFieldEnum
    having?: quotationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: QuotationCountAggregateInputType | true
    _avg?: QuotationAvgAggregateInputType
    _sum?: QuotationSumAggregateInputType
    _min?: QuotationMinAggregateInputType
    _max?: QuotationMaxAggregateInputType
  }

  export type QuotationGroupByOutputType = {
    quotation_id: number
    customer_id: number | null
    admin_id: number | null
    status: $Enums.quotation_status_enum | null
    total_amount: Decimal | null
    credit_period: number | null
    payment_mode: $Enums.payment_mode_enum | null
    created_at: Date | null
    updated_at: Date | null
    _count: QuotationCountAggregateOutputType | null
    _avg: QuotationAvgAggregateOutputType | null
    _sum: QuotationSumAggregateOutputType | null
    _min: QuotationMinAggregateOutputType | null
    _max: QuotationMaxAggregateOutputType | null
  }

  type GetQuotationGroupByPayload<T extends quotationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<QuotationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof QuotationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], QuotationGroupByOutputType[P]>
            : GetScalarType<T[P], QuotationGroupByOutputType[P]>
        }
      >
    >


  export type quotationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_id?: boolean
    customer_id?: boolean
    admin_id?: boolean
    status?: boolean
    total_amount?: boolean
    credit_period?: boolean
    payment_mode?: boolean
    created_at?: boolean
    updated_at?: boolean
    order?: boolean | quotation$orderArgs<ExtArgs>
    customer?: boolean | quotation$customerArgs<ExtArgs>
    quotation_details?: boolean | quotation$quotation_detailsArgs<ExtArgs>
    _count?: boolean | QuotationCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["quotation"]>

  export type quotationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_id?: boolean
    customer_id?: boolean
    admin_id?: boolean
    status?: boolean
    total_amount?: boolean
    credit_period?: boolean
    payment_mode?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | quotation$customerArgs<ExtArgs>
  }, ExtArgs["result"]["quotation"]>

  export type quotationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_id?: boolean
    customer_id?: boolean
    admin_id?: boolean
    status?: boolean
    total_amount?: boolean
    credit_period?: boolean
    payment_mode?: boolean
    created_at?: boolean
    updated_at?: boolean
    customer?: boolean | quotation$customerArgs<ExtArgs>
  }, ExtArgs["result"]["quotation"]>

  export type quotationSelectScalar = {
    quotation_id?: boolean
    customer_id?: boolean
    admin_id?: boolean
    status?: boolean
    total_amount?: boolean
    credit_period?: boolean
    payment_mode?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type quotationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"quotation_id" | "customer_id" | "admin_id" | "status" | "total_amount" | "credit_period" | "payment_mode" | "created_at" | "updated_at", ExtArgs["result"]["quotation"]>
  export type quotationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    order?: boolean | quotation$orderArgs<ExtArgs>
    customer?: boolean | quotation$customerArgs<ExtArgs>
    quotation_details?: boolean | quotation$quotation_detailsArgs<ExtArgs>
    _count?: boolean | QuotationCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type quotationIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | quotation$customerArgs<ExtArgs>
  }
  export type quotationIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | quotation$customerArgs<ExtArgs>
  }

  export type $quotationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "quotation"
    objects: {
      order: Prisma.$orderPayload<ExtArgs>[]
      customer: Prisma.$customerPayload<ExtArgs> | null
      quotation_details: Prisma.$quotation_detailsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      quotation_id: number
      customer_id: number | null
      admin_id: number | null
      status: $Enums.quotation_status_enum | null
      total_amount: Prisma.Decimal | null
      credit_period: number | null
      payment_mode: $Enums.payment_mode_enum | null
      created_at: Date | null
      updated_at: Date | null
    }, ExtArgs["result"]["quotation"]>
    composites: {}
  }

  type quotationGetPayload<S extends boolean | null | undefined | quotationDefaultArgs> = $Result.GetResult<Prisma.$quotationPayload, S>

  type quotationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<quotationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: QuotationCountAggregateInputType | true
    }

  export interface quotationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['quotation'], meta: { name: 'quotation' } }
    /**
     * Find zero or one Quotation that matches the filter.
     * @param {quotationFindUniqueArgs} args - Arguments to find a Quotation
     * @example
     * // Get one Quotation
     * const quotation = await prisma.quotation.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends quotationFindUniqueArgs>(args: SelectSubset<T, quotationFindUniqueArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Quotation that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {quotationFindUniqueOrThrowArgs} args - Arguments to find a Quotation
     * @example
     * // Get one Quotation
     * const quotation = await prisma.quotation.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends quotationFindUniqueOrThrowArgs>(args: SelectSubset<T, quotationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Quotation that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationFindFirstArgs} args - Arguments to find a Quotation
     * @example
     * // Get one Quotation
     * const quotation = await prisma.quotation.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends quotationFindFirstArgs>(args?: SelectSubset<T, quotationFindFirstArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Quotation that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationFindFirstOrThrowArgs} args - Arguments to find a Quotation
     * @example
     * // Get one Quotation
     * const quotation = await prisma.quotation.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends quotationFindFirstOrThrowArgs>(args?: SelectSubset<T, quotationFindFirstOrThrowArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Quotations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Quotations
     * const quotations = await prisma.quotation.findMany()
     * 
     * // Get first 10 Quotations
     * const quotations = await prisma.quotation.findMany({ take: 10 })
     * 
     * // Only select the `quotation_id`
     * const quotationWithQuotation_idOnly = await prisma.quotation.findMany({ select: { quotation_id: true } })
     * 
     */
    findMany<T extends quotationFindManyArgs>(args?: SelectSubset<T, quotationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Quotation.
     * @param {quotationCreateArgs} args - Arguments to create a Quotation.
     * @example
     * // Create one Quotation
     * const Quotation = await prisma.quotation.create({
     *   data: {
     *     // ... data to create a Quotation
     *   }
     * })
     * 
     */
    create<T extends quotationCreateArgs>(args: SelectSubset<T, quotationCreateArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Quotations.
     * @param {quotationCreateManyArgs} args - Arguments to create many Quotations.
     * @example
     * // Create many Quotations
     * const quotation = await prisma.quotation.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends quotationCreateManyArgs>(args?: SelectSubset<T, quotationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Quotations and returns the data saved in the database.
     * @param {quotationCreateManyAndReturnArgs} args - Arguments to create many Quotations.
     * @example
     * // Create many Quotations
     * const quotation = await prisma.quotation.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Quotations and only return the `quotation_id`
     * const quotationWithQuotation_idOnly = await prisma.quotation.createManyAndReturn({
     *   select: { quotation_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends quotationCreateManyAndReturnArgs>(args?: SelectSubset<T, quotationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Quotation.
     * @param {quotationDeleteArgs} args - Arguments to delete one Quotation.
     * @example
     * // Delete one Quotation
     * const Quotation = await prisma.quotation.delete({
     *   where: {
     *     // ... filter to delete one Quotation
     *   }
     * })
     * 
     */
    delete<T extends quotationDeleteArgs>(args: SelectSubset<T, quotationDeleteArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Quotation.
     * @param {quotationUpdateArgs} args - Arguments to update one Quotation.
     * @example
     * // Update one Quotation
     * const quotation = await prisma.quotation.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends quotationUpdateArgs>(args: SelectSubset<T, quotationUpdateArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Quotations.
     * @param {quotationDeleteManyArgs} args - Arguments to filter Quotations to delete.
     * @example
     * // Delete a few Quotations
     * const { count } = await prisma.quotation.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends quotationDeleteManyArgs>(args?: SelectSubset<T, quotationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Quotations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Quotations
     * const quotation = await prisma.quotation.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends quotationUpdateManyArgs>(args: SelectSubset<T, quotationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Quotations and returns the data updated in the database.
     * @param {quotationUpdateManyAndReturnArgs} args - Arguments to update many Quotations.
     * @example
     * // Update many Quotations
     * const quotation = await prisma.quotation.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Quotations and only return the `quotation_id`
     * const quotationWithQuotation_idOnly = await prisma.quotation.updateManyAndReturn({
     *   select: { quotation_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends quotationUpdateManyAndReturnArgs>(args: SelectSubset<T, quotationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Quotation.
     * @param {quotationUpsertArgs} args - Arguments to update or create a Quotation.
     * @example
     * // Update or create a Quotation
     * const quotation = await prisma.quotation.upsert({
     *   create: {
     *     // ... data to create a Quotation
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Quotation we want to update
     *   }
     * })
     */
    upsert<T extends quotationUpsertArgs>(args: SelectSubset<T, quotationUpsertArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Quotations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationCountArgs} args - Arguments to filter Quotations to count.
     * @example
     * // Count the number of Quotations
     * const count = await prisma.quotation.count({
     *   where: {
     *     // ... the filter for the Quotations we want to count
     *   }
     * })
    **/
    count<T extends quotationCountArgs>(
      args?: Subset<T, quotationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], QuotationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Quotation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {QuotationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends QuotationAggregateArgs>(args: Subset<T, QuotationAggregateArgs>): Prisma.PrismaPromise<GetQuotationAggregateType<T>>

    /**
     * Group by Quotation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends quotationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: quotationGroupByArgs['orderBy'] }
        : { orderBy?: quotationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, quotationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetQuotationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the quotation model
   */
  readonly fields: quotationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for quotation.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__quotationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    order<T extends quotation$orderArgs<ExtArgs> = {}>(args?: Subset<T, quotation$orderArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$orderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    customer<T extends quotation$customerArgs<ExtArgs> = {}>(args?: Subset<T, quotation$customerArgs<ExtArgs>>): Prisma__customerClient<$Result.GetResult<Prisma.$customerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    quotation_details<T extends quotation$quotation_detailsArgs<ExtArgs> = {}>(args?: Subset<T, quotation$quotation_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the quotation model
   */
  interface quotationFieldRefs {
    readonly quotation_id: FieldRef<"quotation", 'Int'>
    readonly customer_id: FieldRef<"quotation", 'Int'>
    readonly admin_id: FieldRef<"quotation", 'Int'>
    readonly status: FieldRef<"quotation", 'quotation_status_enum'>
    readonly total_amount: FieldRef<"quotation", 'Decimal'>
    readonly credit_period: FieldRef<"quotation", 'Int'>
    readonly payment_mode: FieldRef<"quotation", 'payment_mode_enum'>
    readonly created_at: FieldRef<"quotation", 'DateTime'>
    readonly updated_at: FieldRef<"quotation", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * quotation findUnique
   */
  export type quotationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter, which quotation to fetch.
     */
    where: quotationWhereUniqueInput
  }

  /**
   * quotation findUniqueOrThrow
   */
  export type quotationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter, which quotation to fetch.
     */
    where: quotationWhereUniqueInput
  }

  /**
   * quotation findFirst
   */
  export type quotationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter, which quotation to fetch.
     */
    where?: quotationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotations to fetch.
     */
    orderBy?: quotationOrderByWithRelationInput | quotationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for quotations.
     */
    cursor?: quotationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of quotations.
     */
    distinct?: QuotationScalarFieldEnum | QuotationScalarFieldEnum[]
  }

  /**
   * quotation findFirstOrThrow
   */
  export type quotationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter, which quotation to fetch.
     */
    where?: quotationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotations to fetch.
     */
    orderBy?: quotationOrderByWithRelationInput | quotationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for quotations.
     */
    cursor?: quotationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of quotations.
     */
    distinct?: QuotationScalarFieldEnum | QuotationScalarFieldEnum[]
  }

  /**
   * quotation findMany
   */
  export type quotationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter, which quotations to fetch.
     */
    where?: quotationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotations to fetch.
     */
    orderBy?: quotationOrderByWithRelationInput | quotationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing quotations.
     */
    cursor?: quotationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotations.
     */
    skip?: number
    distinct?: QuotationScalarFieldEnum | QuotationScalarFieldEnum[]
  }

  /**
   * quotation create
   */
  export type quotationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * The data needed to create a quotation.
     */
    data?: XOR<quotationCreateInput, quotationUncheckedCreateInput>
  }

  /**
   * quotation createMany
   */
  export type quotationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many quotations.
     */
    data: quotationCreateManyInput | quotationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * quotation createManyAndReturn
   */
  export type quotationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * The data used to create many quotations.
     */
    data: quotationCreateManyInput | quotationCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * quotation update
   */
  export type quotationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * The data needed to update a quotation.
     */
    data: XOR<quotationUpdateInput, quotationUncheckedUpdateInput>
    /**
     * Choose, which quotation to update.
     */
    where: quotationWhereUniqueInput
  }

  /**
   * quotation updateMany
   */
  export type quotationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update quotations.
     */
    data: XOR<quotationUpdateManyMutationInput, quotationUncheckedUpdateManyInput>
    /**
     * Filter which quotations to update
     */
    where?: quotationWhereInput
    /**
     * Limit how many quotations to update.
     */
    limit?: number
  }

  /**
   * quotation updateManyAndReturn
   */
  export type quotationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * The data used to update quotations.
     */
    data: XOR<quotationUpdateManyMutationInput, quotationUncheckedUpdateManyInput>
    /**
     * Filter which quotations to update
     */
    where?: quotationWhereInput
    /**
     * Limit how many quotations to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * quotation upsert
   */
  export type quotationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * The filter to search for the quotation to update in case it exists.
     */
    where: quotationWhereUniqueInput
    /**
     * In case the quotation found by the `where` argument doesn't exist, create a new quotation with this data.
     */
    create: XOR<quotationCreateInput, quotationUncheckedCreateInput>
    /**
     * In case the quotation was found with the provided `where` argument, update it with this data.
     */
    update: XOR<quotationUpdateInput, quotationUncheckedUpdateInput>
  }

  /**
   * quotation delete
   */
  export type quotationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    /**
     * Filter which quotation to delete.
     */
    where: quotationWhereUniqueInput
  }

  /**
   * quotation deleteMany
   */
  export type quotationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which quotations to delete
     */
    where?: quotationWhereInput
    /**
     * Limit how many quotations to delete.
     */
    limit?: number
  }

  /**
   * quotation.order
   */
  export type quotation$orderArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the order
     */
    select?: orderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the order
     */
    omit?: orderOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: orderInclude<ExtArgs> | null
    where?: orderWhereInput
    orderBy?: orderOrderByWithRelationInput | orderOrderByWithRelationInput[]
    cursor?: orderWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrderScalarFieldEnum | OrderScalarFieldEnum[]
  }

  /**
   * quotation.customer
   */
  export type quotation$customerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the customer
     */
    select?: customerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the customer
     */
    omit?: customerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: customerInclude<ExtArgs> | null
    where?: customerWhereInput
  }

  /**
   * quotation.quotation_details
   */
  export type quotation$quotation_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    where?: quotation_detailsWhereInput
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    cursor?: quotation_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Quotation_detailsScalarFieldEnum | Quotation_detailsScalarFieldEnum[]
  }

  /**
   * quotation without action
   */
  export type quotationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
  }


  /**
   * Model quotation_details
   */

  export type AggregateQuotation_details = {
    _count: Quotation_detailsCountAggregateOutputType | null
    _avg: Quotation_detailsAvgAggregateOutputType | null
    _sum: Quotation_detailsSumAggregateOutputType | null
    _min: Quotation_detailsMinAggregateOutputType | null
    _max: Quotation_detailsMaxAggregateOutputType | null
  }

  export type Quotation_detailsAvgAggregateOutputType = {
    quotation_item_id: number | null
    quotation_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Quotation_detailsSumAggregateOutputType = {
    quotation_item_id: number | null
    quotation_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Quotation_detailsMinAggregateOutputType = {
    quotation_item_id: number | null
    quotation_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Quotation_detailsMaxAggregateOutputType = {
    quotation_item_id: number | null
    quotation_id: number | null
    product_id: number | null
    quantity: number | null
    price: Decimal | null
  }

  export type Quotation_detailsCountAggregateOutputType = {
    quotation_item_id: number
    quotation_id: number
    product_id: number
    quantity: number
    price: number
    _all: number
  }


  export type Quotation_detailsAvgAggregateInputType = {
    quotation_item_id?: true
    quotation_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Quotation_detailsSumAggregateInputType = {
    quotation_item_id?: true
    quotation_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Quotation_detailsMinAggregateInputType = {
    quotation_item_id?: true
    quotation_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Quotation_detailsMaxAggregateInputType = {
    quotation_item_id?: true
    quotation_id?: true
    product_id?: true
    quantity?: true
    price?: true
  }

  export type Quotation_detailsCountAggregateInputType = {
    quotation_item_id?: true
    quotation_id?: true
    product_id?: true
    quantity?: true
    price?: true
    _all?: true
  }

  export type Quotation_detailsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which quotation_details to aggregate.
     */
    where?: quotation_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotation_details to fetch.
     */
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: quotation_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotation_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotation_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned quotation_details
    **/
    _count?: true | Quotation_detailsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Quotation_detailsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Quotation_detailsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Quotation_detailsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Quotation_detailsMaxAggregateInputType
  }

  export type GetQuotation_detailsAggregateType<T extends Quotation_detailsAggregateArgs> = {
        [P in keyof T & keyof AggregateQuotation_details]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateQuotation_details[P]>
      : GetScalarType<T[P], AggregateQuotation_details[P]>
  }




  export type quotation_detailsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: quotation_detailsWhereInput
    orderBy?: quotation_detailsOrderByWithAggregationInput | quotation_detailsOrderByWithAggregationInput[]
    by: Quotation_detailsScalarFieldEnum[] | Quotation_detailsScalarFieldEnum
    having?: quotation_detailsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Quotation_detailsCountAggregateInputType | true
    _avg?: Quotation_detailsAvgAggregateInputType
    _sum?: Quotation_detailsSumAggregateInputType
    _min?: Quotation_detailsMinAggregateInputType
    _max?: Quotation_detailsMaxAggregateInputType
  }

  export type Quotation_detailsGroupByOutputType = {
    quotation_item_id: number
    quotation_id: number | null
    product_id: number | null
    quantity: number
    price: Decimal | null
    _count: Quotation_detailsCountAggregateOutputType | null
    _avg: Quotation_detailsAvgAggregateOutputType | null
    _sum: Quotation_detailsSumAggregateOutputType | null
    _min: Quotation_detailsMinAggregateOutputType | null
    _max: Quotation_detailsMaxAggregateOutputType | null
  }

  type GetQuotation_detailsGroupByPayload<T extends quotation_detailsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Quotation_detailsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Quotation_detailsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Quotation_detailsGroupByOutputType[P]>
            : GetScalarType<T[P], Quotation_detailsGroupByOutputType[P]>
        }
      >
    >


  export type quotation_detailsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_item_id?: boolean
    quotation_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }, ExtArgs["result"]["quotation_details"]>

  export type quotation_detailsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_item_id?: boolean
    quotation_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }, ExtArgs["result"]["quotation_details"]>

  export type quotation_detailsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    quotation_item_id?: boolean
    quotation_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }, ExtArgs["result"]["quotation_details"]>

  export type quotation_detailsSelectScalar = {
    quotation_item_id?: boolean
    quotation_id?: boolean
    product_id?: boolean
    quantity?: boolean
    price?: boolean
  }

  export type quotation_detailsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"quotation_item_id" | "quotation_id" | "product_id" | "quantity" | "price", ExtArgs["result"]["quotation_details"]>
  export type quotation_detailsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }
  export type quotation_detailsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }
  export type quotation_detailsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | quotation_details$productArgs<ExtArgs>
    quotation?: boolean | quotation_details$quotationArgs<ExtArgs>
  }

  export type $quotation_detailsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "quotation_details"
    objects: {
      product: Prisma.$productPayload<ExtArgs> | null
      quotation: Prisma.$quotationPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      quotation_item_id: number
      quotation_id: number | null
      product_id: number | null
      quantity: number
      price: Prisma.Decimal | null
    }, ExtArgs["result"]["quotation_details"]>
    composites: {}
  }

  type quotation_detailsGetPayload<S extends boolean | null | undefined | quotation_detailsDefaultArgs> = $Result.GetResult<Prisma.$quotation_detailsPayload, S>

  type quotation_detailsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<quotation_detailsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Quotation_detailsCountAggregateInputType | true
    }

  export interface quotation_detailsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['quotation_details'], meta: { name: 'quotation_details' } }
    /**
     * Find zero or one Quotation_details that matches the filter.
     * @param {quotation_detailsFindUniqueArgs} args - Arguments to find a Quotation_details
     * @example
     * // Get one Quotation_details
     * const quotation_details = await prisma.quotation_details.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends quotation_detailsFindUniqueArgs>(args: SelectSubset<T, quotation_detailsFindUniqueArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Quotation_details that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {quotation_detailsFindUniqueOrThrowArgs} args - Arguments to find a Quotation_details
     * @example
     * // Get one Quotation_details
     * const quotation_details = await prisma.quotation_details.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends quotation_detailsFindUniqueOrThrowArgs>(args: SelectSubset<T, quotation_detailsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Quotation_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsFindFirstArgs} args - Arguments to find a Quotation_details
     * @example
     * // Get one Quotation_details
     * const quotation_details = await prisma.quotation_details.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends quotation_detailsFindFirstArgs>(args?: SelectSubset<T, quotation_detailsFindFirstArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Quotation_details that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsFindFirstOrThrowArgs} args - Arguments to find a Quotation_details
     * @example
     * // Get one Quotation_details
     * const quotation_details = await prisma.quotation_details.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends quotation_detailsFindFirstOrThrowArgs>(args?: SelectSubset<T, quotation_detailsFindFirstOrThrowArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Quotation_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Quotation_details
     * const quotation_details = await prisma.quotation_details.findMany()
     * 
     * // Get first 10 Quotation_details
     * const quotation_details = await prisma.quotation_details.findMany({ take: 10 })
     * 
     * // Only select the `quotation_item_id`
     * const quotation_detailsWithQuotation_item_idOnly = await prisma.quotation_details.findMany({ select: { quotation_item_id: true } })
     * 
     */
    findMany<T extends quotation_detailsFindManyArgs>(args?: SelectSubset<T, quotation_detailsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Quotation_details.
     * @param {quotation_detailsCreateArgs} args - Arguments to create a Quotation_details.
     * @example
     * // Create one Quotation_details
     * const Quotation_details = await prisma.quotation_details.create({
     *   data: {
     *     // ... data to create a Quotation_details
     *   }
     * })
     * 
     */
    create<T extends quotation_detailsCreateArgs>(args: SelectSubset<T, quotation_detailsCreateArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Quotation_details.
     * @param {quotation_detailsCreateManyArgs} args - Arguments to create many Quotation_details.
     * @example
     * // Create many Quotation_details
     * const quotation_details = await prisma.quotation_details.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends quotation_detailsCreateManyArgs>(args?: SelectSubset<T, quotation_detailsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Quotation_details and returns the data saved in the database.
     * @param {quotation_detailsCreateManyAndReturnArgs} args - Arguments to create many Quotation_details.
     * @example
     * // Create many Quotation_details
     * const quotation_details = await prisma.quotation_details.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Quotation_details and only return the `quotation_item_id`
     * const quotation_detailsWithQuotation_item_idOnly = await prisma.quotation_details.createManyAndReturn({
     *   select: { quotation_item_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends quotation_detailsCreateManyAndReturnArgs>(args?: SelectSubset<T, quotation_detailsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Quotation_details.
     * @param {quotation_detailsDeleteArgs} args - Arguments to delete one Quotation_details.
     * @example
     * // Delete one Quotation_details
     * const Quotation_details = await prisma.quotation_details.delete({
     *   where: {
     *     // ... filter to delete one Quotation_details
     *   }
     * })
     * 
     */
    delete<T extends quotation_detailsDeleteArgs>(args: SelectSubset<T, quotation_detailsDeleteArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Quotation_details.
     * @param {quotation_detailsUpdateArgs} args - Arguments to update one Quotation_details.
     * @example
     * // Update one Quotation_details
     * const quotation_details = await prisma.quotation_details.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends quotation_detailsUpdateArgs>(args: SelectSubset<T, quotation_detailsUpdateArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Quotation_details.
     * @param {quotation_detailsDeleteManyArgs} args - Arguments to filter Quotation_details to delete.
     * @example
     * // Delete a few Quotation_details
     * const { count } = await prisma.quotation_details.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends quotation_detailsDeleteManyArgs>(args?: SelectSubset<T, quotation_detailsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Quotation_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Quotation_details
     * const quotation_details = await prisma.quotation_details.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends quotation_detailsUpdateManyArgs>(args: SelectSubset<T, quotation_detailsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Quotation_details and returns the data updated in the database.
     * @param {quotation_detailsUpdateManyAndReturnArgs} args - Arguments to update many Quotation_details.
     * @example
     * // Update many Quotation_details
     * const quotation_details = await prisma.quotation_details.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Quotation_details and only return the `quotation_item_id`
     * const quotation_detailsWithQuotation_item_idOnly = await prisma.quotation_details.updateManyAndReturn({
     *   select: { quotation_item_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends quotation_detailsUpdateManyAndReturnArgs>(args: SelectSubset<T, quotation_detailsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Quotation_details.
     * @param {quotation_detailsUpsertArgs} args - Arguments to update or create a Quotation_details.
     * @example
     * // Update or create a Quotation_details
     * const quotation_details = await prisma.quotation_details.upsert({
     *   create: {
     *     // ... data to create a Quotation_details
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Quotation_details we want to update
     *   }
     * })
     */
    upsert<T extends quotation_detailsUpsertArgs>(args: SelectSubset<T, quotation_detailsUpsertArgs<ExtArgs>>): Prisma__quotation_detailsClient<$Result.GetResult<Prisma.$quotation_detailsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Quotation_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsCountArgs} args - Arguments to filter Quotation_details to count.
     * @example
     * // Count the number of Quotation_details
     * const count = await prisma.quotation_details.count({
     *   where: {
     *     // ... the filter for the Quotation_details we want to count
     *   }
     * })
    **/
    count<T extends quotation_detailsCountArgs>(
      args?: Subset<T, quotation_detailsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Quotation_detailsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Quotation_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Quotation_detailsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Quotation_detailsAggregateArgs>(args: Subset<T, Quotation_detailsAggregateArgs>): Prisma.PrismaPromise<GetQuotation_detailsAggregateType<T>>

    /**
     * Group by Quotation_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {quotation_detailsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends quotation_detailsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: quotation_detailsGroupByArgs['orderBy'] }
        : { orderBy?: quotation_detailsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, quotation_detailsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetQuotation_detailsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the quotation_details model
   */
  readonly fields: quotation_detailsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for quotation_details.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__quotation_detailsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    product<T extends quotation_details$productArgs<ExtArgs> = {}>(args?: Subset<T, quotation_details$productArgs<ExtArgs>>): Prisma__productClient<$Result.GetResult<Prisma.$productPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    quotation<T extends quotation_details$quotationArgs<ExtArgs> = {}>(args?: Subset<T, quotation_details$quotationArgs<ExtArgs>>): Prisma__quotationClient<$Result.GetResult<Prisma.$quotationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the quotation_details model
   */
  interface quotation_detailsFieldRefs {
    readonly quotation_item_id: FieldRef<"quotation_details", 'Int'>
    readonly quotation_id: FieldRef<"quotation_details", 'Int'>
    readonly product_id: FieldRef<"quotation_details", 'Int'>
    readonly quantity: FieldRef<"quotation_details", 'Int'>
    readonly price: FieldRef<"quotation_details", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * quotation_details findUnique
   */
  export type quotation_detailsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter, which quotation_details to fetch.
     */
    where: quotation_detailsWhereUniqueInput
  }

  /**
   * quotation_details findUniqueOrThrow
   */
  export type quotation_detailsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter, which quotation_details to fetch.
     */
    where: quotation_detailsWhereUniqueInput
  }

  /**
   * quotation_details findFirst
   */
  export type quotation_detailsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter, which quotation_details to fetch.
     */
    where?: quotation_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotation_details to fetch.
     */
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for quotation_details.
     */
    cursor?: quotation_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotation_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotation_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of quotation_details.
     */
    distinct?: Quotation_detailsScalarFieldEnum | Quotation_detailsScalarFieldEnum[]
  }

  /**
   * quotation_details findFirstOrThrow
   */
  export type quotation_detailsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter, which quotation_details to fetch.
     */
    where?: quotation_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotation_details to fetch.
     */
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for quotation_details.
     */
    cursor?: quotation_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotation_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotation_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of quotation_details.
     */
    distinct?: Quotation_detailsScalarFieldEnum | Quotation_detailsScalarFieldEnum[]
  }

  /**
   * quotation_details findMany
   */
  export type quotation_detailsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter, which quotation_details to fetch.
     */
    where?: quotation_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of quotation_details to fetch.
     */
    orderBy?: quotation_detailsOrderByWithRelationInput | quotation_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing quotation_details.
     */
    cursor?: quotation_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` quotation_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` quotation_details.
     */
    skip?: number
    distinct?: Quotation_detailsScalarFieldEnum | Quotation_detailsScalarFieldEnum[]
  }

  /**
   * quotation_details create
   */
  export type quotation_detailsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * The data needed to create a quotation_details.
     */
    data: XOR<quotation_detailsCreateInput, quotation_detailsUncheckedCreateInput>
  }

  /**
   * quotation_details createMany
   */
  export type quotation_detailsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many quotation_details.
     */
    data: quotation_detailsCreateManyInput | quotation_detailsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * quotation_details createManyAndReturn
   */
  export type quotation_detailsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * The data used to create many quotation_details.
     */
    data: quotation_detailsCreateManyInput | quotation_detailsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * quotation_details update
   */
  export type quotation_detailsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * The data needed to update a quotation_details.
     */
    data: XOR<quotation_detailsUpdateInput, quotation_detailsUncheckedUpdateInput>
    /**
     * Choose, which quotation_details to update.
     */
    where: quotation_detailsWhereUniqueInput
  }

  /**
   * quotation_details updateMany
   */
  export type quotation_detailsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update quotation_details.
     */
    data: XOR<quotation_detailsUpdateManyMutationInput, quotation_detailsUncheckedUpdateManyInput>
    /**
     * Filter which quotation_details to update
     */
    where?: quotation_detailsWhereInput
    /**
     * Limit how many quotation_details to update.
     */
    limit?: number
  }

  /**
   * quotation_details updateManyAndReturn
   */
  export type quotation_detailsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * The data used to update quotation_details.
     */
    data: XOR<quotation_detailsUpdateManyMutationInput, quotation_detailsUncheckedUpdateManyInput>
    /**
     * Filter which quotation_details to update
     */
    where?: quotation_detailsWhereInput
    /**
     * Limit how many quotation_details to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * quotation_details upsert
   */
  export type quotation_detailsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * The filter to search for the quotation_details to update in case it exists.
     */
    where: quotation_detailsWhereUniqueInput
    /**
     * In case the quotation_details found by the `where` argument doesn't exist, create a new quotation_details with this data.
     */
    create: XOR<quotation_detailsCreateInput, quotation_detailsUncheckedCreateInput>
    /**
     * In case the quotation_details was found with the provided `where` argument, update it with this data.
     */
    update: XOR<quotation_detailsUpdateInput, quotation_detailsUncheckedUpdateInput>
  }

  /**
   * quotation_details delete
   */
  export type quotation_detailsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
    /**
     * Filter which quotation_details to delete.
     */
    where: quotation_detailsWhereUniqueInput
  }

  /**
   * quotation_details deleteMany
   */
  export type quotation_detailsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which quotation_details to delete
     */
    where?: quotation_detailsWhereInput
    /**
     * Limit how many quotation_details to delete.
     */
    limit?: number
  }

  /**
   * quotation_details.product
   */
  export type quotation_details$productArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the product
     */
    select?: productSelect<ExtArgs> | null
    /**
     * Omit specific fields from the product
     */
    omit?: productOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productInclude<ExtArgs> | null
    where?: productWhereInput
  }

  /**
   * quotation_details.quotation
   */
  export type quotation_details$quotationArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation
     */
    select?: quotationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation
     */
    omit?: quotationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotationInclude<ExtArgs> | null
    where?: quotationWhereInput
  }

  /**
   * quotation_details without action
   */
  export type quotation_detailsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the quotation_details
     */
    select?: quotation_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the quotation_details
     */
    omit?: quotation_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: quotation_detailsInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const AdminScalarFieldEnum: {
    admin_id: 'admin_id',
    username: 'username',
    password: 'password',
    roles: 'roles',
    email: 'email',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type AdminScalarFieldEnum = (typeof AdminScalarFieldEnum)[keyof typeof AdminScalarFieldEnum]


  export const CreditScalarFieldEnum: {
    credit_id: 'credit_id',
    customer_id: 'customer_id',
    due_date: 'due_date',
    credit_amount: 'credit_amount',
    status: 'status',
    total_credit_limit: 'total_credit_limit',
    available_credit_limit: 'available_credit_limit',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type CreditScalarFieldEnum = (typeof CreditScalarFieldEnum)[keyof typeof CreditScalarFieldEnum]


  export const CustomerScalarFieldEnum: {
    customer_id: 'customer_id',
    username: 'username',
    password: 'password',
    email: 'email',
    mobile_number: 'mobile_number',
    credit_limit: 'credit_limit',
    remaining_credit: 'remaining_credit',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type CustomerScalarFieldEnum = (typeof CustomerScalarFieldEnum)[keyof typeof CustomerScalarFieldEnum]


  export const Inventory_inflow_outflowScalarFieldEnum: {
    id: 'id',
    product_id: 'product_id',
    flow_direction: 'flow_direction',
    quantity: 'quantity',
    created_at: 'created_at'
  };

  export type Inventory_inflow_outflowScalarFieldEnum = (typeof Inventory_inflow_outflowScalarFieldEnum)[keyof typeof Inventory_inflow_outflowScalarFieldEnum]


  export const NotificationScalarFieldEnum: {
    notification_id: 'notification_id',
    customer_id: 'customer_id',
    message: 'message',
    sent_at: 'sent_at'
  };

  export type NotificationScalarFieldEnum = (typeof NotificationScalarFieldEnum)[keyof typeof NotificationScalarFieldEnum]


  export const OrderScalarFieldEnum: {
    order_id: 'order_id',
    quotation_id: 'quotation_id',
    customer_id: 'customer_id',
    status: 'status',
    total_price: 'total_price',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type OrderScalarFieldEnum = (typeof OrderScalarFieldEnum)[keyof typeof OrderScalarFieldEnum]


  export const Order_detailsScalarFieldEnum: {
    order_item_id: 'order_item_id',
    order_id: 'order_id',
    product_id: 'product_id',
    quantity: 'quantity',
    price: 'price'
  };

  export type Order_detailsScalarFieldEnum = (typeof Order_detailsScalarFieldEnum)[keyof typeof Order_detailsScalarFieldEnum]


  export const PaymentScalarFieldEnum: {
    payment_id: 'payment_id',
    order_id: 'order_id',
    amount: 'amount',
    payment_mode: 'payment_mode',
    payment_date: 'payment_date',
    status: 'status'
  };

  export type PaymentScalarFieldEnum = (typeof PaymentScalarFieldEnum)[keyof typeof PaymentScalarFieldEnum]


  export const ProductScalarFieldEnum: {
    product_id: 'product_id',
    name: 'name',
    min_stock_limit: 'min_stock_limit',
    description: 'description',
    specifications: 'specifications',
    image_url: 'image_url',
    price: 'price',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type ProductScalarFieldEnum = (typeof ProductScalarFieldEnum)[keyof typeof ProductScalarFieldEnum]


  export const QuotationScalarFieldEnum: {
    quotation_id: 'quotation_id',
    customer_id: 'customer_id',
    admin_id: 'admin_id',
    status: 'status',
    total_amount: 'total_amount',
    credit_period: 'credit_period',
    payment_mode: 'payment_mode',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type QuotationScalarFieldEnum = (typeof QuotationScalarFieldEnum)[keyof typeof QuotationScalarFieldEnum]


  export const Quotation_detailsScalarFieldEnum: {
    quotation_item_id: 'quotation_item_id',
    quotation_id: 'quotation_id',
    product_id: 'product_id',
    quantity: 'quantity',
    price: 'price'
  };

  export type Quotation_detailsScalarFieldEnum = (typeof Quotation_detailsScalarFieldEnum)[keyof typeof Quotation_detailsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'credit_status_enum'
   */
  export type Enumcredit_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'credit_status_enum'>
    


  /**
   * Reference to a field of type 'credit_status_enum[]'
   */
  export type ListEnumcredit_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'credit_status_enum[]'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Decimal[]'
   */
  export type ListDecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal[]'>
    


  /**
   * Reference to a field of type 'flow_direction_enum'
   */
  export type Enumflow_direction_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'flow_direction_enum'>
    


  /**
   * Reference to a field of type 'flow_direction_enum[]'
   */
  export type ListEnumflow_direction_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'flow_direction_enum[]'>
    


  /**
   * Reference to a field of type 'order_status_enum'
   */
  export type Enumorder_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'order_status_enum'>
    


  /**
   * Reference to a field of type 'order_status_enum[]'
   */
  export type ListEnumorder_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'order_status_enum[]'>
    


  /**
   * Reference to a field of type 'payment_mode_enum'
   */
  export type Enumpayment_mode_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'payment_mode_enum'>
    


  /**
   * Reference to a field of type 'payment_mode_enum[]'
   */
  export type ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'payment_mode_enum[]'>
    


  /**
   * Reference to a field of type 'payment_status_enum'
   */
  export type Enumpayment_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'payment_status_enum'>
    


  /**
   * Reference to a field of type 'payment_status_enum[]'
   */
  export type ListEnumpayment_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'payment_status_enum[]'>
    


  /**
   * Reference to a field of type 'quotation_status_enum'
   */
  export type Enumquotation_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'quotation_status_enum'>
    


  /**
   * Reference to a field of type 'quotation_status_enum[]'
   */
  export type ListEnumquotation_status_enumFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'quotation_status_enum[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type adminWhereInput = {
    AND?: adminWhereInput | adminWhereInput[]
    OR?: adminWhereInput[]
    NOT?: adminWhereInput | adminWhereInput[]
    admin_id?: IntFilter<"admin"> | number
    username?: StringFilter<"admin"> | string
    password?: StringFilter<"admin"> | string
    roles?: StringNullableListFilter<"admin">
    email?: StringNullableFilter<"admin"> | string | null
    created_at?: DateTimeNullableFilter<"admin"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"admin"> | Date | string | null
  }

  export type adminOrderByWithRelationInput = {
    admin_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    roles?: SortOrder
    email?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
  }

  export type adminWhereUniqueInput = Prisma.AtLeast<{
    admin_id?: number
    username?: string
    AND?: adminWhereInput | adminWhereInput[]
    OR?: adminWhereInput[]
    NOT?: adminWhereInput | adminWhereInput[]
    password?: StringFilter<"admin"> | string
    roles?: StringNullableListFilter<"admin">
    email?: StringNullableFilter<"admin"> | string | null
    created_at?: DateTimeNullableFilter<"admin"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"admin"> | Date | string | null
  }, "admin_id" | "username">

  export type adminOrderByWithAggregationInput = {
    admin_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    roles?: SortOrder
    email?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: adminCountOrderByAggregateInput
    _avg?: adminAvgOrderByAggregateInput
    _max?: adminMaxOrderByAggregateInput
    _min?: adminMinOrderByAggregateInput
    _sum?: adminSumOrderByAggregateInput
  }

  export type adminScalarWhereWithAggregatesInput = {
    AND?: adminScalarWhereWithAggregatesInput | adminScalarWhereWithAggregatesInput[]
    OR?: adminScalarWhereWithAggregatesInput[]
    NOT?: adminScalarWhereWithAggregatesInput | adminScalarWhereWithAggregatesInput[]
    admin_id?: IntWithAggregatesFilter<"admin"> | number
    username?: StringWithAggregatesFilter<"admin"> | string
    password?: StringWithAggregatesFilter<"admin"> | string
    roles?: StringNullableListFilter<"admin">
    email?: StringNullableWithAggregatesFilter<"admin"> | string | null
    created_at?: DateTimeNullableWithAggregatesFilter<"admin"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"admin"> | Date | string | null
  }

  export type creditWhereInput = {
    AND?: creditWhereInput | creditWhereInput[]
    OR?: creditWhereInput[]
    NOT?: creditWhereInput | creditWhereInput[]
    credit_id?: IntFilter<"credit"> | number
    customer_id?: IntNullableFilter<"credit"> | number | null
    due_date?: DateTimeNullableFilter<"credit"> | Date | string | null
    credit_amount?: IntNullableFilter<"credit"> | number | null
    status?: Enumcredit_status_enumNullableFilter<"credit"> | $Enums.credit_status_enum | null
    total_credit_limit?: IntNullableFilter<"credit"> | number | null
    available_credit_limit?: IntNullableFilter<"credit"> | number | null
    created_at?: DateTimeNullableFilter<"credit"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"credit"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
  }

  export type creditOrderByWithRelationInput = {
    credit_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    due_date?: SortOrderInput | SortOrder
    credit_amount?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_credit_limit?: SortOrderInput | SortOrder
    available_credit_limit?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    customer?: customerOrderByWithRelationInput
  }

  export type creditWhereUniqueInput = Prisma.AtLeast<{
    credit_id?: number
    customer_id?: number
    AND?: creditWhereInput | creditWhereInput[]
    OR?: creditWhereInput[]
    NOT?: creditWhereInput | creditWhereInput[]
    due_date?: DateTimeNullableFilter<"credit"> | Date | string | null
    credit_amount?: IntNullableFilter<"credit"> | number | null
    status?: Enumcredit_status_enumNullableFilter<"credit"> | $Enums.credit_status_enum | null
    total_credit_limit?: IntNullableFilter<"credit"> | number | null
    available_credit_limit?: IntNullableFilter<"credit"> | number | null
    created_at?: DateTimeNullableFilter<"credit"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"credit"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
  }, "credit_id" | "customer_id">

  export type creditOrderByWithAggregationInput = {
    credit_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    due_date?: SortOrderInput | SortOrder
    credit_amount?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_credit_limit?: SortOrderInput | SortOrder
    available_credit_limit?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: creditCountOrderByAggregateInput
    _avg?: creditAvgOrderByAggregateInput
    _max?: creditMaxOrderByAggregateInput
    _min?: creditMinOrderByAggregateInput
    _sum?: creditSumOrderByAggregateInput
  }

  export type creditScalarWhereWithAggregatesInput = {
    AND?: creditScalarWhereWithAggregatesInput | creditScalarWhereWithAggregatesInput[]
    OR?: creditScalarWhereWithAggregatesInput[]
    NOT?: creditScalarWhereWithAggregatesInput | creditScalarWhereWithAggregatesInput[]
    credit_id?: IntWithAggregatesFilter<"credit"> | number
    customer_id?: IntNullableWithAggregatesFilter<"credit"> | number | null
    due_date?: DateTimeNullableWithAggregatesFilter<"credit"> | Date | string | null
    credit_amount?: IntNullableWithAggregatesFilter<"credit"> | number | null
    status?: Enumcredit_status_enumNullableWithAggregatesFilter<"credit"> | $Enums.credit_status_enum | null
    total_credit_limit?: IntNullableWithAggregatesFilter<"credit"> | number | null
    available_credit_limit?: IntNullableWithAggregatesFilter<"credit"> | number | null
    created_at?: DateTimeNullableWithAggregatesFilter<"credit"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"credit"> | Date | string | null
  }

  export type customerWhereInput = {
    AND?: customerWhereInput | customerWhereInput[]
    OR?: customerWhereInput[]
    NOT?: customerWhereInput | customerWhereInput[]
    customer_id?: IntFilter<"customer"> | number
    username?: StringFilter<"customer"> | string
    password?: StringFilter<"customer"> | string
    email?: StringFilter<"customer"> | string
    mobile_number?: StringFilter<"customer"> | string
    credit_limit?: DecimalNullableFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: DecimalNullableFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableFilter<"customer"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"customer"> | Date | string | null
    credit?: XOR<CreditNullableScalarRelationFilter, creditWhereInput> | null
    notification?: NotificationListRelationFilter
    order?: OrderListRelationFilter
    quotation?: QuotationListRelationFilter
  }

  export type customerOrderByWithRelationInput = {
    customer_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    mobile_number?: SortOrder
    credit_limit?: SortOrderInput | SortOrder
    remaining_credit?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    credit?: creditOrderByWithRelationInput
    notification?: notificationOrderByRelationAggregateInput
    order?: orderOrderByRelationAggregateInput
    quotation?: quotationOrderByRelationAggregateInput
  }

  export type customerWhereUniqueInput = Prisma.AtLeast<{
    customer_id?: number
    username?: string
    email?: string
    mobile_number?: string
    AND?: customerWhereInput | customerWhereInput[]
    OR?: customerWhereInput[]
    NOT?: customerWhereInput | customerWhereInput[]
    password?: StringFilter<"customer"> | string
    credit_limit?: DecimalNullableFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: DecimalNullableFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableFilter<"customer"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"customer"> | Date | string | null
    credit?: XOR<CreditNullableScalarRelationFilter, creditWhereInput> | null
    notification?: NotificationListRelationFilter
    order?: OrderListRelationFilter
    quotation?: QuotationListRelationFilter
  }, "customer_id" | "username" | "email" | "mobile_number">

  export type customerOrderByWithAggregationInput = {
    customer_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    mobile_number?: SortOrder
    credit_limit?: SortOrderInput | SortOrder
    remaining_credit?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: customerCountOrderByAggregateInput
    _avg?: customerAvgOrderByAggregateInput
    _max?: customerMaxOrderByAggregateInput
    _min?: customerMinOrderByAggregateInput
    _sum?: customerSumOrderByAggregateInput
  }

  export type customerScalarWhereWithAggregatesInput = {
    AND?: customerScalarWhereWithAggregatesInput | customerScalarWhereWithAggregatesInput[]
    OR?: customerScalarWhereWithAggregatesInput[]
    NOT?: customerScalarWhereWithAggregatesInput | customerScalarWhereWithAggregatesInput[]
    customer_id?: IntWithAggregatesFilter<"customer"> | number
    username?: StringWithAggregatesFilter<"customer"> | string
    password?: StringWithAggregatesFilter<"customer"> | string
    email?: StringWithAggregatesFilter<"customer"> | string
    mobile_number?: StringWithAggregatesFilter<"customer"> | string
    credit_limit?: DecimalNullableWithAggregatesFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: DecimalNullableWithAggregatesFilter<"customer"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableWithAggregatesFilter<"customer"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"customer"> | Date | string | null
  }

  export type inventory_inflow_outflowWhereInput = {
    AND?: inventory_inflow_outflowWhereInput | inventory_inflow_outflowWhereInput[]
    OR?: inventory_inflow_outflowWhereInput[]
    NOT?: inventory_inflow_outflowWhereInput | inventory_inflow_outflowWhereInput[]
    id?: IntFilter<"inventory_inflow_outflow"> | number
    product_id?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    flow_direction?: Enumflow_direction_enumNullableFilter<"inventory_inflow_outflow"> | $Enums.flow_direction_enum | null
    quantity?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    created_at?: DateTimeNullableFilter<"inventory_inflow_outflow"> | Date | string | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
  }

  export type inventory_inflow_outflowOrderByWithRelationInput = {
    id?: SortOrder
    product_id?: SortOrderInput | SortOrder
    flow_direction?: SortOrderInput | SortOrder
    quantity?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    product?: productOrderByWithRelationInput
  }

  export type inventory_inflow_outflowWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: inventory_inflow_outflowWhereInput | inventory_inflow_outflowWhereInput[]
    OR?: inventory_inflow_outflowWhereInput[]
    NOT?: inventory_inflow_outflowWhereInput | inventory_inflow_outflowWhereInput[]
    product_id?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    flow_direction?: Enumflow_direction_enumNullableFilter<"inventory_inflow_outflow"> | $Enums.flow_direction_enum | null
    quantity?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    created_at?: DateTimeNullableFilter<"inventory_inflow_outflow"> | Date | string | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
  }, "id">

  export type inventory_inflow_outflowOrderByWithAggregationInput = {
    id?: SortOrder
    product_id?: SortOrderInput | SortOrder
    flow_direction?: SortOrderInput | SortOrder
    quantity?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    _count?: inventory_inflow_outflowCountOrderByAggregateInput
    _avg?: inventory_inflow_outflowAvgOrderByAggregateInput
    _max?: inventory_inflow_outflowMaxOrderByAggregateInput
    _min?: inventory_inflow_outflowMinOrderByAggregateInput
    _sum?: inventory_inflow_outflowSumOrderByAggregateInput
  }

  export type inventory_inflow_outflowScalarWhereWithAggregatesInput = {
    AND?: inventory_inflow_outflowScalarWhereWithAggregatesInput | inventory_inflow_outflowScalarWhereWithAggregatesInput[]
    OR?: inventory_inflow_outflowScalarWhereWithAggregatesInput[]
    NOT?: inventory_inflow_outflowScalarWhereWithAggregatesInput | inventory_inflow_outflowScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"inventory_inflow_outflow"> | number
    product_id?: IntNullableWithAggregatesFilter<"inventory_inflow_outflow"> | number | null
    flow_direction?: Enumflow_direction_enumNullableWithAggregatesFilter<"inventory_inflow_outflow"> | $Enums.flow_direction_enum | null
    quantity?: IntNullableWithAggregatesFilter<"inventory_inflow_outflow"> | number | null
    created_at?: DateTimeNullableWithAggregatesFilter<"inventory_inflow_outflow"> | Date | string | null
  }

  export type notificationWhereInput = {
    AND?: notificationWhereInput | notificationWhereInput[]
    OR?: notificationWhereInput[]
    NOT?: notificationWhereInput | notificationWhereInput[]
    notification_id?: IntFilter<"notification"> | number
    customer_id?: IntNullableFilter<"notification"> | number | null
    message?: StringFilter<"notification"> | string
    sent_at?: DateTimeNullableFilter<"notification"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
  }

  export type notificationOrderByWithRelationInput = {
    notification_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    message?: SortOrder
    sent_at?: SortOrderInput | SortOrder
    customer?: customerOrderByWithRelationInput
  }

  export type notificationWhereUniqueInput = Prisma.AtLeast<{
    notification_id?: number
    AND?: notificationWhereInput | notificationWhereInput[]
    OR?: notificationWhereInput[]
    NOT?: notificationWhereInput | notificationWhereInput[]
    customer_id?: IntNullableFilter<"notification"> | number | null
    message?: StringFilter<"notification"> | string
    sent_at?: DateTimeNullableFilter<"notification"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
  }, "notification_id">

  export type notificationOrderByWithAggregationInput = {
    notification_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    message?: SortOrder
    sent_at?: SortOrderInput | SortOrder
    _count?: notificationCountOrderByAggregateInput
    _avg?: notificationAvgOrderByAggregateInput
    _max?: notificationMaxOrderByAggregateInput
    _min?: notificationMinOrderByAggregateInput
    _sum?: notificationSumOrderByAggregateInput
  }

  export type notificationScalarWhereWithAggregatesInput = {
    AND?: notificationScalarWhereWithAggregatesInput | notificationScalarWhereWithAggregatesInput[]
    OR?: notificationScalarWhereWithAggregatesInput[]
    NOT?: notificationScalarWhereWithAggregatesInput | notificationScalarWhereWithAggregatesInput[]
    notification_id?: IntWithAggregatesFilter<"notification"> | number
    customer_id?: IntNullableWithAggregatesFilter<"notification"> | number | null
    message?: StringWithAggregatesFilter<"notification"> | string
    sent_at?: DateTimeNullableWithAggregatesFilter<"notification"> | Date | string | null
  }

  export type orderWhereInput = {
    AND?: orderWhereInput | orderWhereInput[]
    OR?: orderWhereInput[]
    NOT?: orderWhereInput | orderWhereInput[]
    order_id?: IntFilter<"order"> | number
    quotation_id?: IntNullableFilter<"order"> | number | null
    customer_id?: IntNullableFilter<"order"> | number | null
    status?: Enumorder_status_enumNullableFilter<"order"> | $Enums.order_status_enum | null
    total_price?: DecimalNullableFilter<"order"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableFilter<"order"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"order"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
    quotation?: XOR<QuotationNullableScalarRelationFilter, quotationWhereInput> | null
    order_details?: Order_detailsListRelationFilter
    payment?: PaymentListRelationFilter
  }

  export type orderOrderByWithRelationInput = {
    order_id?: SortOrder
    quotation_id?: SortOrderInput | SortOrder
    customer_id?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_price?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    customer?: customerOrderByWithRelationInput
    quotation?: quotationOrderByWithRelationInput
    order_details?: order_detailsOrderByRelationAggregateInput
    payment?: paymentOrderByRelationAggregateInput
  }

  export type orderWhereUniqueInput = Prisma.AtLeast<{
    order_id?: number
    AND?: orderWhereInput | orderWhereInput[]
    OR?: orderWhereInput[]
    NOT?: orderWhereInput | orderWhereInput[]
    quotation_id?: IntNullableFilter<"order"> | number | null
    customer_id?: IntNullableFilter<"order"> | number | null
    status?: Enumorder_status_enumNullableFilter<"order"> | $Enums.order_status_enum | null
    total_price?: DecimalNullableFilter<"order"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableFilter<"order"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"order"> | Date | string | null
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
    quotation?: XOR<QuotationNullableScalarRelationFilter, quotationWhereInput> | null
    order_details?: Order_detailsListRelationFilter
    payment?: PaymentListRelationFilter
  }, "order_id">

  export type orderOrderByWithAggregationInput = {
    order_id?: SortOrder
    quotation_id?: SortOrderInput | SortOrder
    customer_id?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_price?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: orderCountOrderByAggregateInput
    _avg?: orderAvgOrderByAggregateInput
    _max?: orderMaxOrderByAggregateInput
    _min?: orderMinOrderByAggregateInput
    _sum?: orderSumOrderByAggregateInput
  }

  export type orderScalarWhereWithAggregatesInput = {
    AND?: orderScalarWhereWithAggregatesInput | orderScalarWhereWithAggregatesInput[]
    OR?: orderScalarWhereWithAggregatesInput[]
    NOT?: orderScalarWhereWithAggregatesInput | orderScalarWhereWithAggregatesInput[]
    order_id?: IntWithAggregatesFilter<"order"> | number
    quotation_id?: IntNullableWithAggregatesFilter<"order"> | number | null
    customer_id?: IntNullableWithAggregatesFilter<"order"> | number | null
    status?: Enumorder_status_enumNullableWithAggregatesFilter<"order"> | $Enums.order_status_enum | null
    total_price?: DecimalNullableWithAggregatesFilter<"order"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableWithAggregatesFilter<"order"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"order"> | Date | string | null
  }

  export type order_detailsWhereInput = {
    AND?: order_detailsWhereInput | order_detailsWhereInput[]
    OR?: order_detailsWhereInput[]
    NOT?: order_detailsWhereInput | order_detailsWhereInput[]
    order_item_id?: IntFilter<"order_details"> | number
    order_id?: IntNullableFilter<"order_details"> | number | null
    product_id?: IntNullableFilter<"order_details"> | number | null
    quantity?: IntFilter<"order_details"> | number
    price?: DecimalFilter<"order_details"> | Decimal | DecimalJsLike | number | string
    order?: XOR<OrderNullableScalarRelationFilter, orderWhereInput> | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
  }

  export type order_detailsOrderByWithRelationInput = {
    order_item_id?: SortOrder
    order_id?: SortOrderInput | SortOrder
    product_id?: SortOrderInput | SortOrder
    quantity?: SortOrder
    price?: SortOrder
    order?: orderOrderByWithRelationInput
    product?: productOrderByWithRelationInput
  }

  export type order_detailsWhereUniqueInput = Prisma.AtLeast<{
    order_item_id?: number
    AND?: order_detailsWhereInput | order_detailsWhereInput[]
    OR?: order_detailsWhereInput[]
    NOT?: order_detailsWhereInput | order_detailsWhereInput[]
    order_id?: IntNullableFilter<"order_details"> | number | null
    product_id?: IntNullableFilter<"order_details"> | number | null
    quantity?: IntFilter<"order_details"> | number
    price?: DecimalFilter<"order_details"> | Decimal | DecimalJsLike | number | string
    order?: XOR<OrderNullableScalarRelationFilter, orderWhereInput> | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
  }, "order_item_id">

  export type order_detailsOrderByWithAggregationInput = {
    order_item_id?: SortOrder
    order_id?: SortOrderInput | SortOrder
    product_id?: SortOrderInput | SortOrder
    quantity?: SortOrder
    price?: SortOrder
    _count?: order_detailsCountOrderByAggregateInput
    _avg?: order_detailsAvgOrderByAggregateInput
    _max?: order_detailsMaxOrderByAggregateInput
    _min?: order_detailsMinOrderByAggregateInput
    _sum?: order_detailsSumOrderByAggregateInput
  }

  export type order_detailsScalarWhereWithAggregatesInput = {
    AND?: order_detailsScalarWhereWithAggregatesInput | order_detailsScalarWhereWithAggregatesInput[]
    OR?: order_detailsScalarWhereWithAggregatesInput[]
    NOT?: order_detailsScalarWhereWithAggregatesInput | order_detailsScalarWhereWithAggregatesInput[]
    order_item_id?: IntWithAggregatesFilter<"order_details"> | number
    order_id?: IntNullableWithAggregatesFilter<"order_details"> | number | null
    product_id?: IntNullableWithAggregatesFilter<"order_details"> | number | null
    quantity?: IntWithAggregatesFilter<"order_details"> | number
    price?: DecimalWithAggregatesFilter<"order_details"> | Decimal | DecimalJsLike | number | string
  }

  export type paymentWhereInput = {
    AND?: paymentWhereInput | paymentWhereInput[]
    OR?: paymentWhereInput[]
    NOT?: paymentWhereInput | paymentWhereInput[]
    payment_id?: IntFilter<"payment"> | number
    order_id?: IntNullableFilter<"payment"> | number | null
    amount?: DecimalFilter<"payment"> | Decimal | DecimalJsLike | number | string
    payment_mode?: Enumpayment_mode_enumNullableFilter<"payment"> | $Enums.payment_mode_enum | null
    payment_date?: DateTimeNullableFilter<"payment"> | Date | string | null
    status?: Enumpayment_status_enumNullableFilter<"payment"> | $Enums.payment_status_enum | null
    order?: XOR<OrderNullableScalarRelationFilter, orderWhereInput> | null
  }

  export type paymentOrderByWithRelationInput = {
    payment_id?: SortOrder
    order_id?: SortOrderInput | SortOrder
    amount?: SortOrder
    payment_mode?: SortOrderInput | SortOrder
    payment_date?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    order?: orderOrderByWithRelationInput
  }

  export type paymentWhereUniqueInput = Prisma.AtLeast<{
    payment_id?: number
    AND?: paymentWhereInput | paymentWhereInput[]
    OR?: paymentWhereInput[]
    NOT?: paymentWhereInput | paymentWhereInput[]
    order_id?: IntNullableFilter<"payment"> | number | null
    amount?: DecimalFilter<"payment"> | Decimal | DecimalJsLike | number | string
    payment_mode?: Enumpayment_mode_enumNullableFilter<"payment"> | $Enums.payment_mode_enum | null
    payment_date?: DateTimeNullableFilter<"payment"> | Date | string | null
    status?: Enumpayment_status_enumNullableFilter<"payment"> | $Enums.payment_status_enum | null
    order?: XOR<OrderNullableScalarRelationFilter, orderWhereInput> | null
  }, "payment_id">

  export type paymentOrderByWithAggregationInput = {
    payment_id?: SortOrder
    order_id?: SortOrderInput | SortOrder
    amount?: SortOrder
    payment_mode?: SortOrderInput | SortOrder
    payment_date?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    _count?: paymentCountOrderByAggregateInput
    _avg?: paymentAvgOrderByAggregateInput
    _max?: paymentMaxOrderByAggregateInput
    _min?: paymentMinOrderByAggregateInput
    _sum?: paymentSumOrderByAggregateInput
  }

  export type paymentScalarWhereWithAggregatesInput = {
    AND?: paymentScalarWhereWithAggregatesInput | paymentScalarWhereWithAggregatesInput[]
    OR?: paymentScalarWhereWithAggregatesInput[]
    NOT?: paymentScalarWhereWithAggregatesInput | paymentScalarWhereWithAggregatesInput[]
    payment_id?: IntWithAggregatesFilter<"payment"> | number
    order_id?: IntNullableWithAggregatesFilter<"payment"> | number | null
    amount?: DecimalWithAggregatesFilter<"payment"> | Decimal | DecimalJsLike | number | string
    payment_mode?: Enumpayment_mode_enumNullableWithAggregatesFilter<"payment"> | $Enums.payment_mode_enum | null
    payment_date?: DateTimeNullableWithAggregatesFilter<"payment"> | Date | string | null
    status?: Enumpayment_status_enumNullableWithAggregatesFilter<"payment"> | $Enums.payment_status_enum | null
  }

  export type productWhereInput = {
    AND?: productWhereInput | productWhereInput[]
    OR?: productWhereInput[]
    NOT?: productWhereInput | productWhereInput[]
    product_id?: IntFilter<"product"> | number
    name?: StringFilter<"product"> | string
    min_stock_limit?: IntNullableFilter<"product"> | number | null
    description?: StringNullableFilter<"product"> | string | null
    specifications?: StringNullableFilter<"product"> | string | null
    image_url?: StringNullableListFilter<"product">
    price?: DecimalFilter<"product"> | Decimal | DecimalJsLike | number | string
    created_at?: DateTimeNullableFilter<"product"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"product"> | Date | string | null
    inventory_inflow_outflow?: Inventory_inflow_outflowListRelationFilter
    order_details?: Order_detailsListRelationFilter
    quotation_details?: Quotation_detailsListRelationFilter
  }

  export type productOrderByWithRelationInput = {
    product_id?: SortOrder
    name?: SortOrder
    min_stock_limit?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    specifications?: SortOrderInput | SortOrder
    image_url?: SortOrder
    price?: SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    inventory_inflow_outflow?: inventory_inflow_outflowOrderByRelationAggregateInput
    order_details?: order_detailsOrderByRelationAggregateInput
    quotation_details?: quotation_detailsOrderByRelationAggregateInput
  }

  export type productWhereUniqueInput = Prisma.AtLeast<{
    product_id?: number
    AND?: productWhereInput | productWhereInput[]
    OR?: productWhereInput[]
    NOT?: productWhereInput | productWhereInput[]
    name?: StringFilter<"product"> | string
    min_stock_limit?: IntNullableFilter<"product"> | number | null
    description?: StringNullableFilter<"product"> | string | null
    specifications?: StringNullableFilter<"product"> | string | null
    image_url?: StringNullableListFilter<"product">
    price?: DecimalFilter<"product"> | Decimal | DecimalJsLike | number | string
    created_at?: DateTimeNullableFilter<"product"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"product"> | Date | string | null
    inventory_inflow_outflow?: Inventory_inflow_outflowListRelationFilter
    order_details?: Order_detailsListRelationFilter
    quotation_details?: Quotation_detailsListRelationFilter
  }, "product_id">

  export type productOrderByWithAggregationInput = {
    product_id?: SortOrder
    name?: SortOrder
    min_stock_limit?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    specifications?: SortOrderInput | SortOrder
    image_url?: SortOrder
    price?: SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: productCountOrderByAggregateInput
    _avg?: productAvgOrderByAggregateInput
    _max?: productMaxOrderByAggregateInput
    _min?: productMinOrderByAggregateInput
    _sum?: productSumOrderByAggregateInput
  }

  export type productScalarWhereWithAggregatesInput = {
    AND?: productScalarWhereWithAggregatesInput | productScalarWhereWithAggregatesInput[]
    OR?: productScalarWhereWithAggregatesInput[]
    NOT?: productScalarWhereWithAggregatesInput | productScalarWhereWithAggregatesInput[]
    product_id?: IntWithAggregatesFilter<"product"> | number
    name?: StringWithAggregatesFilter<"product"> | string
    min_stock_limit?: IntNullableWithAggregatesFilter<"product"> | number | null
    description?: StringNullableWithAggregatesFilter<"product"> | string | null
    specifications?: StringNullableWithAggregatesFilter<"product"> | string | null
    image_url?: StringNullableListFilter<"product">
    price?: DecimalWithAggregatesFilter<"product"> | Decimal | DecimalJsLike | number | string
    created_at?: DateTimeNullableWithAggregatesFilter<"product"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"product"> | Date | string | null
  }

  export type quotationWhereInput = {
    AND?: quotationWhereInput | quotationWhereInput[]
    OR?: quotationWhereInput[]
    NOT?: quotationWhereInput | quotationWhereInput[]
    quotation_id?: IntFilter<"quotation"> | number
    customer_id?: IntNullableFilter<"quotation"> | number | null
    admin_id?: IntNullableFilter<"quotation"> | number | null
    status?: Enumquotation_status_enumNullableFilter<"quotation"> | $Enums.quotation_status_enum | null
    total_amount?: DecimalNullableFilter<"quotation"> | Decimal | DecimalJsLike | number | string | null
    credit_period?: IntNullableFilter<"quotation"> | number | null
    payment_mode?: Enumpayment_mode_enumNullableFilter<"quotation"> | $Enums.payment_mode_enum | null
    created_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
    order?: OrderListRelationFilter
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
    quotation_details?: Quotation_detailsListRelationFilter
  }

  export type quotationOrderByWithRelationInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    admin_id?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_amount?: SortOrderInput | SortOrder
    credit_period?: SortOrderInput | SortOrder
    payment_mode?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    order?: orderOrderByRelationAggregateInput
    customer?: customerOrderByWithRelationInput
    quotation_details?: quotation_detailsOrderByRelationAggregateInput
  }

  export type quotationWhereUniqueInput = Prisma.AtLeast<{
    quotation_id?: number
    AND?: quotationWhereInput | quotationWhereInput[]
    OR?: quotationWhereInput[]
    NOT?: quotationWhereInput | quotationWhereInput[]
    customer_id?: IntNullableFilter<"quotation"> | number | null
    admin_id?: IntNullableFilter<"quotation"> | number | null
    status?: Enumquotation_status_enumNullableFilter<"quotation"> | $Enums.quotation_status_enum | null
    total_amount?: DecimalNullableFilter<"quotation"> | Decimal | DecimalJsLike | number | string | null
    credit_period?: IntNullableFilter<"quotation"> | number | null
    payment_mode?: Enumpayment_mode_enumNullableFilter<"quotation"> | $Enums.payment_mode_enum | null
    created_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
    order?: OrderListRelationFilter
    customer?: XOR<CustomerNullableScalarRelationFilter, customerWhereInput> | null
    quotation_details?: Quotation_detailsListRelationFilter
  }, "quotation_id">

  export type quotationOrderByWithAggregationInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrderInput | SortOrder
    admin_id?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    total_amount?: SortOrderInput | SortOrder
    credit_period?: SortOrderInput | SortOrder
    payment_mode?: SortOrderInput | SortOrder
    created_at?: SortOrderInput | SortOrder
    updated_at?: SortOrderInput | SortOrder
    _count?: quotationCountOrderByAggregateInput
    _avg?: quotationAvgOrderByAggregateInput
    _max?: quotationMaxOrderByAggregateInput
    _min?: quotationMinOrderByAggregateInput
    _sum?: quotationSumOrderByAggregateInput
  }

  export type quotationScalarWhereWithAggregatesInput = {
    AND?: quotationScalarWhereWithAggregatesInput | quotationScalarWhereWithAggregatesInput[]
    OR?: quotationScalarWhereWithAggregatesInput[]
    NOT?: quotationScalarWhereWithAggregatesInput | quotationScalarWhereWithAggregatesInput[]
    quotation_id?: IntWithAggregatesFilter<"quotation"> | number
    customer_id?: IntNullableWithAggregatesFilter<"quotation"> | number | null
    admin_id?: IntNullableWithAggregatesFilter<"quotation"> | number | null
    status?: Enumquotation_status_enumNullableWithAggregatesFilter<"quotation"> | $Enums.quotation_status_enum | null
    total_amount?: DecimalNullableWithAggregatesFilter<"quotation"> | Decimal | DecimalJsLike | number | string | null
    credit_period?: IntNullableWithAggregatesFilter<"quotation"> | number | null
    payment_mode?: Enumpayment_mode_enumNullableWithAggregatesFilter<"quotation"> | $Enums.payment_mode_enum | null
    created_at?: DateTimeNullableWithAggregatesFilter<"quotation"> | Date | string | null
    updated_at?: DateTimeNullableWithAggregatesFilter<"quotation"> | Date | string | null
  }

  export type quotation_detailsWhereInput = {
    AND?: quotation_detailsWhereInput | quotation_detailsWhereInput[]
    OR?: quotation_detailsWhereInput[]
    NOT?: quotation_detailsWhereInput | quotation_detailsWhereInput[]
    quotation_item_id?: IntFilter<"quotation_details"> | number
    quotation_id?: IntNullableFilter<"quotation_details"> | number | null
    product_id?: IntNullableFilter<"quotation_details"> | number | null
    quantity?: IntFilter<"quotation_details"> | number
    price?: DecimalNullableFilter<"quotation_details"> | Decimal | DecimalJsLike | number | string | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
    quotation?: XOR<QuotationNullableScalarRelationFilter, quotationWhereInput> | null
  }

  export type quotation_detailsOrderByWithRelationInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrderInput | SortOrder
    product_id?: SortOrderInput | SortOrder
    quantity?: SortOrder
    price?: SortOrderInput | SortOrder
    product?: productOrderByWithRelationInput
    quotation?: quotationOrderByWithRelationInput
  }

  export type quotation_detailsWhereUniqueInput = Prisma.AtLeast<{
    quotation_item_id?: number
    AND?: quotation_detailsWhereInput | quotation_detailsWhereInput[]
    OR?: quotation_detailsWhereInput[]
    NOT?: quotation_detailsWhereInput | quotation_detailsWhereInput[]
    quotation_id?: IntNullableFilter<"quotation_details"> | number | null
    product_id?: IntNullableFilter<"quotation_details"> | number | null
    quantity?: IntFilter<"quotation_details"> | number
    price?: DecimalNullableFilter<"quotation_details"> | Decimal | DecimalJsLike | number | string | null
    product?: XOR<ProductNullableScalarRelationFilter, productWhereInput> | null
    quotation?: XOR<QuotationNullableScalarRelationFilter, quotationWhereInput> | null
  }, "quotation_item_id">

  export type quotation_detailsOrderByWithAggregationInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrderInput | SortOrder
    product_id?: SortOrderInput | SortOrder
    quantity?: SortOrder
    price?: SortOrderInput | SortOrder
    _count?: quotation_detailsCountOrderByAggregateInput
    _avg?: quotation_detailsAvgOrderByAggregateInput
    _max?: quotation_detailsMaxOrderByAggregateInput
    _min?: quotation_detailsMinOrderByAggregateInput
    _sum?: quotation_detailsSumOrderByAggregateInput
  }

  export type quotation_detailsScalarWhereWithAggregatesInput = {
    AND?: quotation_detailsScalarWhereWithAggregatesInput | quotation_detailsScalarWhereWithAggregatesInput[]
    OR?: quotation_detailsScalarWhereWithAggregatesInput[]
    NOT?: quotation_detailsScalarWhereWithAggregatesInput | quotation_detailsScalarWhereWithAggregatesInput[]
    quotation_item_id?: IntWithAggregatesFilter<"quotation_details"> | number
    quotation_id?: IntNullableWithAggregatesFilter<"quotation_details"> | number | null
    product_id?: IntNullableWithAggregatesFilter<"quotation_details"> | number | null
    quantity?: IntWithAggregatesFilter<"quotation_details"> | number
    price?: DecimalNullableWithAggregatesFilter<"quotation_details"> | Decimal | DecimalJsLike | number | string | null
  }

  export type adminCreateInput = {
    username: string
    password: string
    roles?: adminCreaterolesInput | string[]
    email?: string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type adminUncheckedCreateInput = {
    admin_id?: number
    username: string
    password: string
    roles?: adminCreaterolesInput | string[]
    email?: string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type adminUpdateInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    roles?: adminUpdaterolesInput | string[]
    email?: NullableStringFieldUpdateOperationsInput | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type adminUncheckedUpdateInput = {
    admin_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    roles?: adminUpdaterolesInput | string[]
    email?: NullableStringFieldUpdateOperationsInput | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type adminCreateManyInput = {
    admin_id?: number
    username: string
    password: string
    roles?: adminCreaterolesInput | string[]
    email?: string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type adminUpdateManyMutationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    roles?: adminUpdaterolesInput | string[]
    email?: NullableStringFieldUpdateOperationsInput | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type adminUncheckedUpdateManyInput = {
    admin_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    roles?: adminUpdaterolesInput | string[]
    email?: NullableStringFieldUpdateOperationsInput | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type creditCreateInput = {
    due_date?: Date | string | null
    credit_amount?: number | null
    status?: $Enums.credit_status_enum | null
    total_credit_limit?: number | null
    available_credit_limit?: number | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutCreditInput
  }

  export type creditUncheckedCreateInput = {
    credit_id?: number
    customer_id?: number | null
    due_date?: Date | string | null
    credit_amount?: number | null
    status?: $Enums.credit_status_enum | null
    total_credit_limit?: number | null
    available_credit_limit?: number | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type creditUpdateInput = {
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutCreditNestedInput
  }

  export type creditUncheckedUpdateInput = {
    credit_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type creditCreateManyInput = {
    credit_id?: number
    customer_id?: number | null
    due_date?: Date | string | null
    credit_amount?: number | null
    status?: $Enums.credit_status_enum | null
    total_credit_limit?: number | null
    available_credit_limit?: number | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type creditUpdateManyMutationInput = {
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type creditUncheckedUpdateManyInput = {
    credit_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type customerCreateInput = {
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditCreateNestedOneWithoutCustomerInput
    notification?: notificationCreateNestedManyWithoutCustomerInput
    order?: orderCreateNestedManyWithoutCustomerInput
    quotation?: quotationCreateNestedManyWithoutCustomerInput
  }

  export type customerUncheckedCreateInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditUncheckedCreateNestedOneWithoutCustomerInput
    notification?: notificationUncheckedCreateNestedManyWithoutCustomerInput
    order?: orderUncheckedCreateNestedManyWithoutCustomerInput
    quotation?: quotationUncheckedCreateNestedManyWithoutCustomerInput
  }

  export type customerUpdateInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUpdateOneWithoutCustomerNestedInput
    notification?: notificationUpdateManyWithoutCustomerNestedInput
    order?: orderUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUpdateManyWithoutCustomerNestedInput
  }

  export type customerUncheckedUpdateInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUncheckedUpdateOneWithoutCustomerNestedInput
    notification?: notificationUncheckedUpdateManyWithoutCustomerNestedInput
    order?: orderUncheckedUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUncheckedUpdateManyWithoutCustomerNestedInput
  }

  export type customerCreateManyInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type customerUpdateManyMutationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type customerUncheckedUpdateManyInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inventory_inflow_outflowCreateInput = {
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
    product?: productCreateNestedOneWithoutInventory_inflow_outflowInput
  }

  export type inventory_inflow_outflowUncheckedCreateInput = {
    id?: number
    product_id?: number | null
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
  }

  export type inventory_inflow_outflowUpdateInput = {
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    product?: productUpdateOneWithoutInventory_inflow_outflowNestedInput
  }

  export type inventory_inflow_outflowUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inventory_inflow_outflowCreateManyInput = {
    id?: number
    product_id?: number | null
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
  }

  export type inventory_inflow_outflowUpdateManyMutationInput = {
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inventory_inflow_outflowUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationCreateInput = {
    message: string
    sent_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutNotificationInput
  }

  export type notificationUncheckedCreateInput = {
    notification_id?: number
    customer_id?: number | null
    message: string
    sent_at?: Date | string | null
  }

  export type notificationUpdateInput = {
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutNotificationNestedInput
  }

  export type notificationUncheckedUpdateInput = {
    notification_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationCreateManyInput = {
    notification_id?: number
    customer_id?: number | null
    message: string
    sent_at?: Date | string | null
  }

  export type notificationUpdateManyMutationInput = {
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationUncheckedUpdateManyInput = {
    notification_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type orderCreateInput = {
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutOrderInput
    quotation?: quotationCreateNestedOneWithoutOrderInput
    order_details?: order_detailsCreateNestedManyWithoutOrderInput
    payment?: paymentCreateNestedManyWithoutOrderInput
  }

  export type orderUncheckedCreateInput = {
    order_id?: number
    quotation_id?: number | null
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsUncheckedCreateNestedManyWithoutOrderInput
    payment?: paymentUncheckedCreateNestedManyWithoutOrderInput
  }

  export type orderUpdateInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutOrderNestedInput
    quotation?: quotationUpdateOneWithoutOrderNestedInput
    order_details?: order_detailsUpdateManyWithoutOrderNestedInput
    payment?: paymentUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUncheckedUpdateManyWithoutOrderNestedInput
    payment?: paymentUncheckedUpdateManyWithoutOrderNestedInput
  }

  export type orderCreateManyInput = {
    order_id?: number
    quotation_id?: number | null
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type orderUpdateManyMutationInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type orderUncheckedUpdateManyInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type order_detailsCreateInput = {
    quantity: number
    price: Decimal | DecimalJsLike | number | string
    order?: orderCreateNestedOneWithoutOrder_detailsInput
    product?: productCreateNestedOneWithoutOrder_detailsInput
  }

  export type order_detailsUncheckedCreateInput = {
    order_item_id?: number
    order_id?: number | null
    product_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type order_detailsUpdateInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    order?: orderUpdateOneWithoutOrder_detailsNestedInput
    product?: productUpdateOneWithoutOrder_detailsNestedInput
  }

  export type order_detailsUncheckedUpdateInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type order_detailsCreateManyInput = {
    order_item_id?: number
    order_id?: number | null
    product_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type order_detailsUpdateManyMutationInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type order_detailsUncheckedUpdateManyInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type paymentCreateInput = {
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
    order?: orderCreateNestedOneWithoutPaymentInput
  }

  export type paymentUncheckedCreateInput = {
    payment_id?: number
    order_id?: number | null
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
  }

  export type paymentUpdateInput = {
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
    order?: orderUpdateOneWithoutPaymentNestedInput
  }

  export type paymentUncheckedUpdateInput = {
    payment_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type paymentCreateManyInput = {
    payment_id?: number
    order_id?: number | null
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
  }

  export type paymentUpdateManyMutationInput = {
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type paymentUncheckedUpdateManyInput = {
    payment_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type productCreateInput = {
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowCreateNestedManyWithoutProductInput
    order_details?: order_detailsCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutProductInput
  }

  export type productUncheckedCreateInput = {
    product_id?: number
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedCreateNestedManyWithoutProductInput
    order_details?: order_detailsUncheckedCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type productUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUpdateManyWithoutProductNestedInput
    order_details?: order_detailsUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutProductNestedInput
  }

  export type productUncheckedUpdateInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedUpdateManyWithoutProductNestedInput
    order_details?: order_detailsUncheckedUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type productCreateManyInput = {
    product_id?: number
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type productUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type productUncheckedUpdateManyInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type quotationCreateInput = {
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderCreateNestedManyWithoutQuotationInput
    customer?: customerCreateNestedOneWithoutQuotationInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutQuotationInput
  }

  export type quotationUncheckedCreateInput = {
    quotation_id?: number
    customer_id?: number | null
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderUncheckedCreateNestedManyWithoutQuotationInput
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutQuotationInput
  }

  export type quotationUpdateInput = {
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUpdateManyWithoutQuotationNestedInput
    customer?: customerUpdateOneWithoutQuotationNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutQuotationNestedInput
  }

  export type quotationUncheckedUpdateInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUncheckedUpdateManyWithoutQuotationNestedInput
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutQuotationNestedInput
  }

  export type quotationCreateManyInput = {
    quotation_id?: number
    customer_id?: number | null
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type quotationUpdateManyMutationInput = {
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type quotationUncheckedUpdateManyInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type quotation_detailsCreateInput = {
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
    product?: productCreateNestedOneWithoutQuotation_detailsInput
    quotation?: quotationCreateNestedOneWithoutQuotation_detailsInput
  }

  export type quotation_detailsUncheckedCreateInput = {
    quotation_item_id?: number
    quotation_id?: number | null
    product_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsUpdateInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    product?: productUpdateOneWithoutQuotation_detailsNestedInput
    quotation?: quotationUpdateOneWithoutQuotation_detailsNestedInput
  }

  export type quotation_detailsUncheckedUpdateInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsCreateManyInput = {
    quotation_item_id?: number
    quotation_id?: number | null
    product_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsUpdateManyMutationInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsUncheckedUpdateManyInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableListFilter<$PrismaModel = never> = {
    equals?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    has?: string | StringFieldRefInput<$PrismaModel> | null
    hasEvery?: string[] | ListStringFieldRefInput<$PrismaModel>
    hasSome?: string[] | ListStringFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type adminCountOrderByAggregateInput = {
    admin_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    roles?: SortOrder
    email?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type adminAvgOrderByAggregateInput = {
    admin_id?: SortOrder
  }

  export type adminMaxOrderByAggregateInput = {
    admin_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type adminMinOrderByAggregateInput = {
    admin_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type adminSumOrderByAggregateInput = {
    admin_id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type Enumcredit_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.credit_status_enum | Enumcredit_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel> | $Enums.credit_status_enum | null
  }

  export type CustomerNullableScalarRelationFilter = {
    is?: customerWhereInput | null
    isNot?: customerWhereInput | null
  }

  export type creditCountOrderByAggregateInput = {
    credit_id?: SortOrder
    customer_id?: SortOrder
    due_date?: SortOrder
    credit_amount?: SortOrder
    status?: SortOrder
    total_credit_limit?: SortOrder
    available_credit_limit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type creditAvgOrderByAggregateInput = {
    credit_id?: SortOrder
    customer_id?: SortOrder
    credit_amount?: SortOrder
    total_credit_limit?: SortOrder
    available_credit_limit?: SortOrder
  }

  export type creditMaxOrderByAggregateInput = {
    credit_id?: SortOrder
    customer_id?: SortOrder
    due_date?: SortOrder
    credit_amount?: SortOrder
    status?: SortOrder
    total_credit_limit?: SortOrder
    available_credit_limit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type creditMinOrderByAggregateInput = {
    credit_id?: SortOrder
    customer_id?: SortOrder
    due_date?: SortOrder
    credit_amount?: SortOrder
    status?: SortOrder
    total_credit_limit?: SortOrder
    available_credit_limit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type creditSumOrderByAggregateInput = {
    credit_id?: SortOrder
    customer_id?: SortOrder
    credit_amount?: SortOrder
    total_credit_limit?: SortOrder
    available_credit_limit?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type Enumcredit_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.credit_status_enum | Enumcredit_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumcredit_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.credit_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel>
  }

  export type DecimalNullableFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
  }

  export type CreditNullableScalarRelationFilter = {
    is?: creditWhereInput | null
    isNot?: creditWhereInput | null
  }

  export type NotificationListRelationFilter = {
    every?: notificationWhereInput
    some?: notificationWhereInput
    none?: notificationWhereInput
  }

  export type OrderListRelationFilter = {
    every?: orderWhereInput
    some?: orderWhereInput
    none?: orderWhereInput
  }

  export type QuotationListRelationFilter = {
    every?: quotationWhereInput
    some?: quotationWhereInput
    none?: quotationWhereInput
  }

  export type notificationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type orderOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type quotationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type customerCountOrderByAggregateInput = {
    customer_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    mobile_number?: SortOrder
    credit_limit?: SortOrder
    remaining_credit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type customerAvgOrderByAggregateInput = {
    customer_id?: SortOrder
    credit_limit?: SortOrder
    remaining_credit?: SortOrder
  }

  export type customerMaxOrderByAggregateInput = {
    customer_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    mobile_number?: SortOrder
    credit_limit?: SortOrder
    remaining_credit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type customerMinOrderByAggregateInput = {
    customer_id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    email?: SortOrder
    mobile_number?: SortOrder
    credit_limit?: SortOrder
    remaining_credit?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type customerSumOrderByAggregateInput = {
    customer_id?: SortOrder
    credit_limit?: SortOrder
    remaining_credit?: SortOrder
  }

  export type DecimalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedDecimalNullableFilter<$PrismaModel>
    _sum?: NestedDecimalNullableFilter<$PrismaModel>
    _min?: NestedDecimalNullableFilter<$PrismaModel>
    _max?: NestedDecimalNullableFilter<$PrismaModel>
  }

  export type Enumflow_direction_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.flow_direction_enum | Enumflow_direction_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel> | $Enums.flow_direction_enum | null
  }

  export type ProductNullableScalarRelationFilter = {
    is?: productWhereInput | null
    isNot?: productWhereInput | null
  }

  export type inventory_inflow_outflowCountOrderByAggregateInput = {
    id?: SortOrder
    product_id?: SortOrder
    flow_direction?: SortOrder
    quantity?: SortOrder
    created_at?: SortOrder
  }

  export type inventory_inflow_outflowAvgOrderByAggregateInput = {
    id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
  }

  export type inventory_inflow_outflowMaxOrderByAggregateInput = {
    id?: SortOrder
    product_id?: SortOrder
    flow_direction?: SortOrder
    quantity?: SortOrder
    created_at?: SortOrder
  }

  export type inventory_inflow_outflowMinOrderByAggregateInput = {
    id?: SortOrder
    product_id?: SortOrder
    flow_direction?: SortOrder
    quantity?: SortOrder
    created_at?: SortOrder
  }

  export type inventory_inflow_outflowSumOrderByAggregateInput = {
    id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
  }

  export type Enumflow_direction_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.flow_direction_enum | Enumflow_direction_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumflow_direction_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.flow_direction_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel>
  }

  export type notificationCountOrderByAggregateInput = {
    notification_id?: SortOrder
    customer_id?: SortOrder
    message?: SortOrder
    sent_at?: SortOrder
  }

  export type notificationAvgOrderByAggregateInput = {
    notification_id?: SortOrder
    customer_id?: SortOrder
  }

  export type notificationMaxOrderByAggregateInput = {
    notification_id?: SortOrder
    customer_id?: SortOrder
    message?: SortOrder
    sent_at?: SortOrder
  }

  export type notificationMinOrderByAggregateInput = {
    notification_id?: SortOrder
    customer_id?: SortOrder
    message?: SortOrder
    sent_at?: SortOrder
  }

  export type notificationSumOrderByAggregateInput = {
    notification_id?: SortOrder
    customer_id?: SortOrder
  }

  export type Enumorder_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.order_status_enum | Enumorder_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumorder_status_enumNullableFilter<$PrismaModel> | $Enums.order_status_enum | null
  }

  export type QuotationNullableScalarRelationFilter = {
    is?: quotationWhereInput | null
    isNot?: quotationWhereInput | null
  }

  export type Order_detailsListRelationFilter = {
    every?: order_detailsWhereInput
    some?: order_detailsWhereInput
    none?: order_detailsWhereInput
  }

  export type PaymentListRelationFilter = {
    every?: paymentWhereInput
    some?: paymentWhereInput
    none?: paymentWhereInput
  }

  export type order_detailsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type paymentOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type orderCountOrderByAggregateInput = {
    order_id?: SortOrder
    quotation_id?: SortOrder
    customer_id?: SortOrder
    status?: SortOrder
    total_price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type orderAvgOrderByAggregateInput = {
    order_id?: SortOrder
    quotation_id?: SortOrder
    customer_id?: SortOrder
    total_price?: SortOrder
  }

  export type orderMaxOrderByAggregateInput = {
    order_id?: SortOrder
    quotation_id?: SortOrder
    customer_id?: SortOrder
    status?: SortOrder
    total_price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type orderMinOrderByAggregateInput = {
    order_id?: SortOrder
    quotation_id?: SortOrder
    customer_id?: SortOrder
    status?: SortOrder
    total_price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type orderSumOrderByAggregateInput = {
    order_id?: SortOrder
    quotation_id?: SortOrder
    customer_id?: SortOrder
    total_price?: SortOrder
  }

  export type Enumorder_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.order_status_enum | Enumorder_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumorder_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.order_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumorder_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumorder_status_enumNullableFilter<$PrismaModel>
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type OrderNullableScalarRelationFilter = {
    is?: orderWhereInput | null
    isNot?: orderWhereInput | null
  }

  export type order_detailsCountOrderByAggregateInput = {
    order_item_id?: SortOrder
    order_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type order_detailsAvgOrderByAggregateInput = {
    order_item_id?: SortOrder
    order_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type order_detailsMaxOrderByAggregateInput = {
    order_item_id?: SortOrder
    order_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type order_detailsMinOrderByAggregateInput = {
    order_item_id?: SortOrder
    order_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type order_detailsSumOrderByAggregateInput = {
    order_item_id?: SortOrder
    order_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type Enumpayment_mode_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_mode_enum | Enumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel> | $Enums.payment_mode_enum | null
  }

  export type Enumpayment_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_status_enum | Enumpayment_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel> | $Enums.payment_status_enum | null
  }

  export type paymentCountOrderByAggregateInput = {
    payment_id?: SortOrder
    order_id?: SortOrder
    amount?: SortOrder
    payment_mode?: SortOrder
    payment_date?: SortOrder
    status?: SortOrder
  }

  export type paymentAvgOrderByAggregateInput = {
    payment_id?: SortOrder
    order_id?: SortOrder
    amount?: SortOrder
  }

  export type paymentMaxOrderByAggregateInput = {
    payment_id?: SortOrder
    order_id?: SortOrder
    amount?: SortOrder
    payment_mode?: SortOrder
    payment_date?: SortOrder
    status?: SortOrder
  }

  export type paymentMinOrderByAggregateInput = {
    payment_id?: SortOrder
    order_id?: SortOrder
    amount?: SortOrder
    payment_mode?: SortOrder
    payment_date?: SortOrder
    status?: SortOrder
  }

  export type paymentSumOrderByAggregateInput = {
    payment_id?: SortOrder
    order_id?: SortOrder
    amount?: SortOrder
  }

  export type Enumpayment_mode_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_mode_enum | Enumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_mode_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.payment_mode_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel>
  }

  export type Enumpayment_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_status_enum | Enumpayment_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.payment_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel>
  }

  export type Inventory_inflow_outflowListRelationFilter = {
    every?: inventory_inflow_outflowWhereInput
    some?: inventory_inflow_outflowWhereInput
    none?: inventory_inflow_outflowWhereInput
  }

  export type Quotation_detailsListRelationFilter = {
    every?: quotation_detailsWhereInput
    some?: quotation_detailsWhereInput
    none?: quotation_detailsWhereInput
  }

  export type inventory_inflow_outflowOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type quotation_detailsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type productCountOrderByAggregateInput = {
    product_id?: SortOrder
    name?: SortOrder
    min_stock_limit?: SortOrder
    description?: SortOrder
    specifications?: SortOrder
    image_url?: SortOrder
    price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type productAvgOrderByAggregateInput = {
    product_id?: SortOrder
    min_stock_limit?: SortOrder
    price?: SortOrder
  }

  export type productMaxOrderByAggregateInput = {
    product_id?: SortOrder
    name?: SortOrder
    min_stock_limit?: SortOrder
    description?: SortOrder
    specifications?: SortOrder
    price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type productMinOrderByAggregateInput = {
    product_id?: SortOrder
    name?: SortOrder
    min_stock_limit?: SortOrder
    description?: SortOrder
    specifications?: SortOrder
    price?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type productSumOrderByAggregateInput = {
    product_id?: SortOrder
    min_stock_limit?: SortOrder
    price?: SortOrder
  }

  export type Enumquotation_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.quotation_status_enum | Enumquotation_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel> | $Enums.quotation_status_enum | null
  }

  export type quotationCountOrderByAggregateInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrder
    admin_id?: SortOrder
    status?: SortOrder
    total_amount?: SortOrder
    credit_period?: SortOrder
    payment_mode?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type quotationAvgOrderByAggregateInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrder
    admin_id?: SortOrder
    total_amount?: SortOrder
    credit_period?: SortOrder
  }

  export type quotationMaxOrderByAggregateInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrder
    admin_id?: SortOrder
    status?: SortOrder
    total_amount?: SortOrder
    credit_period?: SortOrder
    payment_mode?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type quotationMinOrderByAggregateInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrder
    admin_id?: SortOrder
    status?: SortOrder
    total_amount?: SortOrder
    credit_period?: SortOrder
    payment_mode?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type quotationSumOrderByAggregateInput = {
    quotation_id?: SortOrder
    customer_id?: SortOrder
    admin_id?: SortOrder
    total_amount?: SortOrder
    credit_period?: SortOrder
  }

  export type Enumquotation_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.quotation_status_enum | Enumquotation_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumquotation_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.quotation_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel>
  }

  export type quotation_detailsCountOrderByAggregateInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type quotation_detailsAvgOrderByAggregateInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type quotation_detailsMaxOrderByAggregateInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type quotation_detailsMinOrderByAggregateInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type quotation_detailsSumOrderByAggregateInput = {
    quotation_item_id?: SortOrder
    quotation_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    price?: SortOrder
  }

  export type adminCreaterolesInput = {
    set: string[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type adminUpdaterolesInput = {
    set?: string[]
    push?: string | string[]
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type customerCreateNestedOneWithoutCreditInput = {
    create?: XOR<customerCreateWithoutCreditInput, customerUncheckedCreateWithoutCreditInput>
    connectOrCreate?: customerCreateOrConnectWithoutCreditInput
    connect?: customerWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableEnumcredit_status_enumFieldUpdateOperationsInput = {
    set?: $Enums.credit_status_enum | null
  }

  export type customerUpdateOneWithoutCreditNestedInput = {
    create?: XOR<customerCreateWithoutCreditInput, customerUncheckedCreateWithoutCreditInput>
    connectOrCreate?: customerCreateOrConnectWithoutCreditInput
    upsert?: customerUpsertWithoutCreditInput
    disconnect?: customerWhereInput | boolean
    delete?: customerWhereInput | boolean
    connect?: customerWhereUniqueInput
    update?: XOR<XOR<customerUpdateToOneWithWhereWithoutCreditInput, customerUpdateWithoutCreditInput>, customerUncheckedUpdateWithoutCreditInput>
  }

  export type creditCreateNestedOneWithoutCustomerInput = {
    create?: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
    connectOrCreate?: creditCreateOrConnectWithoutCustomerInput
    connect?: creditWhereUniqueInput
  }

  export type notificationCreateNestedManyWithoutCustomerInput = {
    create?: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput> | notificationCreateWithoutCustomerInput[] | notificationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: notificationCreateOrConnectWithoutCustomerInput | notificationCreateOrConnectWithoutCustomerInput[]
    createMany?: notificationCreateManyCustomerInputEnvelope
    connect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
  }

  export type orderCreateNestedManyWithoutCustomerInput = {
    create?: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput> | orderCreateWithoutCustomerInput[] | orderUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: orderCreateOrConnectWithoutCustomerInput | orderCreateOrConnectWithoutCustomerInput[]
    createMany?: orderCreateManyCustomerInputEnvelope
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
  }

  export type quotationCreateNestedManyWithoutCustomerInput = {
    create?: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput> | quotationCreateWithoutCustomerInput[] | quotationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: quotationCreateOrConnectWithoutCustomerInput | quotationCreateOrConnectWithoutCustomerInput[]
    createMany?: quotationCreateManyCustomerInputEnvelope
    connect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
  }

  export type creditUncheckedCreateNestedOneWithoutCustomerInput = {
    create?: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
    connectOrCreate?: creditCreateOrConnectWithoutCustomerInput
    connect?: creditWhereUniqueInput
  }

  export type notificationUncheckedCreateNestedManyWithoutCustomerInput = {
    create?: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput> | notificationCreateWithoutCustomerInput[] | notificationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: notificationCreateOrConnectWithoutCustomerInput | notificationCreateOrConnectWithoutCustomerInput[]
    createMany?: notificationCreateManyCustomerInputEnvelope
    connect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
  }

  export type orderUncheckedCreateNestedManyWithoutCustomerInput = {
    create?: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput> | orderCreateWithoutCustomerInput[] | orderUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: orderCreateOrConnectWithoutCustomerInput | orderCreateOrConnectWithoutCustomerInput[]
    createMany?: orderCreateManyCustomerInputEnvelope
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
  }

  export type quotationUncheckedCreateNestedManyWithoutCustomerInput = {
    create?: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput> | quotationCreateWithoutCustomerInput[] | quotationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: quotationCreateOrConnectWithoutCustomerInput | quotationCreateOrConnectWithoutCustomerInput[]
    createMany?: quotationCreateManyCustomerInputEnvelope
    connect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
  }

  export type NullableDecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string | null
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type creditUpdateOneWithoutCustomerNestedInput = {
    create?: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
    connectOrCreate?: creditCreateOrConnectWithoutCustomerInput
    upsert?: creditUpsertWithoutCustomerInput
    disconnect?: creditWhereInput | boolean
    delete?: creditWhereInput | boolean
    connect?: creditWhereUniqueInput
    update?: XOR<XOR<creditUpdateToOneWithWhereWithoutCustomerInput, creditUpdateWithoutCustomerInput>, creditUncheckedUpdateWithoutCustomerInput>
  }

  export type notificationUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput> | notificationCreateWithoutCustomerInput[] | notificationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: notificationCreateOrConnectWithoutCustomerInput | notificationCreateOrConnectWithoutCustomerInput[]
    upsert?: notificationUpsertWithWhereUniqueWithoutCustomerInput | notificationUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: notificationCreateManyCustomerInputEnvelope
    set?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    disconnect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    delete?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    connect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    update?: notificationUpdateWithWhereUniqueWithoutCustomerInput | notificationUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: notificationUpdateManyWithWhereWithoutCustomerInput | notificationUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: notificationScalarWhereInput | notificationScalarWhereInput[]
  }

  export type orderUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput> | orderCreateWithoutCustomerInput[] | orderUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: orderCreateOrConnectWithoutCustomerInput | orderCreateOrConnectWithoutCustomerInput[]
    upsert?: orderUpsertWithWhereUniqueWithoutCustomerInput | orderUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: orderCreateManyCustomerInputEnvelope
    set?: orderWhereUniqueInput | orderWhereUniqueInput[]
    disconnect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    delete?: orderWhereUniqueInput | orderWhereUniqueInput[]
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    update?: orderUpdateWithWhereUniqueWithoutCustomerInput | orderUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: orderUpdateManyWithWhereWithoutCustomerInput | orderUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: orderScalarWhereInput | orderScalarWhereInput[]
  }

  export type quotationUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput> | quotationCreateWithoutCustomerInput[] | quotationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: quotationCreateOrConnectWithoutCustomerInput | quotationCreateOrConnectWithoutCustomerInput[]
    upsert?: quotationUpsertWithWhereUniqueWithoutCustomerInput | quotationUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: quotationCreateManyCustomerInputEnvelope
    set?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    disconnect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    delete?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    connect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    update?: quotationUpdateWithWhereUniqueWithoutCustomerInput | quotationUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: quotationUpdateManyWithWhereWithoutCustomerInput | quotationUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: quotationScalarWhereInput | quotationScalarWhereInput[]
  }

  export type creditUncheckedUpdateOneWithoutCustomerNestedInput = {
    create?: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
    connectOrCreate?: creditCreateOrConnectWithoutCustomerInput
    upsert?: creditUpsertWithoutCustomerInput
    disconnect?: creditWhereInput | boolean
    delete?: creditWhereInput | boolean
    connect?: creditWhereUniqueInput
    update?: XOR<XOR<creditUpdateToOneWithWhereWithoutCustomerInput, creditUpdateWithoutCustomerInput>, creditUncheckedUpdateWithoutCustomerInput>
  }

  export type notificationUncheckedUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput> | notificationCreateWithoutCustomerInput[] | notificationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: notificationCreateOrConnectWithoutCustomerInput | notificationCreateOrConnectWithoutCustomerInput[]
    upsert?: notificationUpsertWithWhereUniqueWithoutCustomerInput | notificationUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: notificationCreateManyCustomerInputEnvelope
    set?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    disconnect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    delete?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    connect?: notificationWhereUniqueInput | notificationWhereUniqueInput[]
    update?: notificationUpdateWithWhereUniqueWithoutCustomerInput | notificationUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: notificationUpdateManyWithWhereWithoutCustomerInput | notificationUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: notificationScalarWhereInput | notificationScalarWhereInput[]
  }

  export type orderUncheckedUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput> | orderCreateWithoutCustomerInput[] | orderUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: orderCreateOrConnectWithoutCustomerInput | orderCreateOrConnectWithoutCustomerInput[]
    upsert?: orderUpsertWithWhereUniqueWithoutCustomerInput | orderUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: orderCreateManyCustomerInputEnvelope
    set?: orderWhereUniqueInput | orderWhereUniqueInput[]
    disconnect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    delete?: orderWhereUniqueInput | orderWhereUniqueInput[]
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    update?: orderUpdateWithWhereUniqueWithoutCustomerInput | orderUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: orderUpdateManyWithWhereWithoutCustomerInput | orderUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: orderScalarWhereInput | orderScalarWhereInput[]
  }

  export type quotationUncheckedUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput> | quotationCreateWithoutCustomerInput[] | quotationUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: quotationCreateOrConnectWithoutCustomerInput | quotationCreateOrConnectWithoutCustomerInput[]
    upsert?: quotationUpsertWithWhereUniqueWithoutCustomerInput | quotationUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: quotationCreateManyCustomerInputEnvelope
    set?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    disconnect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    delete?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    connect?: quotationWhereUniqueInput | quotationWhereUniqueInput[]
    update?: quotationUpdateWithWhereUniqueWithoutCustomerInput | quotationUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: quotationUpdateManyWithWhereWithoutCustomerInput | quotationUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: quotationScalarWhereInput | quotationScalarWhereInput[]
  }

  export type productCreateNestedOneWithoutInventory_inflow_outflowInput = {
    create?: XOR<productCreateWithoutInventory_inflow_outflowInput, productUncheckedCreateWithoutInventory_inflow_outflowInput>
    connectOrCreate?: productCreateOrConnectWithoutInventory_inflow_outflowInput
    connect?: productWhereUniqueInput
  }

  export type NullableEnumflow_direction_enumFieldUpdateOperationsInput = {
    set?: $Enums.flow_direction_enum | null
  }

  export type productUpdateOneWithoutInventory_inflow_outflowNestedInput = {
    create?: XOR<productCreateWithoutInventory_inflow_outflowInput, productUncheckedCreateWithoutInventory_inflow_outflowInput>
    connectOrCreate?: productCreateOrConnectWithoutInventory_inflow_outflowInput
    upsert?: productUpsertWithoutInventory_inflow_outflowInput
    disconnect?: productWhereInput | boolean
    delete?: productWhereInput | boolean
    connect?: productWhereUniqueInput
    update?: XOR<XOR<productUpdateToOneWithWhereWithoutInventory_inflow_outflowInput, productUpdateWithoutInventory_inflow_outflowInput>, productUncheckedUpdateWithoutInventory_inflow_outflowInput>
  }

  export type customerCreateNestedOneWithoutNotificationInput = {
    create?: XOR<customerCreateWithoutNotificationInput, customerUncheckedCreateWithoutNotificationInput>
    connectOrCreate?: customerCreateOrConnectWithoutNotificationInput
    connect?: customerWhereUniqueInput
  }

  export type customerUpdateOneWithoutNotificationNestedInput = {
    create?: XOR<customerCreateWithoutNotificationInput, customerUncheckedCreateWithoutNotificationInput>
    connectOrCreate?: customerCreateOrConnectWithoutNotificationInput
    upsert?: customerUpsertWithoutNotificationInput
    disconnect?: customerWhereInput | boolean
    delete?: customerWhereInput | boolean
    connect?: customerWhereUniqueInput
    update?: XOR<XOR<customerUpdateToOneWithWhereWithoutNotificationInput, customerUpdateWithoutNotificationInput>, customerUncheckedUpdateWithoutNotificationInput>
  }

  export type customerCreateNestedOneWithoutOrderInput = {
    create?: XOR<customerCreateWithoutOrderInput, customerUncheckedCreateWithoutOrderInput>
    connectOrCreate?: customerCreateOrConnectWithoutOrderInput
    connect?: customerWhereUniqueInput
  }

  export type quotationCreateNestedOneWithoutOrderInput = {
    create?: XOR<quotationCreateWithoutOrderInput, quotationUncheckedCreateWithoutOrderInput>
    connectOrCreate?: quotationCreateOrConnectWithoutOrderInput
    connect?: quotationWhereUniqueInput
  }

  export type order_detailsCreateNestedManyWithoutOrderInput = {
    create?: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput> | order_detailsCreateWithoutOrderInput[] | order_detailsUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutOrderInput | order_detailsCreateOrConnectWithoutOrderInput[]
    createMany?: order_detailsCreateManyOrderInputEnvelope
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
  }

  export type paymentCreateNestedManyWithoutOrderInput = {
    create?: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput> | paymentCreateWithoutOrderInput[] | paymentUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: paymentCreateOrConnectWithoutOrderInput | paymentCreateOrConnectWithoutOrderInput[]
    createMany?: paymentCreateManyOrderInputEnvelope
    connect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
  }

  export type order_detailsUncheckedCreateNestedManyWithoutOrderInput = {
    create?: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput> | order_detailsCreateWithoutOrderInput[] | order_detailsUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutOrderInput | order_detailsCreateOrConnectWithoutOrderInput[]
    createMany?: order_detailsCreateManyOrderInputEnvelope
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
  }

  export type paymentUncheckedCreateNestedManyWithoutOrderInput = {
    create?: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput> | paymentCreateWithoutOrderInput[] | paymentUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: paymentCreateOrConnectWithoutOrderInput | paymentCreateOrConnectWithoutOrderInput[]
    createMany?: paymentCreateManyOrderInputEnvelope
    connect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
  }

  export type NullableEnumorder_status_enumFieldUpdateOperationsInput = {
    set?: $Enums.order_status_enum | null
  }

  export type customerUpdateOneWithoutOrderNestedInput = {
    create?: XOR<customerCreateWithoutOrderInput, customerUncheckedCreateWithoutOrderInput>
    connectOrCreate?: customerCreateOrConnectWithoutOrderInput
    upsert?: customerUpsertWithoutOrderInput
    disconnect?: customerWhereInput | boolean
    delete?: customerWhereInput | boolean
    connect?: customerWhereUniqueInput
    update?: XOR<XOR<customerUpdateToOneWithWhereWithoutOrderInput, customerUpdateWithoutOrderInput>, customerUncheckedUpdateWithoutOrderInput>
  }

  export type quotationUpdateOneWithoutOrderNestedInput = {
    create?: XOR<quotationCreateWithoutOrderInput, quotationUncheckedCreateWithoutOrderInput>
    connectOrCreate?: quotationCreateOrConnectWithoutOrderInput
    upsert?: quotationUpsertWithoutOrderInput
    disconnect?: quotationWhereInput | boolean
    delete?: quotationWhereInput | boolean
    connect?: quotationWhereUniqueInput
    update?: XOR<XOR<quotationUpdateToOneWithWhereWithoutOrderInput, quotationUpdateWithoutOrderInput>, quotationUncheckedUpdateWithoutOrderInput>
  }

  export type order_detailsUpdateManyWithoutOrderNestedInput = {
    create?: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput> | order_detailsCreateWithoutOrderInput[] | order_detailsUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutOrderInput | order_detailsCreateOrConnectWithoutOrderInput[]
    upsert?: order_detailsUpsertWithWhereUniqueWithoutOrderInput | order_detailsUpsertWithWhereUniqueWithoutOrderInput[]
    createMany?: order_detailsCreateManyOrderInputEnvelope
    set?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    disconnect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    delete?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    update?: order_detailsUpdateWithWhereUniqueWithoutOrderInput | order_detailsUpdateWithWhereUniqueWithoutOrderInput[]
    updateMany?: order_detailsUpdateManyWithWhereWithoutOrderInput | order_detailsUpdateManyWithWhereWithoutOrderInput[]
    deleteMany?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
  }

  export type paymentUpdateManyWithoutOrderNestedInput = {
    create?: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput> | paymentCreateWithoutOrderInput[] | paymentUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: paymentCreateOrConnectWithoutOrderInput | paymentCreateOrConnectWithoutOrderInput[]
    upsert?: paymentUpsertWithWhereUniqueWithoutOrderInput | paymentUpsertWithWhereUniqueWithoutOrderInput[]
    createMany?: paymentCreateManyOrderInputEnvelope
    set?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    disconnect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    delete?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    connect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    update?: paymentUpdateWithWhereUniqueWithoutOrderInput | paymentUpdateWithWhereUniqueWithoutOrderInput[]
    updateMany?: paymentUpdateManyWithWhereWithoutOrderInput | paymentUpdateManyWithWhereWithoutOrderInput[]
    deleteMany?: paymentScalarWhereInput | paymentScalarWhereInput[]
  }

  export type order_detailsUncheckedUpdateManyWithoutOrderNestedInput = {
    create?: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput> | order_detailsCreateWithoutOrderInput[] | order_detailsUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutOrderInput | order_detailsCreateOrConnectWithoutOrderInput[]
    upsert?: order_detailsUpsertWithWhereUniqueWithoutOrderInput | order_detailsUpsertWithWhereUniqueWithoutOrderInput[]
    createMany?: order_detailsCreateManyOrderInputEnvelope
    set?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    disconnect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    delete?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    update?: order_detailsUpdateWithWhereUniqueWithoutOrderInput | order_detailsUpdateWithWhereUniqueWithoutOrderInput[]
    updateMany?: order_detailsUpdateManyWithWhereWithoutOrderInput | order_detailsUpdateManyWithWhereWithoutOrderInput[]
    deleteMany?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
  }

  export type paymentUncheckedUpdateManyWithoutOrderNestedInput = {
    create?: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput> | paymentCreateWithoutOrderInput[] | paymentUncheckedCreateWithoutOrderInput[]
    connectOrCreate?: paymentCreateOrConnectWithoutOrderInput | paymentCreateOrConnectWithoutOrderInput[]
    upsert?: paymentUpsertWithWhereUniqueWithoutOrderInput | paymentUpsertWithWhereUniqueWithoutOrderInput[]
    createMany?: paymentCreateManyOrderInputEnvelope
    set?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    disconnect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    delete?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    connect?: paymentWhereUniqueInput | paymentWhereUniqueInput[]
    update?: paymentUpdateWithWhereUniqueWithoutOrderInput | paymentUpdateWithWhereUniqueWithoutOrderInput[]
    updateMany?: paymentUpdateManyWithWhereWithoutOrderInput | paymentUpdateManyWithWhereWithoutOrderInput[]
    deleteMany?: paymentScalarWhereInput | paymentScalarWhereInput[]
  }

  export type orderCreateNestedOneWithoutOrder_detailsInput = {
    create?: XOR<orderCreateWithoutOrder_detailsInput, orderUncheckedCreateWithoutOrder_detailsInput>
    connectOrCreate?: orderCreateOrConnectWithoutOrder_detailsInput
    connect?: orderWhereUniqueInput
  }

  export type productCreateNestedOneWithoutOrder_detailsInput = {
    create?: XOR<productCreateWithoutOrder_detailsInput, productUncheckedCreateWithoutOrder_detailsInput>
    connectOrCreate?: productCreateOrConnectWithoutOrder_detailsInput
    connect?: productWhereUniqueInput
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type orderUpdateOneWithoutOrder_detailsNestedInput = {
    create?: XOR<orderCreateWithoutOrder_detailsInput, orderUncheckedCreateWithoutOrder_detailsInput>
    connectOrCreate?: orderCreateOrConnectWithoutOrder_detailsInput
    upsert?: orderUpsertWithoutOrder_detailsInput
    disconnect?: orderWhereInput | boolean
    delete?: orderWhereInput | boolean
    connect?: orderWhereUniqueInput
    update?: XOR<XOR<orderUpdateToOneWithWhereWithoutOrder_detailsInput, orderUpdateWithoutOrder_detailsInput>, orderUncheckedUpdateWithoutOrder_detailsInput>
  }

  export type productUpdateOneWithoutOrder_detailsNestedInput = {
    create?: XOR<productCreateWithoutOrder_detailsInput, productUncheckedCreateWithoutOrder_detailsInput>
    connectOrCreate?: productCreateOrConnectWithoutOrder_detailsInput
    upsert?: productUpsertWithoutOrder_detailsInput
    disconnect?: productWhereInput | boolean
    delete?: productWhereInput | boolean
    connect?: productWhereUniqueInput
    update?: XOR<XOR<productUpdateToOneWithWhereWithoutOrder_detailsInput, productUpdateWithoutOrder_detailsInput>, productUncheckedUpdateWithoutOrder_detailsInput>
  }

  export type orderCreateNestedOneWithoutPaymentInput = {
    create?: XOR<orderCreateWithoutPaymentInput, orderUncheckedCreateWithoutPaymentInput>
    connectOrCreate?: orderCreateOrConnectWithoutPaymentInput
    connect?: orderWhereUniqueInput
  }

  export type NullableEnumpayment_mode_enumFieldUpdateOperationsInput = {
    set?: $Enums.payment_mode_enum | null
  }

  export type NullableEnumpayment_status_enumFieldUpdateOperationsInput = {
    set?: $Enums.payment_status_enum | null
  }

  export type orderUpdateOneWithoutPaymentNestedInput = {
    create?: XOR<orderCreateWithoutPaymentInput, orderUncheckedCreateWithoutPaymentInput>
    connectOrCreate?: orderCreateOrConnectWithoutPaymentInput
    upsert?: orderUpsertWithoutPaymentInput
    disconnect?: orderWhereInput | boolean
    delete?: orderWhereInput | boolean
    connect?: orderWhereUniqueInput
    update?: XOR<XOR<orderUpdateToOneWithWhereWithoutPaymentInput, orderUpdateWithoutPaymentInput>, orderUncheckedUpdateWithoutPaymentInput>
  }

  export type productCreateimage_urlInput = {
    set: string[]
  }

  export type inventory_inflow_outflowCreateNestedManyWithoutProductInput = {
    create?: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput> | inventory_inflow_outflowCreateWithoutProductInput[] | inventory_inflow_outflowUncheckedCreateWithoutProductInput[]
    connectOrCreate?: inventory_inflow_outflowCreateOrConnectWithoutProductInput | inventory_inflow_outflowCreateOrConnectWithoutProductInput[]
    createMany?: inventory_inflow_outflowCreateManyProductInputEnvelope
    connect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
  }

  export type order_detailsCreateNestedManyWithoutProductInput = {
    create?: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput> | order_detailsCreateWithoutProductInput[] | order_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutProductInput | order_detailsCreateOrConnectWithoutProductInput[]
    createMany?: order_detailsCreateManyProductInputEnvelope
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
  }

  export type quotation_detailsCreateNestedManyWithoutProductInput = {
    create?: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput> | quotation_detailsCreateWithoutProductInput[] | quotation_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutProductInput | quotation_detailsCreateOrConnectWithoutProductInput[]
    createMany?: quotation_detailsCreateManyProductInputEnvelope
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
  }

  export type inventory_inflow_outflowUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput> | inventory_inflow_outflowCreateWithoutProductInput[] | inventory_inflow_outflowUncheckedCreateWithoutProductInput[]
    connectOrCreate?: inventory_inflow_outflowCreateOrConnectWithoutProductInput | inventory_inflow_outflowCreateOrConnectWithoutProductInput[]
    createMany?: inventory_inflow_outflowCreateManyProductInputEnvelope
    connect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
  }

  export type order_detailsUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput> | order_detailsCreateWithoutProductInput[] | order_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutProductInput | order_detailsCreateOrConnectWithoutProductInput[]
    createMany?: order_detailsCreateManyProductInputEnvelope
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
  }

  export type quotation_detailsUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput> | quotation_detailsCreateWithoutProductInput[] | quotation_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutProductInput | quotation_detailsCreateOrConnectWithoutProductInput[]
    createMany?: quotation_detailsCreateManyProductInputEnvelope
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
  }

  export type productUpdateimage_urlInput = {
    set?: string[]
    push?: string | string[]
  }

  export type inventory_inflow_outflowUpdateManyWithoutProductNestedInput = {
    create?: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput> | inventory_inflow_outflowCreateWithoutProductInput[] | inventory_inflow_outflowUncheckedCreateWithoutProductInput[]
    connectOrCreate?: inventory_inflow_outflowCreateOrConnectWithoutProductInput | inventory_inflow_outflowCreateOrConnectWithoutProductInput[]
    upsert?: inventory_inflow_outflowUpsertWithWhereUniqueWithoutProductInput | inventory_inflow_outflowUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: inventory_inflow_outflowCreateManyProductInputEnvelope
    set?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    disconnect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    delete?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    connect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    update?: inventory_inflow_outflowUpdateWithWhereUniqueWithoutProductInput | inventory_inflow_outflowUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: inventory_inflow_outflowUpdateManyWithWhereWithoutProductInput | inventory_inflow_outflowUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: inventory_inflow_outflowScalarWhereInput | inventory_inflow_outflowScalarWhereInput[]
  }

  export type order_detailsUpdateManyWithoutProductNestedInput = {
    create?: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput> | order_detailsCreateWithoutProductInput[] | order_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutProductInput | order_detailsCreateOrConnectWithoutProductInput[]
    upsert?: order_detailsUpsertWithWhereUniqueWithoutProductInput | order_detailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: order_detailsCreateManyProductInputEnvelope
    set?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    disconnect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    delete?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    update?: order_detailsUpdateWithWhereUniqueWithoutProductInput | order_detailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: order_detailsUpdateManyWithWhereWithoutProductInput | order_detailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
  }

  export type quotation_detailsUpdateManyWithoutProductNestedInput = {
    create?: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput> | quotation_detailsCreateWithoutProductInput[] | quotation_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutProductInput | quotation_detailsCreateOrConnectWithoutProductInput[]
    upsert?: quotation_detailsUpsertWithWhereUniqueWithoutProductInput | quotation_detailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: quotation_detailsCreateManyProductInputEnvelope
    set?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    disconnect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    delete?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    update?: quotation_detailsUpdateWithWhereUniqueWithoutProductInput | quotation_detailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: quotation_detailsUpdateManyWithWhereWithoutProductInput | quotation_detailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
  }

  export type inventory_inflow_outflowUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput> | inventory_inflow_outflowCreateWithoutProductInput[] | inventory_inflow_outflowUncheckedCreateWithoutProductInput[]
    connectOrCreate?: inventory_inflow_outflowCreateOrConnectWithoutProductInput | inventory_inflow_outflowCreateOrConnectWithoutProductInput[]
    upsert?: inventory_inflow_outflowUpsertWithWhereUniqueWithoutProductInput | inventory_inflow_outflowUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: inventory_inflow_outflowCreateManyProductInputEnvelope
    set?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    disconnect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    delete?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    connect?: inventory_inflow_outflowWhereUniqueInput | inventory_inflow_outflowWhereUniqueInput[]
    update?: inventory_inflow_outflowUpdateWithWhereUniqueWithoutProductInput | inventory_inflow_outflowUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: inventory_inflow_outflowUpdateManyWithWhereWithoutProductInput | inventory_inflow_outflowUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: inventory_inflow_outflowScalarWhereInput | inventory_inflow_outflowScalarWhereInput[]
  }

  export type order_detailsUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput> | order_detailsCreateWithoutProductInput[] | order_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: order_detailsCreateOrConnectWithoutProductInput | order_detailsCreateOrConnectWithoutProductInput[]
    upsert?: order_detailsUpsertWithWhereUniqueWithoutProductInput | order_detailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: order_detailsCreateManyProductInputEnvelope
    set?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    disconnect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    delete?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    connect?: order_detailsWhereUniqueInput | order_detailsWhereUniqueInput[]
    update?: order_detailsUpdateWithWhereUniqueWithoutProductInput | order_detailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: order_detailsUpdateManyWithWhereWithoutProductInput | order_detailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
  }

  export type quotation_detailsUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput> | quotation_detailsCreateWithoutProductInput[] | quotation_detailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutProductInput | quotation_detailsCreateOrConnectWithoutProductInput[]
    upsert?: quotation_detailsUpsertWithWhereUniqueWithoutProductInput | quotation_detailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: quotation_detailsCreateManyProductInputEnvelope
    set?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    disconnect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    delete?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    update?: quotation_detailsUpdateWithWhereUniqueWithoutProductInput | quotation_detailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: quotation_detailsUpdateManyWithWhereWithoutProductInput | quotation_detailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
  }

  export type orderCreateNestedManyWithoutQuotationInput = {
    create?: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput> | orderCreateWithoutQuotationInput[] | orderUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: orderCreateOrConnectWithoutQuotationInput | orderCreateOrConnectWithoutQuotationInput[]
    createMany?: orderCreateManyQuotationInputEnvelope
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
  }

  export type customerCreateNestedOneWithoutQuotationInput = {
    create?: XOR<customerCreateWithoutQuotationInput, customerUncheckedCreateWithoutQuotationInput>
    connectOrCreate?: customerCreateOrConnectWithoutQuotationInput
    connect?: customerWhereUniqueInput
  }

  export type quotation_detailsCreateNestedManyWithoutQuotationInput = {
    create?: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput> | quotation_detailsCreateWithoutQuotationInput[] | quotation_detailsUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutQuotationInput | quotation_detailsCreateOrConnectWithoutQuotationInput[]
    createMany?: quotation_detailsCreateManyQuotationInputEnvelope
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
  }

  export type orderUncheckedCreateNestedManyWithoutQuotationInput = {
    create?: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput> | orderCreateWithoutQuotationInput[] | orderUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: orderCreateOrConnectWithoutQuotationInput | orderCreateOrConnectWithoutQuotationInput[]
    createMany?: orderCreateManyQuotationInputEnvelope
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
  }

  export type quotation_detailsUncheckedCreateNestedManyWithoutQuotationInput = {
    create?: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput> | quotation_detailsCreateWithoutQuotationInput[] | quotation_detailsUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutQuotationInput | quotation_detailsCreateOrConnectWithoutQuotationInput[]
    createMany?: quotation_detailsCreateManyQuotationInputEnvelope
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
  }

  export type NullableEnumquotation_status_enumFieldUpdateOperationsInput = {
    set?: $Enums.quotation_status_enum | null
  }

  export type orderUpdateManyWithoutQuotationNestedInput = {
    create?: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput> | orderCreateWithoutQuotationInput[] | orderUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: orderCreateOrConnectWithoutQuotationInput | orderCreateOrConnectWithoutQuotationInput[]
    upsert?: orderUpsertWithWhereUniqueWithoutQuotationInput | orderUpsertWithWhereUniqueWithoutQuotationInput[]
    createMany?: orderCreateManyQuotationInputEnvelope
    set?: orderWhereUniqueInput | orderWhereUniqueInput[]
    disconnect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    delete?: orderWhereUniqueInput | orderWhereUniqueInput[]
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    update?: orderUpdateWithWhereUniqueWithoutQuotationInput | orderUpdateWithWhereUniqueWithoutQuotationInput[]
    updateMany?: orderUpdateManyWithWhereWithoutQuotationInput | orderUpdateManyWithWhereWithoutQuotationInput[]
    deleteMany?: orderScalarWhereInput | orderScalarWhereInput[]
  }

  export type customerUpdateOneWithoutQuotationNestedInput = {
    create?: XOR<customerCreateWithoutQuotationInput, customerUncheckedCreateWithoutQuotationInput>
    connectOrCreate?: customerCreateOrConnectWithoutQuotationInput
    upsert?: customerUpsertWithoutQuotationInput
    disconnect?: customerWhereInput | boolean
    delete?: customerWhereInput | boolean
    connect?: customerWhereUniqueInput
    update?: XOR<XOR<customerUpdateToOneWithWhereWithoutQuotationInput, customerUpdateWithoutQuotationInput>, customerUncheckedUpdateWithoutQuotationInput>
  }

  export type quotation_detailsUpdateManyWithoutQuotationNestedInput = {
    create?: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput> | quotation_detailsCreateWithoutQuotationInput[] | quotation_detailsUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutQuotationInput | quotation_detailsCreateOrConnectWithoutQuotationInput[]
    upsert?: quotation_detailsUpsertWithWhereUniqueWithoutQuotationInput | quotation_detailsUpsertWithWhereUniqueWithoutQuotationInput[]
    createMany?: quotation_detailsCreateManyQuotationInputEnvelope
    set?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    disconnect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    delete?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    update?: quotation_detailsUpdateWithWhereUniqueWithoutQuotationInput | quotation_detailsUpdateWithWhereUniqueWithoutQuotationInput[]
    updateMany?: quotation_detailsUpdateManyWithWhereWithoutQuotationInput | quotation_detailsUpdateManyWithWhereWithoutQuotationInput[]
    deleteMany?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
  }

  export type orderUncheckedUpdateManyWithoutQuotationNestedInput = {
    create?: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput> | orderCreateWithoutQuotationInput[] | orderUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: orderCreateOrConnectWithoutQuotationInput | orderCreateOrConnectWithoutQuotationInput[]
    upsert?: orderUpsertWithWhereUniqueWithoutQuotationInput | orderUpsertWithWhereUniqueWithoutQuotationInput[]
    createMany?: orderCreateManyQuotationInputEnvelope
    set?: orderWhereUniqueInput | orderWhereUniqueInput[]
    disconnect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    delete?: orderWhereUniqueInput | orderWhereUniqueInput[]
    connect?: orderWhereUniqueInput | orderWhereUniqueInput[]
    update?: orderUpdateWithWhereUniqueWithoutQuotationInput | orderUpdateWithWhereUniqueWithoutQuotationInput[]
    updateMany?: orderUpdateManyWithWhereWithoutQuotationInput | orderUpdateManyWithWhereWithoutQuotationInput[]
    deleteMany?: orderScalarWhereInput | orderScalarWhereInput[]
  }

  export type quotation_detailsUncheckedUpdateManyWithoutQuotationNestedInput = {
    create?: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput> | quotation_detailsCreateWithoutQuotationInput[] | quotation_detailsUncheckedCreateWithoutQuotationInput[]
    connectOrCreate?: quotation_detailsCreateOrConnectWithoutQuotationInput | quotation_detailsCreateOrConnectWithoutQuotationInput[]
    upsert?: quotation_detailsUpsertWithWhereUniqueWithoutQuotationInput | quotation_detailsUpsertWithWhereUniqueWithoutQuotationInput[]
    createMany?: quotation_detailsCreateManyQuotationInputEnvelope
    set?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    disconnect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    delete?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    connect?: quotation_detailsWhereUniqueInput | quotation_detailsWhereUniqueInput[]
    update?: quotation_detailsUpdateWithWhereUniqueWithoutQuotationInput | quotation_detailsUpdateWithWhereUniqueWithoutQuotationInput[]
    updateMany?: quotation_detailsUpdateManyWithWhereWithoutQuotationInput | quotation_detailsUpdateManyWithWhereWithoutQuotationInput[]
    deleteMany?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
  }

  export type productCreateNestedOneWithoutQuotation_detailsInput = {
    create?: XOR<productCreateWithoutQuotation_detailsInput, productUncheckedCreateWithoutQuotation_detailsInput>
    connectOrCreate?: productCreateOrConnectWithoutQuotation_detailsInput
    connect?: productWhereUniqueInput
  }

  export type quotationCreateNestedOneWithoutQuotation_detailsInput = {
    create?: XOR<quotationCreateWithoutQuotation_detailsInput, quotationUncheckedCreateWithoutQuotation_detailsInput>
    connectOrCreate?: quotationCreateOrConnectWithoutQuotation_detailsInput
    connect?: quotationWhereUniqueInput
  }

  export type productUpdateOneWithoutQuotation_detailsNestedInput = {
    create?: XOR<productCreateWithoutQuotation_detailsInput, productUncheckedCreateWithoutQuotation_detailsInput>
    connectOrCreate?: productCreateOrConnectWithoutQuotation_detailsInput
    upsert?: productUpsertWithoutQuotation_detailsInput
    disconnect?: productWhereInput | boolean
    delete?: productWhereInput | boolean
    connect?: productWhereUniqueInput
    update?: XOR<XOR<productUpdateToOneWithWhereWithoutQuotation_detailsInput, productUpdateWithoutQuotation_detailsInput>, productUncheckedUpdateWithoutQuotation_detailsInput>
  }

  export type quotationUpdateOneWithoutQuotation_detailsNestedInput = {
    create?: XOR<quotationCreateWithoutQuotation_detailsInput, quotationUncheckedCreateWithoutQuotation_detailsInput>
    connectOrCreate?: quotationCreateOrConnectWithoutQuotation_detailsInput
    upsert?: quotationUpsertWithoutQuotation_detailsInput
    disconnect?: quotationWhereInput | boolean
    delete?: quotationWhereInput | boolean
    connect?: quotationWhereUniqueInput
    update?: XOR<XOR<quotationUpdateToOneWithWhereWithoutQuotation_detailsInput, quotationUpdateWithoutQuotation_detailsInput>, quotationUncheckedUpdateWithoutQuotation_detailsInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedEnumcredit_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.credit_status_enum | Enumcredit_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel> | $Enums.credit_status_enum | null
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumcredit_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.credit_status_enum | Enumcredit_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.credit_status_enum[] | ListEnumcredit_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumcredit_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.credit_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumcredit_status_enumNullableFilter<$PrismaModel>
  }

  export type NestedDecimalNullableFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
  }

  export type NestedDecimalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedDecimalNullableFilter<$PrismaModel>
    _sum?: NestedDecimalNullableFilter<$PrismaModel>
    _min?: NestedDecimalNullableFilter<$PrismaModel>
    _max?: NestedDecimalNullableFilter<$PrismaModel>
  }

  export type NestedEnumflow_direction_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.flow_direction_enum | Enumflow_direction_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel> | $Enums.flow_direction_enum | null
  }

  export type NestedEnumflow_direction_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.flow_direction_enum | Enumflow_direction_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.flow_direction_enum[] | ListEnumflow_direction_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumflow_direction_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.flow_direction_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumflow_direction_enumNullableFilter<$PrismaModel>
  }

  export type NestedEnumorder_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.order_status_enum | Enumorder_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumorder_status_enumNullableFilter<$PrismaModel> | $Enums.order_status_enum | null
  }

  export type NestedEnumorder_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.order_status_enum | Enumorder_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.order_status_enum[] | ListEnumorder_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumorder_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.order_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumorder_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumorder_status_enumNullableFilter<$PrismaModel>
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type NestedEnumpayment_mode_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_mode_enum | Enumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel> | $Enums.payment_mode_enum | null
  }

  export type NestedEnumpayment_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_status_enum | Enumpayment_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel> | $Enums.payment_status_enum | null
  }

  export type NestedEnumpayment_mode_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_mode_enum | Enumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_mode_enum[] | ListEnumpayment_mode_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_mode_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.payment_mode_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumpayment_mode_enumNullableFilter<$PrismaModel>
  }

  export type NestedEnumpayment_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.payment_status_enum | Enumpayment_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.payment_status_enum[] | ListEnumpayment_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumpayment_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.payment_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumpayment_status_enumNullableFilter<$PrismaModel>
  }

  export type NestedEnumquotation_status_enumNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.quotation_status_enum | Enumquotation_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel> | $Enums.quotation_status_enum | null
  }

  export type NestedEnumquotation_status_enumNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.quotation_status_enum | Enumquotation_status_enumFieldRefInput<$PrismaModel> | null
    in?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.quotation_status_enum[] | ListEnumquotation_status_enumFieldRefInput<$PrismaModel> | null
    not?: NestedEnumquotation_status_enumNullableWithAggregatesFilter<$PrismaModel> | $Enums.quotation_status_enum | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel>
    _max?: NestedEnumquotation_status_enumNullableFilter<$PrismaModel>
  }

  export type customerCreateWithoutCreditInput = {
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    notification?: notificationCreateNestedManyWithoutCustomerInput
    order?: orderCreateNestedManyWithoutCustomerInput
    quotation?: quotationCreateNestedManyWithoutCustomerInput
  }

  export type customerUncheckedCreateWithoutCreditInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    notification?: notificationUncheckedCreateNestedManyWithoutCustomerInput
    order?: orderUncheckedCreateNestedManyWithoutCustomerInput
    quotation?: quotationUncheckedCreateNestedManyWithoutCustomerInput
  }

  export type customerCreateOrConnectWithoutCreditInput = {
    where: customerWhereUniqueInput
    create: XOR<customerCreateWithoutCreditInput, customerUncheckedCreateWithoutCreditInput>
  }

  export type customerUpsertWithoutCreditInput = {
    update: XOR<customerUpdateWithoutCreditInput, customerUncheckedUpdateWithoutCreditInput>
    create: XOR<customerCreateWithoutCreditInput, customerUncheckedCreateWithoutCreditInput>
    where?: customerWhereInput
  }

  export type customerUpdateToOneWithWhereWithoutCreditInput = {
    where?: customerWhereInput
    data: XOR<customerUpdateWithoutCreditInput, customerUncheckedUpdateWithoutCreditInput>
  }

  export type customerUpdateWithoutCreditInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notification?: notificationUpdateManyWithoutCustomerNestedInput
    order?: orderUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUpdateManyWithoutCustomerNestedInput
  }

  export type customerUncheckedUpdateWithoutCreditInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notification?: notificationUncheckedUpdateManyWithoutCustomerNestedInput
    order?: orderUncheckedUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUncheckedUpdateManyWithoutCustomerNestedInput
  }

  export type creditCreateWithoutCustomerInput = {
    due_date?: Date | string | null
    credit_amount?: number | null
    status?: $Enums.credit_status_enum | null
    total_credit_limit?: number | null
    available_credit_limit?: number | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type creditUncheckedCreateWithoutCustomerInput = {
    credit_id?: number
    due_date?: Date | string | null
    credit_amount?: number | null
    status?: $Enums.credit_status_enum | null
    total_credit_limit?: number | null
    available_credit_limit?: number | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type creditCreateOrConnectWithoutCustomerInput = {
    where: creditWhereUniqueInput
    create: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
  }

  export type notificationCreateWithoutCustomerInput = {
    message: string
    sent_at?: Date | string | null
  }

  export type notificationUncheckedCreateWithoutCustomerInput = {
    notification_id?: number
    message: string
    sent_at?: Date | string | null
  }

  export type notificationCreateOrConnectWithoutCustomerInput = {
    where: notificationWhereUniqueInput
    create: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput>
  }

  export type notificationCreateManyCustomerInputEnvelope = {
    data: notificationCreateManyCustomerInput | notificationCreateManyCustomerInput[]
    skipDuplicates?: boolean
  }

  export type orderCreateWithoutCustomerInput = {
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    quotation?: quotationCreateNestedOneWithoutOrderInput
    order_details?: order_detailsCreateNestedManyWithoutOrderInput
    payment?: paymentCreateNestedManyWithoutOrderInput
  }

  export type orderUncheckedCreateWithoutCustomerInput = {
    order_id?: number
    quotation_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsUncheckedCreateNestedManyWithoutOrderInput
    payment?: paymentUncheckedCreateNestedManyWithoutOrderInput
  }

  export type orderCreateOrConnectWithoutCustomerInput = {
    where: orderWhereUniqueInput
    create: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput>
  }

  export type orderCreateManyCustomerInputEnvelope = {
    data: orderCreateManyCustomerInput | orderCreateManyCustomerInput[]
    skipDuplicates?: boolean
  }

  export type quotationCreateWithoutCustomerInput = {
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderCreateNestedManyWithoutQuotationInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutQuotationInput
  }

  export type quotationUncheckedCreateWithoutCustomerInput = {
    quotation_id?: number
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderUncheckedCreateNestedManyWithoutQuotationInput
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutQuotationInput
  }

  export type quotationCreateOrConnectWithoutCustomerInput = {
    where: quotationWhereUniqueInput
    create: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput>
  }

  export type quotationCreateManyCustomerInputEnvelope = {
    data: quotationCreateManyCustomerInput | quotationCreateManyCustomerInput[]
    skipDuplicates?: boolean
  }

  export type creditUpsertWithoutCustomerInput = {
    update: XOR<creditUpdateWithoutCustomerInput, creditUncheckedUpdateWithoutCustomerInput>
    create: XOR<creditCreateWithoutCustomerInput, creditUncheckedCreateWithoutCustomerInput>
    where?: creditWhereInput
  }

  export type creditUpdateToOneWithWhereWithoutCustomerInput = {
    where?: creditWhereInput
    data: XOR<creditUpdateWithoutCustomerInput, creditUncheckedUpdateWithoutCustomerInput>
  }

  export type creditUpdateWithoutCustomerInput = {
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type creditUncheckedUpdateWithoutCustomerInput = {
    credit_id?: IntFieldUpdateOperationsInput | number
    due_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit_amount?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumcredit_status_enumFieldUpdateOperationsInput | $Enums.credit_status_enum | null
    total_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    available_credit_limit?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationUpsertWithWhereUniqueWithoutCustomerInput = {
    where: notificationWhereUniqueInput
    update: XOR<notificationUpdateWithoutCustomerInput, notificationUncheckedUpdateWithoutCustomerInput>
    create: XOR<notificationCreateWithoutCustomerInput, notificationUncheckedCreateWithoutCustomerInput>
  }

  export type notificationUpdateWithWhereUniqueWithoutCustomerInput = {
    where: notificationWhereUniqueInput
    data: XOR<notificationUpdateWithoutCustomerInput, notificationUncheckedUpdateWithoutCustomerInput>
  }

  export type notificationUpdateManyWithWhereWithoutCustomerInput = {
    where: notificationScalarWhereInput
    data: XOR<notificationUpdateManyMutationInput, notificationUncheckedUpdateManyWithoutCustomerInput>
  }

  export type notificationScalarWhereInput = {
    AND?: notificationScalarWhereInput | notificationScalarWhereInput[]
    OR?: notificationScalarWhereInput[]
    NOT?: notificationScalarWhereInput | notificationScalarWhereInput[]
    notification_id?: IntFilter<"notification"> | number
    customer_id?: IntNullableFilter<"notification"> | number | null
    message?: StringFilter<"notification"> | string
    sent_at?: DateTimeNullableFilter<"notification"> | Date | string | null
  }

  export type orderUpsertWithWhereUniqueWithoutCustomerInput = {
    where: orderWhereUniqueInput
    update: XOR<orderUpdateWithoutCustomerInput, orderUncheckedUpdateWithoutCustomerInput>
    create: XOR<orderCreateWithoutCustomerInput, orderUncheckedCreateWithoutCustomerInput>
  }

  export type orderUpdateWithWhereUniqueWithoutCustomerInput = {
    where: orderWhereUniqueInput
    data: XOR<orderUpdateWithoutCustomerInput, orderUncheckedUpdateWithoutCustomerInput>
  }

  export type orderUpdateManyWithWhereWithoutCustomerInput = {
    where: orderScalarWhereInput
    data: XOR<orderUpdateManyMutationInput, orderUncheckedUpdateManyWithoutCustomerInput>
  }

  export type orderScalarWhereInput = {
    AND?: orderScalarWhereInput | orderScalarWhereInput[]
    OR?: orderScalarWhereInput[]
    NOT?: orderScalarWhereInput | orderScalarWhereInput[]
    order_id?: IntFilter<"order"> | number
    quotation_id?: IntNullableFilter<"order"> | number | null
    customer_id?: IntNullableFilter<"order"> | number | null
    status?: Enumorder_status_enumNullableFilter<"order"> | $Enums.order_status_enum | null
    total_price?: DecimalNullableFilter<"order"> | Decimal | DecimalJsLike | number | string | null
    created_at?: DateTimeNullableFilter<"order"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"order"> | Date | string | null
  }

  export type quotationUpsertWithWhereUniqueWithoutCustomerInput = {
    where: quotationWhereUniqueInput
    update: XOR<quotationUpdateWithoutCustomerInput, quotationUncheckedUpdateWithoutCustomerInput>
    create: XOR<quotationCreateWithoutCustomerInput, quotationUncheckedCreateWithoutCustomerInput>
  }

  export type quotationUpdateWithWhereUniqueWithoutCustomerInput = {
    where: quotationWhereUniqueInput
    data: XOR<quotationUpdateWithoutCustomerInput, quotationUncheckedUpdateWithoutCustomerInput>
  }

  export type quotationUpdateManyWithWhereWithoutCustomerInput = {
    where: quotationScalarWhereInput
    data: XOR<quotationUpdateManyMutationInput, quotationUncheckedUpdateManyWithoutCustomerInput>
  }

  export type quotationScalarWhereInput = {
    AND?: quotationScalarWhereInput | quotationScalarWhereInput[]
    OR?: quotationScalarWhereInput[]
    NOT?: quotationScalarWhereInput | quotationScalarWhereInput[]
    quotation_id?: IntFilter<"quotation"> | number
    customer_id?: IntNullableFilter<"quotation"> | number | null
    admin_id?: IntNullableFilter<"quotation"> | number | null
    status?: Enumquotation_status_enumNullableFilter<"quotation"> | $Enums.quotation_status_enum | null
    total_amount?: DecimalNullableFilter<"quotation"> | Decimal | DecimalJsLike | number | string | null
    credit_period?: IntNullableFilter<"quotation"> | number | null
    payment_mode?: Enumpayment_mode_enumNullableFilter<"quotation"> | $Enums.payment_mode_enum | null
    created_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
    updated_at?: DateTimeNullableFilter<"quotation"> | Date | string | null
  }

  export type productCreateWithoutInventory_inflow_outflowInput = {
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutProductInput
  }

  export type productUncheckedCreateWithoutInventory_inflow_outflowInput = {
    product_id?: number
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsUncheckedCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type productCreateOrConnectWithoutInventory_inflow_outflowInput = {
    where: productWhereUniqueInput
    create: XOR<productCreateWithoutInventory_inflow_outflowInput, productUncheckedCreateWithoutInventory_inflow_outflowInput>
  }

  export type productUpsertWithoutInventory_inflow_outflowInput = {
    update: XOR<productUpdateWithoutInventory_inflow_outflowInput, productUncheckedUpdateWithoutInventory_inflow_outflowInput>
    create: XOR<productCreateWithoutInventory_inflow_outflowInput, productUncheckedCreateWithoutInventory_inflow_outflowInput>
    where?: productWhereInput
  }

  export type productUpdateToOneWithWhereWithoutInventory_inflow_outflowInput = {
    where?: productWhereInput
    data: XOR<productUpdateWithoutInventory_inflow_outflowInput, productUncheckedUpdateWithoutInventory_inflow_outflowInput>
  }

  export type productUpdateWithoutInventory_inflow_outflowInput = {
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutProductNestedInput
  }

  export type productUncheckedUpdateWithoutInventory_inflow_outflowInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUncheckedUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type customerCreateWithoutNotificationInput = {
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditCreateNestedOneWithoutCustomerInput
    order?: orderCreateNestedManyWithoutCustomerInput
    quotation?: quotationCreateNestedManyWithoutCustomerInput
  }

  export type customerUncheckedCreateWithoutNotificationInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditUncheckedCreateNestedOneWithoutCustomerInput
    order?: orderUncheckedCreateNestedManyWithoutCustomerInput
    quotation?: quotationUncheckedCreateNestedManyWithoutCustomerInput
  }

  export type customerCreateOrConnectWithoutNotificationInput = {
    where: customerWhereUniqueInput
    create: XOR<customerCreateWithoutNotificationInput, customerUncheckedCreateWithoutNotificationInput>
  }

  export type customerUpsertWithoutNotificationInput = {
    update: XOR<customerUpdateWithoutNotificationInput, customerUncheckedUpdateWithoutNotificationInput>
    create: XOR<customerCreateWithoutNotificationInput, customerUncheckedCreateWithoutNotificationInput>
    where?: customerWhereInput
  }

  export type customerUpdateToOneWithWhereWithoutNotificationInput = {
    where?: customerWhereInput
    data: XOR<customerUpdateWithoutNotificationInput, customerUncheckedUpdateWithoutNotificationInput>
  }

  export type customerUpdateWithoutNotificationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUpdateOneWithoutCustomerNestedInput
    order?: orderUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUpdateManyWithoutCustomerNestedInput
  }

  export type customerUncheckedUpdateWithoutNotificationInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUncheckedUpdateOneWithoutCustomerNestedInput
    order?: orderUncheckedUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUncheckedUpdateManyWithoutCustomerNestedInput
  }

  export type customerCreateWithoutOrderInput = {
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditCreateNestedOneWithoutCustomerInput
    notification?: notificationCreateNestedManyWithoutCustomerInput
    quotation?: quotationCreateNestedManyWithoutCustomerInput
  }

  export type customerUncheckedCreateWithoutOrderInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditUncheckedCreateNestedOneWithoutCustomerInput
    notification?: notificationUncheckedCreateNestedManyWithoutCustomerInput
    quotation?: quotationUncheckedCreateNestedManyWithoutCustomerInput
  }

  export type customerCreateOrConnectWithoutOrderInput = {
    where: customerWhereUniqueInput
    create: XOR<customerCreateWithoutOrderInput, customerUncheckedCreateWithoutOrderInput>
  }

  export type quotationCreateWithoutOrderInput = {
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutQuotationInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutQuotationInput
  }

  export type quotationUncheckedCreateWithoutOrderInput = {
    quotation_id?: number
    customer_id?: number | null
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutQuotationInput
  }

  export type quotationCreateOrConnectWithoutOrderInput = {
    where: quotationWhereUniqueInput
    create: XOR<quotationCreateWithoutOrderInput, quotationUncheckedCreateWithoutOrderInput>
  }

  export type order_detailsCreateWithoutOrderInput = {
    quantity: number
    price: Decimal | DecimalJsLike | number | string
    product?: productCreateNestedOneWithoutOrder_detailsInput
  }

  export type order_detailsUncheckedCreateWithoutOrderInput = {
    order_item_id?: number
    product_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type order_detailsCreateOrConnectWithoutOrderInput = {
    where: order_detailsWhereUniqueInput
    create: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput>
  }

  export type order_detailsCreateManyOrderInputEnvelope = {
    data: order_detailsCreateManyOrderInput | order_detailsCreateManyOrderInput[]
    skipDuplicates?: boolean
  }

  export type paymentCreateWithoutOrderInput = {
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
  }

  export type paymentUncheckedCreateWithoutOrderInput = {
    payment_id?: number
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
  }

  export type paymentCreateOrConnectWithoutOrderInput = {
    where: paymentWhereUniqueInput
    create: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput>
  }

  export type paymentCreateManyOrderInputEnvelope = {
    data: paymentCreateManyOrderInput | paymentCreateManyOrderInput[]
    skipDuplicates?: boolean
  }

  export type customerUpsertWithoutOrderInput = {
    update: XOR<customerUpdateWithoutOrderInput, customerUncheckedUpdateWithoutOrderInput>
    create: XOR<customerCreateWithoutOrderInput, customerUncheckedCreateWithoutOrderInput>
    where?: customerWhereInput
  }

  export type customerUpdateToOneWithWhereWithoutOrderInput = {
    where?: customerWhereInput
    data: XOR<customerUpdateWithoutOrderInput, customerUncheckedUpdateWithoutOrderInput>
  }

  export type customerUpdateWithoutOrderInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUpdateOneWithoutCustomerNestedInput
    notification?: notificationUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUpdateManyWithoutCustomerNestedInput
  }

  export type customerUncheckedUpdateWithoutOrderInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUncheckedUpdateOneWithoutCustomerNestedInput
    notification?: notificationUncheckedUpdateManyWithoutCustomerNestedInput
    quotation?: quotationUncheckedUpdateManyWithoutCustomerNestedInput
  }

  export type quotationUpsertWithoutOrderInput = {
    update: XOR<quotationUpdateWithoutOrderInput, quotationUncheckedUpdateWithoutOrderInput>
    create: XOR<quotationCreateWithoutOrderInput, quotationUncheckedCreateWithoutOrderInput>
    where?: quotationWhereInput
  }

  export type quotationUpdateToOneWithWhereWithoutOrderInput = {
    where?: quotationWhereInput
    data: XOR<quotationUpdateWithoutOrderInput, quotationUncheckedUpdateWithoutOrderInput>
  }

  export type quotationUpdateWithoutOrderInput = {
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutQuotationNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutQuotationNestedInput
  }

  export type quotationUncheckedUpdateWithoutOrderInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutQuotationNestedInput
  }

  export type order_detailsUpsertWithWhereUniqueWithoutOrderInput = {
    where: order_detailsWhereUniqueInput
    update: XOR<order_detailsUpdateWithoutOrderInput, order_detailsUncheckedUpdateWithoutOrderInput>
    create: XOR<order_detailsCreateWithoutOrderInput, order_detailsUncheckedCreateWithoutOrderInput>
  }

  export type order_detailsUpdateWithWhereUniqueWithoutOrderInput = {
    where: order_detailsWhereUniqueInput
    data: XOR<order_detailsUpdateWithoutOrderInput, order_detailsUncheckedUpdateWithoutOrderInput>
  }

  export type order_detailsUpdateManyWithWhereWithoutOrderInput = {
    where: order_detailsScalarWhereInput
    data: XOR<order_detailsUpdateManyMutationInput, order_detailsUncheckedUpdateManyWithoutOrderInput>
  }

  export type order_detailsScalarWhereInput = {
    AND?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
    OR?: order_detailsScalarWhereInput[]
    NOT?: order_detailsScalarWhereInput | order_detailsScalarWhereInput[]
    order_item_id?: IntFilter<"order_details"> | number
    order_id?: IntNullableFilter<"order_details"> | number | null
    product_id?: IntNullableFilter<"order_details"> | number | null
    quantity?: IntFilter<"order_details"> | number
    price?: DecimalFilter<"order_details"> | Decimal | DecimalJsLike | number | string
  }

  export type paymentUpsertWithWhereUniqueWithoutOrderInput = {
    where: paymentWhereUniqueInput
    update: XOR<paymentUpdateWithoutOrderInput, paymentUncheckedUpdateWithoutOrderInput>
    create: XOR<paymentCreateWithoutOrderInput, paymentUncheckedCreateWithoutOrderInput>
  }

  export type paymentUpdateWithWhereUniqueWithoutOrderInput = {
    where: paymentWhereUniqueInput
    data: XOR<paymentUpdateWithoutOrderInput, paymentUncheckedUpdateWithoutOrderInput>
  }

  export type paymentUpdateManyWithWhereWithoutOrderInput = {
    where: paymentScalarWhereInput
    data: XOR<paymentUpdateManyMutationInput, paymentUncheckedUpdateManyWithoutOrderInput>
  }

  export type paymentScalarWhereInput = {
    AND?: paymentScalarWhereInput | paymentScalarWhereInput[]
    OR?: paymentScalarWhereInput[]
    NOT?: paymentScalarWhereInput | paymentScalarWhereInput[]
    payment_id?: IntFilter<"payment"> | number
    order_id?: IntNullableFilter<"payment"> | number | null
    amount?: DecimalFilter<"payment"> | Decimal | DecimalJsLike | number | string
    payment_mode?: Enumpayment_mode_enumNullableFilter<"payment"> | $Enums.payment_mode_enum | null
    payment_date?: DateTimeNullableFilter<"payment"> | Date | string | null
    status?: Enumpayment_status_enumNullableFilter<"payment"> | $Enums.payment_status_enum | null
  }

  export type orderCreateWithoutOrder_detailsInput = {
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutOrderInput
    quotation?: quotationCreateNestedOneWithoutOrderInput
    payment?: paymentCreateNestedManyWithoutOrderInput
  }

  export type orderUncheckedCreateWithoutOrder_detailsInput = {
    order_id?: number
    quotation_id?: number | null
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    payment?: paymentUncheckedCreateNestedManyWithoutOrderInput
  }

  export type orderCreateOrConnectWithoutOrder_detailsInput = {
    where: orderWhereUniqueInput
    create: XOR<orderCreateWithoutOrder_detailsInput, orderUncheckedCreateWithoutOrder_detailsInput>
  }

  export type productCreateWithoutOrder_detailsInput = {
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsCreateNestedManyWithoutProductInput
  }

  export type productUncheckedCreateWithoutOrder_detailsInput = {
    product_id?: number
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedCreateNestedManyWithoutProductInput
    quotation_details?: quotation_detailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type productCreateOrConnectWithoutOrder_detailsInput = {
    where: productWhereUniqueInput
    create: XOR<productCreateWithoutOrder_detailsInput, productUncheckedCreateWithoutOrder_detailsInput>
  }

  export type orderUpsertWithoutOrder_detailsInput = {
    update: XOR<orderUpdateWithoutOrder_detailsInput, orderUncheckedUpdateWithoutOrder_detailsInput>
    create: XOR<orderCreateWithoutOrder_detailsInput, orderUncheckedCreateWithoutOrder_detailsInput>
    where?: orderWhereInput
  }

  export type orderUpdateToOneWithWhereWithoutOrder_detailsInput = {
    where?: orderWhereInput
    data: XOR<orderUpdateWithoutOrder_detailsInput, orderUncheckedUpdateWithoutOrder_detailsInput>
  }

  export type orderUpdateWithoutOrder_detailsInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutOrderNestedInput
    quotation?: quotationUpdateOneWithoutOrderNestedInput
    payment?: paymentUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateWithoutOrder_detailsInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    payment?: paymentUncheckedUpdateManyWithoutOrderNestedInput
  }

  export type productUpsertWithoutOrder_detailsInput = {
    update: XOR<productUpdateWithoutOrder_detailsInput, productUncheckedUpdateWithoutOrder_detailsInput>
    create: XOR<productCreateWithoutOrder_detailsInput, productUncheckedCreateWithoutOrder_detailsInput>
    where?: productWhereInput
  }

  export type productUpdateToOneWithWhereWithoutOrder_detailsInput = {
    where?: productWhereInput
    data: XOR<productUpdateWithoutOrder_detailsInput, productUncheckedUpdateWithoutOrder_detailsInput>
  }

  export type productUpdateWithoutOrder_detailsInput = {
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutProductNestedInput
  }

  export type productUncheckedUpdateWithoutOrder_detailsInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedUpdateManyWithoutProductNestedInput
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type orderCreateWithoutPaymentInput = {
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutOrderInput
    quotation?: quotationCreateNestedOneWithoutOrderInput
    order_details?: order_detailsCreateNestedManyWithoutOrderInput
  }

  export type orderUncheckedCreateWithoutPaymentInput = {
    order_id?: number
    quotation_id?: number | null
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsUncheckedCreateNestedManyWithoutOrderInput
  }

  export type orderCreateOrConnectWithoutPaymentInput = {
    where: orderWhereUniqueInput
    create: XOR<orderCreateWithoutPaymentInput, orderUncheckedCreateWithoutPaymentInput>
  }

  export type orderUpsertWithoutPaymentInput = {
    update: XOR<orderUpdateWithoutPaymentInput, orderUncheckedUpdateWithoutPaymentInput>
    create: XOR<orderCreateWithoutPaymentInput, orderUncheckedCreateWithoutPaymentInput>
    where?: orderWhereInput
  }

  export type orderUpdateToOneWithWhereWithoutPaymentInput = {
    where?: orderWhereInput
    data: XOR<orderUpdateWithoutPaymentInput, orderUncheckedUpdateWithoutPaymentInput>
  }

  export type orderUpdateWithoutPaymentInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutOrderNestedInput
    quotation?: quotationUpdateOneWithoutOrderNestedInput
    order_details?: order_detailsUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateWithoutPaymentInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUncheckedUpdateManyWithoutOrderNestedInput
  }

  export type inventory_inflow_outflowCreateWithoutProductInput = {
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
  }

  export type inventory_inflow_outflowUncheckedCreateWithoutProductInput = {
    id?: number
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
  }

  export type inventory_inflow_outflowCreateOrConnectWithoutProductInput = {
    where: inventory_inflow_outflowWhereUniqueInput
    create: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput>
  }

  export type inventory_inflow_outflowCreateManyProductInputEnvelope = {
    data: inventory_inflow_outflowCreateManyProductInput | inventory_inflow_outflowCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type order_detailsCreateWithoutProductInput = {
    quantity: number
    price: Decimal | DecimalJsLike | number | string
    order?: orderCreateNestedOneWithoutOrder_detailsInput
  }

  export type order_detailsUncheckedCreateWithoutProductInput = {
    order_item_id?: number
    order_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type order_detailsCreateOrConnectWithoutProductInput = {
    where: order_detailsWhereUniqueInput
    create: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput>
  }

  export type order_detailsCreateManyProductInputEnvelope = {
    data: order_detailsCreateManyProductInput | order_detailsCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type quotation_detailsCreateWithoutProductInput = {
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
    quotation?: quotationCreateNestedOneWithoutQuotation_detailsInput
  }

  export type quotation_detailsUncheckedCreateWithoutProductInput = {
    quotation_item_id?: number
    quotation_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsCreateOrConnectWithoutProductInput = {
    where: quotation_detailsWhereUniqueInput
    create: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput>
  }

  export type quotation_detailsCreateManyProductInputEnvelope = {
    data: quotation_detailsCreateManyProductInput | quotation_detailsCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type inventory_inflow_outflowUpsertWithWhereUniqueWithoutProductInput = {
    where: inventory_inflow_outflowWhereUniqueInput
    update: XOR<inventory_inflow_outflowUpdateWithoutProductInput, inventory_inflow_outflowUncheckedUpdateWithoutProductInput>
    create: XOR<inventory_inflow_outflowCreateWithoutProductInput, inventory_inflow_outflowUncheckedCreateWithoutProductInput>
  }

  export type inventory_inflow_outflowUpdateWithWhereUniqueWithoutProductInput = {
    where: inventory_inflow_outflowWhereUniqueInput
    data: XOR<inventory_inflow_outflowUpdateWithoutProductInput, inventory_inflow_outflowUncheckedUpdateWithoutProductInput>
  }

  export type inventory_inflow_outflowUpdateManyWithWhereWithoutProductInput = {
    where: inventory_inflow_outflowScalarWhereInput
    data: XOR<inventory_inflow_outflowUpdateManyMutationInput, inventory_inflow_outflowUncheckedUpdateManyWithoutProductInput>
  }

  export type inventory_inflow_outflowScalarWhereInput = {
    AND?: inventory_inflow_outflowScalarWhereInput | inventory_inflow_outflowScalarWhereInput[]
    OR?: inventory_inflow_outflowScalarWhereInput[]
    NOT?: inventory_inflow_outflowScalarWhereInput | inventory_inflow_outflowScalarWhereInput[]
    id?: IntFilter<"inventory_inflow_outflow"> | number
    product_id?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    flow_direction?: Enumflow_direction_enumNullableFilter<"inventory_inflow_outflow"> | $Enums.flow_direction_enum | null
    quantity?: IntNullableFilter<"inventory_inflow_outflow"> | number | null
    created_at?: DateTimeNullableFilter<"inventory_inflow_outflow"> | Date | string | null
  }

  export type order_detailsUpsertWithWhereUniqueWithoutProductInput = {
    where: order_detailsWhereUniqueInput
    update: XOR<order_detailsUpdateWithoutProductInput, order_detailsUncheckedUpdateWithoutProductInput>
    create: XOR<order_detailsCreateWithoutProductInput, order_detailsUncheckedCreateWithoutProductInput>
  }

  export type order_detailsUpdateWithWhereUniqueWithoutProductInput = {
    where: order_detailsWhereUniqueInput
    data: XOR<order_detailsUpdateWithoutProductInput, order_detailsUncheckedUpdateWithoutProductInput>
  }

  export type order_detailsUpdateManyWithWhereWithoutProductInput = {
    where: order_detailsScalarWhereInput
    data: XOR<order_detailsUpdateManyMutationInput, order_detailsUncheckedUpdateManyWithoutProductInput>
  }

  export type quotation_detailsUpsertWithWhereUniqueWithoutProductInput = {
    where: quotation_detailsWhereUniqueInput
    update: XOR<quotation_detailsUpdateWithoutProductInput, quotation_detailsUncheckedUpdateWithoutProductInput>
    create: XOR<quotation_detailsCreateWithoutProductInput, quotation_detailsUncheckedCreateWithoutProductInput>
  }

  export type quotation_detailsUpdateWithWhereUniqueWithoutProductInput = {
    where: quotation_detailsWhereUniqueInput
    data: XOR<quotation_detailsUpdateWithoutProductInput, quotation_detailsUncheckedUpdateWithoutProductInput>
  }

  export type quotation_detailsUpdateManyWithWhereWithoutProductInput = {
    where: quotation_detailsScalarWhereInput
    data: XOR<quotation_detailsUpdateManyMutationInput, quotation_detailsUncheckedUpdateManyWithoutProductInput>
  }

  export type quotation_detailsScalarWhereInput = {
    AND?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
    OR?: quotation_detailsScalarWhereInput[]
    NOT?: quotation_detailsScalarWhereInput | quotation_detailsScalarWhereInput[]
    quotation_item_id?: IntFilter<"quotation_details"> | number
    quotation_id?: IntNullableFilter<"quotation_details"> | number | null
    product_id?: IntNullableFilter<"quotation_details"> | number | null
    quantity?: IntFilter<"quotation_details"> | number
    price?: DecimalNullableFilter<"quotation_details"> | Decimal | DecimalJsLike | number | string | null
  }

  export type orderCreateWithoutQuotationInput = {
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    customer?: customerCreateNestedOneWithoutOrderInput
    order_details?: order_detailsCreateNestedManyWithoutOrderInput
    payment?: paymentCreateNestedManyWithoutOrderInput
  }

  export type orderUncheckedCreateWithoutQuotationInput = {
    order_id?: number
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order_details?: order_detailsUncheckedCreateNestedManyWithoutOrderInput
    payment?: paymentUncheckedCreateNestedManyWithoutOrderInput
  }

  export type orderCreateOrConnectWithoutQuotationInput = {
    where: orderWhereUniqueInput
    create: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput>
  }

  export type orderCreateManyQuotationInputEnvelope = {
    data: orderCreateManyQuotationInput | orderCreateManyQuotationInput[]
    skipDuplicates?: boolean
  }

  export type customerCreateWithoutQuotationInput = {
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditCreateNestedOneWithoutCustomerInput
    notification?: notificationCreateNestedManyWithoutCustomerInput
    order?: orderCreateNestedManyWithoutCustomerInput
  }

  export type customerUncheckedCreateWithoutQuotationInput = {
    customer_id?: number
    username: string
    password: string
    email: string
    mobile_number: string
    credit_limit?: Decimal | DecimalJsLike | number | string | null
    remaining_credit?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    credit?: creditUncheckedCreateNestedOneWithoutCustomerInput
    notification?: notificationUncheckedCreateNestedManyWithoutCustomerInput
    order?: orderUncheckedCreateNestedManyWithoutCustomerInput
  }

  export type customerCreateOrConnectWithoutQuotationInput = {
    where: customerWhereUniqueInput
    create: XOR<customerCreateWithoutQuotationInput, customerUncheckedCreateWithoutQuotationInput>
  }

  export type quotation_detailsCreateWithoutQuotationInput = {
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
    product?: productCreateNestedOneWithoutQuotation_detailsInput
  }

  export type quotation_detailsUncheckedCreateWithoutQuotationInput = {
    quotation_item_id?: number
    product_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsCreateOrConnectWithoutQuotationInput = {
    where: quotation_detailsWhereUniqueInput
    create: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput>
  }

  export type quotation_detailsCreateManyQuotationInputEnvelope = {
    data: quotation_detailsCreateManyQuotationInput | quotation_detailsCreateManyQuotationInput[]
    skipDuplicates?: boolean
  }

  export type orderUpsertWithWhereUniqueWithoutQuotationInput = {
    where: orderWhereUniqueInput
    update: XOR<orderUpdateWithoutQuotationInput, orderUncheckedUpdateWithoutQuotationInput>
    create: XOR<orderCreateWithoutQuotationInput, orderUncheckedCreateWithoutQuotationInput>
  }

  export type orderUpdateWithWhereUniqueWithoutQuotationInput = {
    where: orderWhereUniqueInput
    data: XOR<orderUpdateWithoutQuotationInput, orderUncheckedUpdateWithoutQuotationInput>
  }

  export type orderUpdateManyWithWhereWithoutQuotationInput = {
    where: orderScalarWhereInput
    data: XOR<orderUpdateManyMutationInput, orderUncheckedUpdateManyWithoutQuotationInput>
  }

  export type customerUpsertWithoutQuotationInput = {
    update: XOR<customerUpdateWithoutQuotationInput, customerUncheckedUpdateWithoutQuotationInput>
    create: XOR<customerCreateWithoutQuotationInput, customerUncheckedCreateWithoutQuotationInput>
    where?: customerWhereInput
  }

  export type customerUpdateToOneWithWhereWithoutQuotationInput = {
    where?: customerWhereInput
    data: XOR<customerUpdateWithoutQuotationInput, customerUncheckedUpdateWithoutQuotationInput>
  }

  export type customerUpdateWithoutQuotationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUpdateOneWithoutCustomerNestedInput
    notification?: notificationUpdateManyWithoutCustomerNestedInput
    order?: orderUpdateManyWithoutCustomerNestedInput
  }

  export type customerUncheckedUpdateWithoutQuotationInput = {
    customer_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    mobile_number?: StringFieldUpdateOperationsInput | string
    credit_limit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    remaining_credit?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    credit?: creditUncheckedUpdateOneWithoutCustomerNestedInput
    notification?: notificationUncheckedUpdateManyWithoutCustomerNestedInput
    order?: orderUncheckedUpdateManyWithoutCustomerNestedInput
  }

  export type quotation_detailsUpsertWithWhereUniqueWithoutQuotationInput = {
    where: quotation_detailsWhereUniqueInput
    update: XOR<quotation_detailsUpdateWithoutQuotationInput, quotation_detailsUncheckedUpdateWithoutQuotationInput>
    create: XOR<quotation_detailsCreateWithoutQuotationInput, quotation_detailsUncheckedCreateWithoutQuotationInput>
  }

  export type quotation_detailsUpdateWithWhereUniqueWithoutQuotationInput = {
    where: quotation_detailsWhereUniqueInput
    data: XOR<quotation_detailsUpdateWithoutQuotationInput, quotation_detailsUncheckedUpdateWithoutQuotationInput>
  }

  export type quotation_detailsUpdateManyWithWhereWithoutQuotationInput = {
    where: quotation_detailsScalarWhereInput
    data: XOR<quotation_detailsUpdateManyMutationInput, quotation_detailsUncheckedUpdateManyWithoutQuotationInput>
  }

  export type productCreateWithoutQuotation_detailsInput = {
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowCreateNestedManyWithoutProductInput
    order_details?: order_detailsCreateNestedManyWithoutProductInput
  }

  export type productUncheckedCreateWithoutQuotation_detailsInput = {
    product_id?: number
    name: string
    min_stock_limit?: number | null
    description?: string | null
    specifications?: string | null
    image_url?: productCreateimage_urlInput | string[]
    price: Decimal | DecimalJsLike | number | string
    created_at?: Date | string | null
    updated_at?: Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedCreateNestedManyWithoutProductInput
    order_details?: order_detailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type productCreateOrConnectWithoutQuotation_detailsInput = {
    where: productWhereUniqueInput
    create: XOR<productCreateWithoutQuotation_detailsInput, productUncheckedCreateWithoutQuotation_detailsInput>
  }

  export type quotationCreateWithoutQuotation_detailsInput = {
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderCreateNestedManyWithoutQuotationInput
    customer?: customerCreateNestedOneWithoutQuotationInput
  }

  export type quotationUncheckedCreateWithoutQuotation_detailsInput = {
    quotation_id?: number
    customer_id?: number | null
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
    order?: orderUncheckedCreateNestedManyWithoutQuotationInput
  }

  export type quotationCreateOrConnectWithoutQuotation_detailsInput = {
    where: quotationWhereUniqueInput
    create: XOR<quotationCreateWithoutQuotation_detailsInput, quotationUncheckedCreateWithoutQuotation_detailsInput>
  }

  export type productUpsertWithoutQuotation_detailsInput = {
    update: XOR<productUpdateWithoutQuotation_detailsInput, productUncheckedUpdateWithoutQuotation_detailsInput>
    create: XOR<productCreateWithoutQuotation_detailsInput, productUncheckedCreateWithoutQuotation_detailsInput>
    where?: productWhereInput
  }

  export type productUpdateToOneWithWhereWithoutQuotation_detailsInput = {
    where?: productWhereInput
    data: XOR<productUpdateWithoutQuotation_detailsInput, productUncheckedUpdateWithoutQuotation_detailsInput>
  }

  export type productUpdateWithoutQuotation_detailsInput = {
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUpdateManyWithoutProductNestedInput
    order_details?: order_detailsUpdateManyWithoutProductNestedInput
  }

  export type productUncheckedUpdateWithoutQuotation_detailsInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    min_stock_limit?: NullableIntFieldUpdateOperationsInput | number | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    specifications?: NullableStringFieldUpdateOperationsInput | string | null
    image_url?: productUpdateimage_urlInput | string[]
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    inventory_inflow_outflow?: inventory_inflow_outflowUncheckedUpdateManyWithoutProductNestedInput
    order_details?: order_detailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type quotationUpsertWithoutQuotation_detailsInput = {
    update: XOR<quotationUpdateWithoutQuotation_detailsInput, quotationUncheckedUpdateWithoutQuotation_detailsInput>
    create: XOR<quotationCreateWithoutQuotation_detailsInput, quotationUncheckedCreateWithoutQuotation_detailsInput>
    where?: quotationWhereInput
  }

  export type quotationUpdateToOneWithWhereWithoutQuotation_detailsInput = {
    where?: quotationWhereInput
    data: XOR<quotationUpdateWithoutQuotation_detailsInput, quotationUncheckedUpdateWithoutQuotation_detailsInput>
  }

  export type quotationUpdateWithoutQuotation_detailsInput = {
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUpdateManyWithoutQuotationNestedInput
    customer?: customerUpdateOneWithoutQuotationNestedInput
  }

  export type quotationUncheckedUpdateWithoutQuotation_detailsInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUncheckedUpdateManyWithoutQuotationNestedInput
  }

  export type notificationCreateManyCustomerInput = {
    notification_id?: number
    message: string
    sent_at?: Date | string | null
  }

  export type orderCreateManyCustomerInput = {
    order_id?: number
    quotation_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type quotationCreateManyCustomerInput = {
    quotation_id?: number
    admin_id?: number | null
    status?: $Enums.quotation_status_enum | null
    total_amount?: Decimal | DecimalJsLike | number | string | null
    credit_period?: number | null
    payment_mode?: $Enums.payment_mode_enum | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type notificationUpdateWithoutCustomerInput = {
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationUncheckedUpdateWithoutCustomerInput = {
    notification_id?: IntFieldUpdateOperationsInput | number
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type notificationUncheckedUpdateManyWithoutCustomerInput = {
    notification_id?: IntFieldUpdateOperationsInput | number
    message?: StringFieldUpdateOperationsInput | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type orderUpdateWithoutCustomerInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    quotation?: quotationUpdateOneWithoutOrderNestedInput
    order_details?: order_detailsUpdateManyWithoutOrderNestedInput
    payment?: paymentUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateWithoutCustomerInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUncheckedUpdateManyWithoutOrderNestedInput
    payment?: paymentUncheckedUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateManyWithoutCustomerInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type quotationUpdateWithoutCustomerInput = {
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUpdateManyWithoutQuotationNestedInput
    quotation_details?: quotation_detailsUpdateManyWithoutQuotationNestedInput
  }

  export type quotationUncheckedUpdateWithoutCustomerInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order?: orderUncheckedUpdateManyWithoutQuotationNestedInput
    quotation_details?: quotation_detailsUncheckedUpdateManyWithoutQuotationNestedInput
  }

  export type quotationUncheckedUpdateManyWithoutCustomerInput = {
    quotation_id?: IntFieldUpdateOperationsInput | number
    admin_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumquotation_status_enumFieldUpdateOperationsInput | $Enums.quotation_status_enum | null
    total_amount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    credit_period?: NullableIntFieldUpdateOperationsInput | number | null
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type order_detailsCreateManyOrderInput = {
    order_item_id?: number
    product_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type paymentCreateManyOrderInput = {
    payment_id?: number
    amount: Decimal | DecimalJsLike | number | string
    payment_mode?: $Enums.payment_mode_enum | null
    payment_date?: Date | string | null
    status?: $Enums.payment_status_enum | null
  }

  export type order_detailsUpdateWithoutOrderInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    product?: productUpdateOneWithoutOrder_detailsNestedInput
  }

  export type order_detailsUncheckedUpdateWithoutOrderInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type order_detailsUncheckedUpdateManyWithoutOrderInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type paymentUpdateWithoutOrderInput = {
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type paymentUncheckedUpdateWithoutOrderInput = {
    payment_id?: IntFieldUpdateOperationsInput | number
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type paymentUncheckedUpdateManyWithoutOrderInput = {
    payment_id?: IntFieldUpdateOperationsInput | number
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_mode?: NullableEnumpayment_mode_enumFieldUpdateOperationsInput | $Enums.payment_mode_enum | null
    payment_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: NullableEnumpayment_status_enumFieldUpdateOperationsInput | $Enums.payment_status_enum | null
  }

  export type inventory_inflow_outflowCreateManyProductInput = {
    id?: number
    flow_direction?: $Enums.flow_direction_enum | null
    quantity?: number | null
    created_at?: Date | string | null
  }

  export type order_detailsCreateManyProductInput = {
    order_item_id?: number
    order_id?: number | null
    quantity: number
    price: Decimal | DecimalJsLike | number | string
  }

  export type quotation_detailsCreateManyProductInput = {
    quotation_item_id?: number
    quotation_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type inventory_inflow_outflowUpdateWithoutProductInput = {
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inventory_inflow_outflowUncheckedUpdateWithoutProductInput = {
    id?: IntFieldUpdateOperationsInput | number
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inventory_inflow_outflowUncheckedUpdateManyWithoutProductInput = {
    id?: IntFieldUpdateOperationsInput | number
    flow_direction?: NullableEnumflow_direction_enumFieldUpdateOperationsInput | $Enums.flow_direction_enum | null
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type order_detailsUpdateWithoutProductInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    order?: orderUpdateOneWithoutOrder_detailsNestedInput
  }

  export type order_detailsUncheckedUpdateWithoutProductInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type order_detailsUncheckedUpdateManyWithoutProductInput = {
    order_item_id?: IntFieldUpdateOperationsInput | number
    order_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
  }

  export type quotation_detailsUpdateWithoutProductInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    quotation?: quotationUpdateOneWithoutQuotation_detailsNestedInput
  }

  export type quotation_detailsUncheckedUpdateWithoutProductInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsUncheckedUpdateManyWithoutProductInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    quotation_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type orderCreateManyQuotationInput = {
    order_id?: number
    customer_id?: number | null
    status?: $Enums.order_status_enum | null
    total_price?: Decimal | DecimalJsLike | number | string | null
    created_at?: Date | string | null
    updated_at?: Date | string | null
  }

  export type quotation_detailsCreateManyQuotationInput = {
    quotation_item_id?: number
    product_id?: number | null
    quantity: number
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type orderUpdateWithoutQuotationInput = {
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    customer?: customerUpdateOneWithoutOrderNestedInput
    order_details?: order_detailsUpdateManyWithoutOrderNestedInput
    payment?: paymentUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateWithoutQuotationInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    order_details?: order_detailsUncheckedUpdateManyWithoutOrderNestedInput
    payment?: paymentUncheckedUpdateManyWithoutOrderNestedInput
  }

  export type orderUncheckedUpdateManyWithoutQuotationInput = {
    order_id?: IntFieldUpdateOperationsInput | number
    customer_id?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableEnumorder_status_enumFieldUpdateOperationsInput | $Enums.order_status_enum | null
    total_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    created_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updated_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type quotation_detailsUpdateWithoutQuotationInput = {
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    product?: productUpdateOneWithoutQuotation_detailsNestedInput
  }

  export type quotation_detailsUncheckedUpdateWithoutQuotationInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type quotation_detailsUncheckedUpdateManyWithoutQuotationInput = {
    quotation_item_id?: IntFieldUpdateOperationsInput | number
    product_id?: NullableIntFieldUpdateOperationsInput | number | null
    quantity?: IntFieldUpdateOperationsInput | number
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}